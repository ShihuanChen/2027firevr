# -*- coding: utf-8 -*-
"""最终净化：处理近重复（保留 gid 较小的那条），从池补足 180。"""
import csv, os, random, re
from collections import Counter

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")
GOLD = os.path.join(D, "_goldset_v2_分层抽样_净化.csv")
OUT = os.path.join(D, "_goldset_v2_分层抽样_净化.csv")

def norm(t):
    t = t.lower()
    t = re.sub(r"[^a-z0-9\u4e00-\u9fff ]", "", t)
    return " ".join(t.split())

rows = []
with open(GOLD, encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        rows.append(r)

# 近重复去重（保留每组的第一个，即 gid 较小）
seen = {}
to_drop = []
for i, r in enumerate(rows):
    nt = norm(r["标题"])
    if nt in seen:
        to_drop.append(i)
    else:
        seen[nt] = i
print(f"需剔除近重复: {len(to_drop)}")
for i in to_drop:
    print(f"  drop gid{rows[i]['编号']} {rows[i]['标题'][:60]}")

# 从池补足
keep_gids = {r["编号"] for j, r in enumerate(rows) if j not in to_drop}
pool = []
with open(SRC, encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        gid = i + 1
        if gid <= 103 or str(gid) in keep_gids:
            continue
        title = row[1] if len(row) > 1 else ""
        body = row[4] if len(row) > 4 else ""
        if len(body or "") < 400 or not (title or "").strip() or len((title or "").strip()) < 12:
            continue
        pool.append({"gid": gid, "title": title, "body": body, "L": len(body)})

random.seed(20260803)
subs = random.sample(pool, len(to_drop))
for i, sub in zip(to_drop, subs):
    rows[i] = {"编号": sub["gid"], "标题": sub["title"][:80], "字数": sub["L"],
               "分层特征": "REPLACED", "正文(前2500)": sub["body"][:2500].replace("\n", " ").replace("\r", ""),
               "用户填1/0": ""}

rows.sort(key=lambda r: int(r["编号"]))
with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(list(rows[0].keys()))
    for r in rows:
        w.writerow([r[k] for k in rows[0].keys()])

# 最终复查
titles2 = [norm(r["标题"]) for r in rows]
dups = {k: v for k, v in Counter(titles2).items() if v > 1}
print(f"\n输出: {OUT}, 共 {len(rows)} 条")
print(f"复查: 重复组 {len(dups)}, 空标题 {sum(1 for r in rows if not (r['标题'] or '').strip())}")
