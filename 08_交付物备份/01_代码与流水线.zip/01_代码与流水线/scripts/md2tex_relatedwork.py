# -*- coding: utf-8 -*-
"""将 Related work 成稿.md 转换为 relatedwork.tex（中文原文保留，供协作时翻译成英文）。"""
import re, os

src = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "relatedwork", "Related work 成稿.md")
with open(src, encoding="utf-8") as f:
    md = f.read()

def convert_cites(t):
    t = re.sub(r"【([A-Za-z0-9_]+)】", r"\\cite{\1}", t)
    t = re.sub(r"\*\*(.+?)\*\*", r"\\textbf{\1}", t)
    return t

# 分节：第一个标题前为引言，之后按 ## 切分
lines = md.split("\n")
intro, sections, cur, cur_title = [], {}, None, None
for ln in lines:
    if ln.startswith("## "):
        if cur_title is not None:
            sections[cur_title] = cur
        cur_title = ln[3:].strip()
        cur = []
    elif cur_title is None:
        intro.append(ln)
    else:
        cur.append(ln)
if cur_title is not None:
    sections[cur_title] = cur

def sec_id(title):
    m = re.match(r"([\d.]+)\s*(.*)", title)
    return m.group(1), m.group(2)

out = []
out.append("% ============================================================")
out.append("% Related Work — CHI 2027 投稿草稿（中文原文，待翻译成英文）")
out.append("% 生成自: relatedwork/Related work 成稿.md")
out.append("% 所有 \\cite key 与 references.bib 一一对应（2026-08-02 已做引用核验）")
out.append("% ============================================================")
out.append("\\section{Related Work}")
out.append("")
out.append(convert_cites("\n".join(intro).strip()))
out.append("")

for title, body in sections.items():
    sid, sname = sec_id(title)
    sub = "subsection" if sid.count(".") >= 1 else "section"
    out.append(f"\\{sub}{{{title.replace(':', ' — ')}}}")
    out.append("")
    out.append(convert_cites("\n".join(body).strip()))
    out.append("")

target = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "relatedwork", "overleaf", "relatedwork.tex")
with open(target, "w", encoding="utf-8") as f:
    f.write("\n".join(out))
print("WROTE", os.path.abspath(target))
