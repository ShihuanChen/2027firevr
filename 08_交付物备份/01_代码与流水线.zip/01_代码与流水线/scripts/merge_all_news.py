#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
紧急合并所有现有新闻数据 -> 朱倩/data/高层火灾新闻总表_YYYYMMDD.csv
策略：尽可能多地保留记录，按标题+URL去重，保留最丰富的字段。
"""

import csv, json, hashlib, os, glob
from datetime import datetime
from collections import OrderedDict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(ROOT, "data")
TODAY = datetime.now().strftime("%Y%m%d")
OUT_PATH = os.path.join(OUT_DIR, f"高层火灾新闻总表_{TODAY}.csv")

# 统一字段（兼容所有来源）
FIELDS = [
    "title", "url", "source", "published_at", "language",
    "content", "fetch_status", "relevance_score", "relevance_tier",
    "screening_status", "origin_file", "notes"
]

def normalize_title(t):
    return t.strip().lower().replace(" ", "") if t else ""

def url_hash(url):
    return hashlib.sha256(url.strip().encode()).hexdigest()[:16]

def dedup_key(title, url):
    return url_hash(url) + "|" + normalize_title(title)[:60]

records = OrderedDict()  # dedup_key -> record

def add_record(rec, origin):
    key = dedup_key(rec.get("title", ""), rec.get("url", ""))
    if not rec.get("url") or not rec.get("title"):
        return
    existing = records.get(key)
    if existing:
        # 已有记录：优先保留有 content / screening_status / relevance_score 的
        if not existing.get("content") and rec.get("content"):
            existing["content"] = rec["content"]
        if not existing.get("screening_status") and rec.get("screening_status"):
            existing["screening_status"] = rec["screening_status"]
        if not existing.get("relevance_score") and rec.get("relevance_score"):
            existing["relevance_score"] = rec["relevance_score"]
        if not existing.get("relevance_tier") and rec.get("relevance_tier"):
            existing["relevance_tier"] = rec["relevance_tier"]
        if not existing.get("notes") and rec.get("notes"):
            existing["notes"] = rec["notes"]
        # 合并来源标记
        if origin not in existing.get("origin_file", ""):
            existing["origin_file"] += ";" + origin
    else:
        full = {f: "" for f in FIELDS}
        full.update(rec)
        full["origin_file"] = origin
        records[key] = full

# ── 1. 第三轮_含正文.csv (最成熟，有筛选结论) ──
rd3 = os.path.join(ROOT, "工作流", "第三轮_含正文.csv")
if os.path.exists(rd3):
    with open(rd3, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            add_record({
                "title": row.get("核心事件", "").strip('"'),
                "url": row.get("canonical_url", "").strip() or row.get("原始报道链接", "").strip(),
                "source": "",
                "published_at": "",
                "language": row.get("language", ""),
                "content": row.get("文本", ""),
                "fetch_status": row.get("fetch_status", ""),
                "relevance_score": row.get("relevance_score", ""),
                "relevance_tier": row.get("relevance_tier", ""),
                "screening_status": row.get("初筛结论", ""),
                "notes": row.get("备注", ""),
            }, "第三轮_含正文")
    print(f"[1] 第三轮_含正文.csv -> {len(records)} unique so far")

# ── 2. results_merged.csv ──
rm = os.path.join(ROOT, "results_merged.csv")
if os.path.exists(rm):
    with open(rm, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            add_record({
                "title": row.get("title", ""),
                "url": row.get("url", ""),
                "source": row.get("source", ""),
                "published_at": row.get("published_at", ""),
                "language": row.get("language", ""),
                "content": row.get("content", ""),
            }, "results_merged")
    print(f"[2] results_merged.csv -> {len(records)} unique so far")

# ── 3. results_playwright.csv ──
rpw = os.path.join(ROOT, "results_playwright.csv")
if os.path.exists(rpw):
    with open(rpw, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            add_record({
                "title": row.get("title", ""),
                "url": row.get("url", ""),
                "source": row.get("source", ""),
                "published_at": row.get("published_at", ""),
                "language": row.get("language", ""),
                "content": row.get("content", ""),
            }, "results_playwright")
    print(f"[3] results_playwright.csv -> {len(records)} unique so far")

# ── 4. results_playwright_more.csv ──
rpwm = os.path.join(ROOT, "results_playwright_more.csv")
if os.path.exists(rpwm):
    with open(rpwm, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            add_record({
                "title": row.get("title", ""),
                "url": row.get("url", ""),
                "source": row.get("source", ""),
                "published_at": row.get("published_at", ""),
                "language": row.get("language", ""),
                "content": row.get("content", ""),
            }, "results_playwright_more")
    print(f"[4] results_playwright_more.csv -> {len(records)} unique so far")

# ── 5. global_high_rise_fire_details_20260624.csv ──
gf = os.path.join(ROOT, "global_high_rise_fire_details_20260624.csv")
if os.path.exists(gf):
    with open(gf, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            add_record({
                "title": row.get("Title", ""),
                "url": row.get("URL", ""),
                "source": row.get("Source", ""),
                "published_at": row.get("Publish_Date", ""),
                "language": "",
                "content": row.get("Full_Content", ""),
            }, "global_high_rise_fire_details")
    print(f"[5] global_high_rise_fire_details -> {len(records)} unique so far")

# ── 6. results_2015~2026.csv ──
year_files = sorted(glob.glob(os.path.join(ROOT, "results_20*.csv")))
for yf in year_files:
    base = os.path.basename(yf)
    with open(yf, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        count = 0
        for row in reader:
            add_record({
                "title": row.get("title", ""),
                "url": row.get("url", ""),
                "source": row.get("source", ""),
                "published_at": row.get("published_at", ""),
                "language": row.get("language", ""),
                "content": row.get("content", ""),
            }, base)
            count += 1
    print(f"[6] {base} ({count} rows) -> {len(records)} unique so far")

# ── 7. v4 progress JSON (452条URL，content可能为空) ──
v4json = os.path.join(ROOT, "data", "collect_progress_v4.json")
if os.path.exists(v4json):
    with open(v4json, "r", encoding="utf-8") as f:
        data = json.load(f)
    collected = data.get("collected", {})
    for k, v in collected.items():
        add_record({
            "title": v.get("title", ""),
            "url": v.get("url", ""),
            "source": v.get("media", ""),
            "published_at": v.get("time", ""),
            "language": "",
            "content": v.get("content", ""),
        }, "collect_progress_v4")
    print(f"[7] collect_progress_v4.json ({len(collected)} entries) -> {len(records)} unique so far")

# ── 写入总表 ──
with open(OUT_PATH, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=FIELDS)
    writer.writeheader()
    for rec in records.values():
        writer.writerow(rec)

# ── 统计 ──
print("\n" + "="*60)
print("OK 总表已输出: " + OUT_PATH)
print("   去重后总记录数: " + str(len(records)))

# 语言统计
lang_counts = {}
for r in records.values():
    l = r.get("language", "").lower() or "unknown"
    if l.startswith("zh"):
        l = "zh"
    elif l.startswith("en"):
        l = "en"
    else:
        l = "other"
    lang_counts[l] = lang_counts.get(l, 0) + 1
print("   语言分布: " + str(lang_counts))

# 筛选状态统计
screen_counts = {}
for r in records.values():
    s = r.get("screening_status", "").strip() or "未筛选"
    screen_counts[s] = screen_counts.get(s, 0) + 1
print("   筛选状态: " + str(screen_counts))

# 来源文件统计
origin_counts = {}
for r in records.values():
    for o in r.get("origin_file", "").split(";"):
        o = o.strip()
        if o:
            origin_counts[o] = origin_counts.get(o, 0) + 1
print("   各来源文件记录数:")
for o, c in sorted(origin_counts.items(), key=lambda x: -x[1]):
    print("      " + o + ": " + str(c))

print("="*60)

# 写入统计摘要
summary_path = os.path.join(OUT_DIR, "高层火灾新闻总表_" + TODAY + "_summary.txt")
with open(summary_path, "w", encoding="utf-8") as f:
    f.write("高层火灾新闻总表统计摘要\n")
    f.write("生成时间: " + TODAY + "\n")
    f.write("总记录数(去重): " + str(len(records)) + "\n")
    f.write("语言分布: " + str(lang_counts) + "\n")
    f.write("筛选状态: " + str(screen_counts) + "\n")
    f.write("\n各来源文件记录数:\n")
    for o, c in sorted(origin_counts.items(), key=lambda x: -x[1]):
        f.write("  " + o + ": " + str(c) + "\n")
print("OK 统计摘要: " + summary_path)
