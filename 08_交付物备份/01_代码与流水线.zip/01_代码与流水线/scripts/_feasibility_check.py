# -*- coding: utf-8 -*-
"""可行性验证：用真实数据跑通 TF-IDF + KMeans + committee 打分，证明管线可靠。"""
import csv, os, re, time, sys
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")

t0 = time.time()
rows = []
with open(SRC, encoding="utf-8") as f:
    reader = csv.reader(f)
    h = next(reader)
    for i, row in enumerate(reader):
        title = row[1] if len(row) > 1 else ""
        body = row[4] if len(row) > 4 else ""
        rows.append({"gid": i + 1, "title": title, "body": body or "", "L": len(body or "")})
print(f"读取 {len(rows)} 条, 用时 {time.time()-t0:.1f}s")

# 过滤（与 _ml_pipeline.py 相同的门槛）
df = [r for r in rows if r["L"] >= 400]
print(f"L>=400: {len(df)} 条")

# 抽样 800 条做快速验证（完整版不抽样）
sample = df[:800]
texts = [(r["title"] + " " + r["body"][:1000]).lower() for r in sample]

t1 = time.time()
vec = TfidfVectorizer(max_features=2000, ngram_range=(1, 2), min_df=3, max_df=0.8)
X = vec.fit_transform(texts)
print(f"TF-IDF: {X.shape[0]} x {X.shape[1]}, 用时 {time.time()-t1:.1f}s")

t2 = time.time()
for k in (10, 20, 30):
    km = KMeans(n_clusters=k, random_state=42, n_init="auto")
    labels = km.fit_predict(X)
    sc = silhouette_score(X, labels)
    print(f"  k={k}: silhouette={sc:.3f} ({time.time()-t2:.1f}s)")
    t2 = time.time()

# committee 演示：三把尺子对前 20 条打分
SCENE_W = ["楼梯","走廊","通道","阳台","窗口","浓烟","被困","trapped","尖叫","恐慌","轮椅","盲人","听障","老人","婴儿","扶着墙"]
PROC_W = ["消防员","救援","扑灭","灭火","送医","出动","responded","extinguished"]
PERSON_W = ["said","witness","survivor","victim","回忆","描述","幸存者","目击者"]

print("\n=== committee 三票演示（前 12 条）===")
for r in sample[:12]:
    t = (r["title"] + " " + r["body"][:2000]).lower()
    v1_scene = sum(1 for w in SCENE_W if w in t)
    v1_proc = sum(1 for w in PROC_W if w in t)
    v1_person = sum(1 for w in PERSON_W if w in t)
    # 票1: v1 关键词启发式（scene>=4 且比例>=0.25 → 待复核）
    ratio = v1_scene / (v1_scene + v1_proc + 1)
    vote1 = "keep?" if (v1_scene >= 4 and ratio >= 0.25) else "drop"
    # 票2: 长度启发式
    vote2 = "keep?" if r["L"] >= 4000 else ("mid" if r["L"] >= 1500 else "drop")
    # 票3: 弱势群体 + 人物
    vg = sum(1 for w in ["轮椅","盲人","聋","听障","老人","残疾","孕妇","婴儿"] if w in t)
    vote3 = "keep?" if (vg >= 1 and v1_person >= 1) else "drop"
    disagree = len({vote1, vote2, vote3})
    print(f"  gid{r['gid']:>5} L={r['L']:>5} 票[{vote1}/{vote2}/{vote3}] 分歧度={disagree}  {r['title'][:40]}")
print(f"\n总用时 {time.time()-t0:.1f}s — 管线可跑通")
