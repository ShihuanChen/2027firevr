#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
补抓缺失正文 v2 — 强化版
策略升级：
  1. 多UA轮换 + Referer伪装
  2. trafilatura 正文提取（比纯正则强）
  3. 失败后尝试 Wayback Machine 存档
  4. 指数退避重试（最多3次）
  5. 并发+限速控制
"""
import csv, os, time, re, random, hashlib
import concurrent.futures
import requests
from datetime import datetime

try:
    import trafilatura
    HAS_TRAFILATURA = True
except ImportError:
    HAS_TRAFILATURA = False
    print("[WARN] trafilatura 未安装，将使用简单正则提取。建议: pip install trafilatura")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT  = os.path.join(ROOT, "data", "高层火灾_第二轮打标_20260701.csv")
TODAY  = datetime.now().strftime("%Y%m%d")
OUTPUT = os.path.join(ROOT, "data", f"高层火灾_补充正文_v2_{TODAY}.csv")

# === User-Agent 池 ===
UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    # 移动端UA（有些站点对移动端友好）
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36",
]

def random_headers(url=""):
    """生成随机请求头"""
    ua = random.choice(UA_POOL)
    domain = ""
    try:
        from urllib.parse import urlparse
        domain = f"https://{urlparse(url).netloc}"
    except:
        pass
    return {
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
        "Accept-Encoding": "gzip, deflate",
        "Referer": domain or "https://www.google.com/",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }

def extract_text_trafilatura(html, url=""):
    """使用 trafilatura 提取正文"""
    if not HAS_TRAFILATURA:
        return None
    try:
        text = trafilatura.extract(html, include_comments=False, include_tables=False,
                                    no_fallback=False, favor_precision=True)
        if text and len(text) > 100:
            return text[:5000]
    except:
        pass
    return None

def extract_text_regex(html):
    """备用正则提取"""
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.S | re.I)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.S | re.I)
    # 尝试提取 article/main 标签内容
    article = re.search(r'<(?:article|main|div[^>]*class="?[^"]*content[^"]*"?)[^>]*>(.*?)</(?:article|main|div)>', html, re.S | re.I)
    if article:
        html = article.group(1)
    text = re.sub(r'<[^>]+>', ' ', html)
    text = re.sub(r'&nbsp;|&amp;|&lt;|&gt;|&quot;', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    lines = [l.strip() for l in text.split('.') if len(l.strip()) > 20]
    return '. '.join(lines[:50])

def extract_text(html, url=""):
    """正文提取：trafilatura 优先，正则备用"""
    if HAS_TRAFILATURA:
        result = extract_text_trafilatura(html, url)
        if result:
            return result
    return extract_text_regex(html)

def fetch_wayback(url):
    """尝试从 Wayback Machine 获取存档"""
    try:
        wayback_api = f"https://archive.org/wayback/available?url={url}"
        resp = requests.get(wayback_api, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            snapshots = data.get("archived_snapshots", {})
            if snapshots and "closest" in snapshots:
                archive_url = snapshots["closest"]["url"]
                arc_resp = requests.get(archive_url, headers=random_headers(url), timeout=30)
                if arc_resp.status_code == 200:
                    return extract_text(arc_resp.text, url)
    except:
        pass
    return None

def fetch_one(row, session, retry_count=0):
    """抓取单条，含重试逻辑"""
    url = row.get("url", "").strip()
    if not url or not url.startswith("http"):
        return {**row, "content": "", "fetch_status_v2": "bad_url", "round2_status": "v2-bad_url"}

    try:
        resp = session.get(url, headers=random_headers(url), timeout=25, allow_redirects=True)

        if resp.status_code == 200:
            text = extract_text(resp.text, url)
            if text and len(text) > 150:
                return {**row, "content": text[:5000], "fetch_status_v2": "v2_ok", "round2_status": "v2-抓取成功"}
            elif text and len(text) > 50:
                # 正文偏短，尝试wayback
                if retry_count < 1:
                    wb = fetch_wayback(url)
                    if wb and len(wb) > 150:
                        return {**row, "content": wb[:5000], "fetch_status_v2": "v2_wayback_ok", "round2_status": "v2-Wayback成功"}
                return {**row, "content": text, "fetch_status_v2": "v2_short", "round2_status": "v2-正文过短"}
            else:
                # 几乎没提取到正文
                if retry_count < 1:
                    wb = fetch_wayback(url)
                    if wb and len(wb) > 100:
                        return {**row, "content": wb[:5000], "fetch_status_v2": "v2_wayback_ok", "round2_status": "v2-Wayback成功"}
                return {**row, "content": text or "", "fetch_status_v2": "v2_empty", "round2_status": "v2-正文为空"}

        elif resp.status_code in (403, 451):
            # 被屏蔽，尝试wayback
            if retry_count < 1:
                wb = fetch_wayback(url)
                if wb and len(wb) > 100:
                    return {**row, "content": wb[:5000], "fetch_status_v2": "v2_wayback_ok", "round2_status": "v2-Wayback成功(blocked)"}
            return {**row, "fetch_status_v2": "v2_blocked", "round2_status": "v2-blocked"}

        elif resp.status_code == 429:
            time.sleep(5 + random.random() * 5)
            if retry_count < 2:
                return fetch_one(row, session, retry_count + 1)
            return {**row, "fetch_status_v2": "v2_429", "round2_status": "v2-限流"}

        else:
            if retry_count < 1 and resp.status_code >= 500:
                time.sleep(2 + random.random() * 3)
                return fetch_one(row, session, retry_count + 1)
            return {**row, "fetch_status_v2": f"v2_http{resp.status_code}", "round2_status": f"v2-HTTP{resp.status_code}"}

    except requests.exceptions.Timeout:
        if retry_count < 2:
            time.sleep(3)
            return fetch_one(row, session, retry_count + 1)
        return {**row, "fetch_status_v2": "v2_timeout", "round2_status": "v2-timeout"}

    except Exception as e:
        if retry_count < 1:
            time.sleep(2)
            return fetch_one(row, session, retry_count + 1)
        return {**row, "fetch_status_v2": f"v2_error:{str(e)[:60]}", "round2_status": "v2-error"}

def main():
    print("=" * 60)
    print(" 补抓缺失正文 v2（强化版）")
    print(" 策略: 多UA + trafilatura提取 + Wayback回退 + 重试")
    print("=" * 60)

    with open(INPUT, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        all_rows = list(reader)

    # 分类
    already_ok = []
    to_refetch = []
    perm_fail = []

    for r in all_rows:
        fs = (r.get("fetch_status") or "").strip().lower()
        content = (r.get("content") or "").strip()

        # 已有质量正文
        if content and len(content) > 100 and not content.startswith("error:") and not content.startswith("We're Sorry"):
            already_ok.append(r)
            continue

        # 永久失败
        if "blocked" in fs or "451" in fs or "403" in fs:
            perm_fail.append(r)
            continue

        # 可重试
        to_refetch.append(r)

    print(f"\n总记录: {len(all_rows)}")
    print(f"已有正文(跳过): {len(already_ok)}")
    print(f"永久失败(跳过): {len(perm_fail)}")
    print(f"可重试: {len(to_refetch)}")

    if not to_refetch:
        print("无需重试。")
        return

    # 限流：每批最多600条，每批间隔
    BATCH_SIZE = 600
    batch = to_refetch[:BATCH_SIZE]
    print(f"本批抓取: {len(batch)} 条 (最多{BATCH_SIZE})")

    session = requests.Session()
    results = []
    new_content = 0

    # 8并发 + 请求间隔
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {}
        for i, row in enumerate(batch):
            # 错开发送，降低被ban概率
            time.sleep(0.05)
            fut = executor.submit(fetch_one, row, session)
            futures[fut] = i

        for fut in concurrent.futures.as_completed(futures):
            try:
                row = fut.result()
                results.append(row)
                if "v2-抓取成功" in str(row.get("round2_status", "")) or "v2-Wayback" in str(row.get("round2_status", "")):
                    new_content += 1
                if len(results) % 30 == 0:
                    print(f"  进度: {len(results)}/{len(batch)}, 新获正文: {new_content}")
            except Exception as e:
                idx = futures[fut]
                results.append({**batch[idx], "fetch_status_v2": f"v2_exception:{str(e)[:60]}", "round2_status": "v2-exception"})

    # 合并输出
    final = already_ok + perm_fail + results
    # 加上超出的未处理记录
    if len(to_refetch) > BATCH_SIZE:
        for r in to_refetch[BATCH_SIZE:]:
            r["fetch_status_v2"] = "v2_unprocessed"
            final.append(r)

    fieldnames = list(all_rows[0].keys())
    # 确保新列存在
    for f in ["fetch_status_v2"]:
        if f not in fieldnames:
            fieldnames.append(f)

    with open(OUTPUT, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(final)

    print(f"\n{'='*40}")
    print(f"[DONE] New content: {new_content}/{len(batch)}")
    print(f"       Total output: {len(final)} records")
    print(f"       File: {OUTPUT}")
    print(f"{'='*40}")

if __name__ == "__main__":
    main()
