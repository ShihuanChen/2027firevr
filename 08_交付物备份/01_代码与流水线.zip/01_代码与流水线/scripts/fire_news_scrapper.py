import feedparser
import pandas as pd
import urllib.parse
from datetime import datetime, timedelta
import time
import trafilatura

def generate_month_chunks(start_year, end_year):
    """
    生成按月划分的时间段，用于突破单次100条的限制
    """
    chunks = []
    start_date = datetime(start_year, 1, 1)
    end_date = datetime(end_year, 12, 31)
    
    current = start_date
    while current < end_date:
        next_month = current + timedelta(days=32)
        next_month = datetime(next_month.year, next_month.month, 1)
        
        after_str = current.strftime("%Y-%m-%d")
        before_str = (next_month - timedelta(days=1)).strftime("%Y-%m-%d")
        
        chunks.append((after_str, before_str))
        current = next_month
    return chunks

def fetch_rss_links(query, hl, gl, ceid, after, before):
    """
    结合时间区间的高级搜索
    """
    # 注入时间语法: "关键词 after:2025-01-01 before:2025-01-31"
    advanced_query = f'{query} after:{after} before:{before}'
    encoded_query = urllib.parse.quote_plus(advanced_query)
    rss_url = f"https://news.google.com/rss/search?q={encoded_query}&hl={hl}&gl={gl}&ceid={ceid}"
    
    feed = feedparser.parse(rss_url)
    articles = []
    for entry in feed.entries:
        articles.append({
            "Title": entry.get("title", ""),
            "URL": entry.get("link", ""),
            "Publish_Date": entry.get("published", ""),
            "Source": entry.get("source", {}).get("title", ""),
            "Region": gl
        })
    return articles

def extract_content(url):
    try:
        downloaded = trafilatura.fetch_url(url)
        if downloaded is None: return "无法下载"
        content = trafilatura.extract(downloaded, include_comments=False)
        return content.strip() if content else "未识别到正文"
    except Exception:
        return "抓取失败"

def main():
    # 1. 扩充更全面的全球关键词池，捕捉所有高楼火灾变体
    keywords_en = '"high-rise fire" OR "skyscraper fire" OR "apartment building fire" OR "tower block fire" OR "high-rise building blaze"'
    keywords_zh = '"高层火灾" OR "高楼火灾" OR "住宅楼火灾" OR "高层建筑起火"'
    
    # 2. 生成 2023 年到 2026 年的所有月份区间
    month_chunks = generate_month_chunks(2023, 2026)
    print(f"📅 已将检索时间轴切分为 {len(month_chunks)} 个月份片段进行深度横扫...")
    
    all_news_meta = []
    
    # 3. 开始时光穿梭式捞取目录
    for after, before in month_chunks:
        print(f"\n🚀 正在捞取时段: {after} 至 {before} ...")
        
        # 搜英文源
        try:
            en_res = fetch_rss_links(keywords_en, "en-US", "US", "US:en", after, before)
            all_news_meta.extend(en_res)
            print(f"  [美区英文] 捞到 {len(en_res)} 条")
        except Exception: pass
        
        # 搜中文源
        try:
            zh_res = fetch_rss_links(keywords_zh, "zh-CN", "CN", "CN:zh", after, before)
            all_news_meta.extend(zh_res)
            print(f"  [中国中文] 捞到 {len(zh_res)} 条")
        except Exception: pass
        
        time.sleep(1) # 防护频率

    if not all_news_meta:
        print("😭 未捞到任何元数据，请检查网络。")
        return

    # 4. 强力智能清洗去重
    df = pd.DataFrame(all_news_meta)
    df['Title_Clean'] = df['Title'].apply(lambda x: str(x)[:25].strip().lower())
    df = df.drop_duplicates(subset=["Title_Clean"], keep="first")
    df = df.drop_duplicates(subset=["URL"], keep="first").reset_index(drop=True)
    df = df.drop(columns=['Title_Clean'])
    
    total_count = len(df)
    print("\n" + "="*50)
    print(f"🧼 历史元数据横扫去重完成！")
    print(f"📊 成功帮您过滤并锁定了 {total_count} 条独立新闻目录！")
    print("="*50)

    # 5. 开始攻坚抓取正文 (因为数据过千，这里做断点保存设计)
    print("\n⚡ 开始深度攻坚，下载这1000+条新闻的全文内容（可能需要半小时左右，请保持网络畅通）...")
    
    full_contents = []
    for idx, row in df.iterrows():
        url = row["URL"]
        print(f"📥 [{idx + 1}/{total_count}] 正在拔取正文: {row['Title'][:20]}...")
        
        text = extract_content(url)
        full_contents.append(text)
        
        # 频繁高压抓取容易被网站封IP，为了保证能稳稳拿满1000条，这里设置1秒间隔
        time.sleep(1) 
        
        # 每抓 100 条在后台自动备份一次，防止中途断网竹篮打水
        if (idx + 1) % 100 == 0:
            df_temp = df.iloc[:idx+1].copy()
            df_temp["Full_Content"] = full_contents
            df_temp.to_csv("backup_fire_news.csv", index=False, encoding="utf-8-sig")
            print(f"💾 进度备份：前 {idx + 1} 条已安全备份至 backup_fire_news.csv")

    # 6. 完工合并落地
    df["Full_Content"] = full_contents
    output_filename = f"global_fire_news_1000plus_{datetime.now().strftime('%Y%m%d')}.csv"
    df.to_csv(output_filename, index=False, encoding="utf-8-sig")
    
    print("\n" + "🎉"*10)
    print(f"🏆 壮举完成！已成功为您构建包含 URL、发布媒体和正文全文的千条级火灾大数据库！")
    print(f"💾 最终成果请查收: {output_filename}")

if __name__ == "__main__":
    main()