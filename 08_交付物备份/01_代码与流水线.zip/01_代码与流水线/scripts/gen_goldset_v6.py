# -*- coding: utf-8 -*-
"""
v5 最终版：人工复核修正（误伤改回 + 漏网补剔），生成最终待判表。
用户只需扫"建议=0"的确认，精判"建议=空"的。
"""
import openpyxl, re

V5_XLSX = r"C:\Users\Administrator\Desktop\_goldset_v5_待判.xlsx"
OUT_XLSX = r"C:\Users\Administrator\Desktop\_goldset_v6_最终待判.xlsx"

# 读取 v5
wb = openpyxl.load_workbook(V5_XLSX, read_only=True, data_only=True)
ws = wb.active
rows = []
for i, row in enumerate(ws.iter_rows(values_only=True)):
    if i == 0:
        continue
    rows.append(list(row))
print(f"v5 共 {len(rows)} 条")

# 人工复核修正表
# 误伤（真实火灾/有价值，改回需判断）：gid -> 修正说明
FIX_TO_KEEP = {
    4809: "德国公寓火灾(Feuer bricht in Wohnhaus)，真实火灾，误伤",
    1471: "德里仓库大火(blaze engulfs warehouse)，真实火灾，误伤",
    7437: "消防员防护装备短缺报道，有调查价值，误伤",
    7345: "香港官方警告承包商消防风险，火灾后续，误伤",
    1944: "Grenfell 纪念活动，真实火灾主题",
}
# 漏网（明显无关，补剔）：gid -> 理由
FIX_TO_DROP = {
    6117: "党政宣传(大调研我们在行动)",
    6688: "乌克兰战争日志(非火灾)",
    3945: "新闻汇总(nattens viktigste)",
    5592: "希腊语飞机坠落(非建筑火灾)",
    7371: "建筑技术(竹脚手架)",
    5738: "政论(香港人视角分析)",
    4809: None,  # placeholder
}

# 应用修正
sugg_map = {}
for r in rows:
    gid = r[0]
    sug, why = str(r[5]), str(r[6] or "")
    if gid in FIX_TO_KEEP:
        sug, why = "", FIX_TO_KEEP[gid]
    if gid in FIX_TO_DROP and FIX_TO_DROP[gid]:
        sug, why = "0", FIX_TO_DROP[gid]
    sugg_map[gid] = (sug, why)

# 生成最终表
wb2 = openpyxl.Workbook()
ws2 = wb2.active
ws2.title = "待判"
ws2.append(["编号", "标题", "字数", "正文(前2000)", "建议", "理由", "最终判定(1保留/0剔除)"])
n_auto = 0
n_manual = 0
for r in rows:
    gid, title, L, feat, body = r[0], r[1], r[2], r[3], r[4]
    sug, why = sugg_map[gid]
    if sug == "0":
        n_auto += 1
    else:
        n_manual += 1
    ws2.append([gid, title[:80], L, str(body)[:2000], sug, why, ""])
wb2.save(OUT_XLSX)

print(f"建议剔除(只需扫一眼确认): {n_auto}")
print(f"需精判: {n_manual}")
print(f"输出: {OUT_XLSX}")

print("\n=== 需精判清单（{n_manual} 条）===".format(n_manual=n_manual))
for r in rows:
    gid = r[0]
    sug, why = sugg_map[gid]
    if not sug:
        print(f"  gid{gid:>6} L={r[2]:>5} {str(r[1])[:55]}")
