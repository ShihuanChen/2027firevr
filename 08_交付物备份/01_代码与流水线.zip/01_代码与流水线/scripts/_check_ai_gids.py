# -*- coding: utf-8 -*-
"""核对其他 AI 给出的高细节 gid：我们的 Grok 判定是什么？是否被漏掉？"""
import csv, os, re

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

# 其他 AI 提供的 gid 集合（从用户消息提取）
ai_gids = {
    # 42 条表
    104, 133, 143, 170, 190, 208, 222, 240, 249, 415,
    454, 455, 531, 537, 538, 5750, 5751, 5756, 5759, 5760,
    5762, 5767, 5782, 5786, 5791, 5798, 2976, 3085, 3115, 3801,
    3823, 3975, 4046, 4135, 4346, 4353, 4343, 4440, 4443, 5105,
    5111, 7910,
    # 补充细节
    7904, 7908, 5619, 7266, 7293, 7295, 7880, 4230, 1500, 4059,
    1790, 4006, 4002, 3999, 4004, 235, 5204, 7875, 178, 3532,
}
print(f"其他 AI 提供的 gid 数: {len(ai_gids)}")

# 我们的全量判定
judg = {}
with open(os.path.join(D, "_全量_grok判定.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        judg[int(r["gid"])] = (r["grok判定"], r["标题"][:70])

# 用户已判金标准
user_lab = {}
with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        user_lab[int(r["gid"])] = int(r["label"])

# 分类
in_K = []
in_D = []  # 被我们漏掉的！
in_E = []
not_found = []
user_keep = []
user_drop = []

for g in sorted(ai_gids):
    if g not in judg:
        not_found.append(g)
        continue
    j, t = judg[g]
    if g in user_lab:
        tag = f"用户判{user_lab[g]}"
    else:
        tag = ""
    if j == "K":
        in_K.append((g, t, tag))
    elif j == "D":
        in_D.append((g, t, tag))
    else:
        in_E.append((g, t, tag))

print(f"\n=== 在我们的路由表 K 中（OK）: {len(in_K)} ===")
for g, t, tag in in_K:
    print(f"  gid{g:>6} [{tag}] {t}")

print(f"\n=== 被我们判 D（漏掉!）: {len(in_D)} ===")
for g, t, tag in in_D:
    print(f"  gid{g:>6} [{tag}] {t}")

print(f"\n=== E 错误: {len(in_E)} ===")
for g, t, tag in in_E:
    print(f"  gid{g:>6} [{tag}] {t}")

print(f"\n=== 不在判定文件中: {len(not_found)} ===")
print(f"  {sorted(not_found)}")
