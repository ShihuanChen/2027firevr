# -*- coding: utf-8 -*-
"""读取 v4 78条交付表的用户标注（1=保留，空白=0剔除）。"""
import openpyxl
from collections import Counter

p = r"C:\Users\Administrator\Desktop\_批量试跑v4_78条交付.xlsx"
wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
ws = wb.active
rows = []
for i, row in enumerate(ws.iter_rows(values_only=True)):
    if i == 0 or row[0] is None:
        continue
    rows.append(list(row))
print(f"总条数: {len(rows)}")
print(f"列: {[c.value for c in wb.active[1]]}")

def clean(v):
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("none", "nan", "-") else s

anno = {}
for r in rows:
    gid = int(r[0])
    v = clean(r[4]) if len(r) > 4 else ""
    if v:
        anno[gid] = v
    else:
        anno[gid] = "0"  # 空白 = 0

print(f"\n标注分布: {dict(Counter(anno.values()))}")

keeps = [g for g, v in anno.items() if v == "1"]
drops = [g for g, v in anno.items() if v == "0"]
print(f"保留(1): {len(keeps)} | 剔除(0): {len(drops)}")

print("\n=== 用户标 1（保留）的条目 ===")
for r in rows:
    gid = int(r[0])
    if anno[gid] == "1":
        print(f"  gid{gid:>6} L={r[2]:>6} {str(r[1])[:60]}")

# 保存合并结果
import csv, os
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
with open(os.path.join(D, "_v4_用户标注.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["gid", "label", "title"])
    for r in rows:
        gid = int(r[0])
        w.writerow([gid, anno[gid], str(r[1])[:80]])
print(f"\n已保存 _v4_用户标注.csv")
