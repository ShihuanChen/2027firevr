"""
高层火灾新闻收集脚本 v4（修正版）
===================================
v3问题：GDELT中 "tower" 匹配通信塔、"fire" 匹配交火/火力，产生大量军事新闻假阳性。
v4修复：
  1. GDELT查询用严格短语匹配，废弃裸词 "tower"
  2. 内容级过滤：检查GDELT返回的snippet/标题，非火灾→直接丢弃
  3. Google News RSS作为主力数据源（标题级搜索更精准）
  4. 输出移到 朱倩/data/ 目录

依赖: pip install requests trafilatura feedparser beautifulsoup4 lxml

用法:
  python collect_fire_news_v4.py                    # 完整收集
  python collect_fire_news_v4.py --target 1000       # 目标1000条
  python collect_fire_news_v4.py --urls-only         # 只收集URL
  python collect_fire_news_v4.py --reset             # 重置进度
  python collect_fire_news_v4.py --workers 16        # 并行抓正文
"""

import argparse, csv, hashlib, json, os, re, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse, parse_qs, quote_plus, unquote

# Windows GBK 兜底
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import requests

try:
    import trafilatura; HAS_TRAFILATURA = True
except ImportError:
    HAS_TRAFILATURA = False; print("⚠ trafilatura 未安装")

try:
    import feedparser; HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False; print("⚠ feedparser 未安装")

try:
    from bs4 import BeautifulSoup; HAS_BS4 = True
except ImportError:
    HAS_BS4 = False

# ========== 路径配置 ==========
BASE_DIR = Path(__file__).resolve().parent.parent  # 朱倩/
OUTPUT_CSV = BASE_DIR / "data" / "高层火灾新闻收集_v4.csv"
PROGRESS_FILE = BASE_DIR / "data" / "collect_progress_v4.json"
TARGET_COUNT = 1000

# 确保输出目录存在
OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)

# ========== GDELT 配置 ==========
GDELT_ENDPOINT = "https://api.gdeltproject.org/api/v2/doc/doc"
GDELT_MIN_INTERVAL = 6.5
_last_gdelt_call = [0.0]

def _gdelt_throttle():
    elapsed = time.monotonic() - _last_gdelt_call[0]
    if elapsed < GDELT_MIN_INTERVAL:
        time.sleep(GDELT_MIN_INTERVAL - elapsed)
    _last_gdelt_call[0] = time.monotonic()

# ========== UA 池 ==========
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
]

def rand_headers():
    import random
    return {"User-Agent": random.choice(USER_AGENTS)}

# ========== v4 关键修复：严格关键词与过滤 ==========

# --- GDELT 查询：只用精确短语，废弃裸词 "tower" ---
GDELT_QUERIES_STRICT = [
    # 英文精确短语（避免 "missile fire" + "telecom tower" 假阳性）
    '"high-rise fire" OR "high rise fire" OR "highrise fire"',
    '"apartment building fire" OR "apartment tower fire" OR "apartment complex fire"',
    '"residential building fire" OR "residential tower fire" OR "residential high-rise fire"',
    '"tower block fire" OR "tower block blaze"',
    '"skyscraper fire" OR "skyscraper blaze" OR "high-rise blaze"',
    '"building fire" evacuation residents',
    '"Grenfell Tower" fire',
    '(fire OR blaze) "story building" OR "storey building" OR "floor building"',
    # 中文
    '高层火灾 OR 高楼火灾 OR 高层建筑火灾 OR 高层住宅火灾',
    '住宅楼火灾 OR 公寓火灾 OR 大厦火灾 OR 居民楼火灾',
    '火灾 高层 疏散 OR 逃生 OR 被困',
    '火灾 高层 死亡 OR 伤亡',
]

# --- Google News RSS 关键词（主力源） ---
GN_QUERIES_EN = '"high-rise fire" OR "skyscraper fire" OR "apartment building fire" OR "tower block fire" OR "high rise fire" OR "high-rise apartment fire" OR "residential high-rise fire"'
GN_QUERIES_ZH = '"高层火灾" OR "高楼火灾" OR "住宅楼火灾" OR "高层建筑起火" OR "高层楼房火灾" OR "高层建筑火灾" OR "高楼大火"'
# 补充细化中文搜索
GN_QUERIES_ZH_2 = '"住宅楼火灾" OR "居民楼火灾" OR "公寓火灾" OR "大厦起火" OR "高层住宅着火"'
GN_QUERIES_ZH_3 = '"Grenfell" 火灾 OR "格伦费尔" 火灾 OR "宏福苑" 火灾 OR "高层火灾" 逃生'

# --- 内容级排除词（检查标题+snippet，v4增强版） ---
REL_EXCLUDE_TITLE = re.compile(
    r'wildfire|bushfire|forest\s+fire|gunfire|fire\s*arm|'
    r'ceasefire|"under\s+fire"|fire\s+sale|exchange.*fire|'
    r'opened\s+fire|return\s+fire|missile\s+fire|drone\s+fire|'
    r'under\s+fire|shelling|artillery\s+fire|mortar\s+fire|'
    r'开火|炮火|山火|森林大火|交火|火遮眼|烽火|战火|枪火',
    re.I
)

# 标题必须包含至少一个火灾建筑关键词
REL_MUST_HAVE_FIRE = re.compile(
    r'high.?rise\s+fire|apartment\s+fire|building\s+fire|'
    r'skyscraper\s+fire|tower\s+block\s+fire|residential\s+fire|'
    r'house\s+fire|flat\s+fire|condo\s+fire|'
    r'高层火灾|高楼火灾|住宅楼火灾|公寓火灾|大厦火灾|'
    r'居民楼火灾|建筑火灾|高层建筑火灾|楼房火灾|'
    r'Grenfell|格伦费尔|宏福苑.*火|高层.*起火|高层.*大火|'
    r'blaze.*building|building.*blaze|inferno.*building|'
    r'\d+.*dead.*fire|\d+.*killed.*fire|fire.*\d+.*dead|'
    r'fire.*killed.*\d+|dies.*fire|deadly.*fire|fatal.*fire',
    re.I
)

SKIP_DOMAINS = {
    "youtube.com", "youtu.be", "tiktok.com", "instagram.com",
    "facebook.com", "twitter.com", "x.com", "linkedin.com",
    "v.qq.com", "bilibili.com", "ixigua.com", "douyin.com",
    "pinterest.com", "reddit.com",
}

def normalize_url(url):
    skip = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_content',
            'fbclid', 'gclid', 'msclkid', 'ref', 'src'}
    try:
        p = urlparse(url)
        q = parse_qs(p.query, keep_blank_values=True)
        q = {k: v for k, v in q.items() if k.lower() not in skip}
        if q:
            query = '&'.join(f"{k}={v[0]}" for k, v in q.items())
            return f"{p.scheme}://{p.netloc}{p.path}?{query}".lower()
        return f"{p.scheme}://{p.netloc}{p.path}".lower()
    except:
        return url.lower()

def url_hash(url):
    return hashlib.md5(url.strip().lower().encode()).hexdigest()

def domain(u):
    try: return urlparse(u).netloc.lower().replace("www.", "")
    except: return ""

def is_valid_url(u):
    if not u or not u.startswith("http"): return False
    d = domain(u)
    if any(s in d for s in SKIP_DOMAINS): return False
    if len(u) < 25: return False
    return True

def is_relevant_fire(title, snippet=""):
    """v4核心修复：严格判断是否为建筑火灾新闻"""
    blob = f"{title} {snippet}"
    # 1. 排除词命中 → 直接丢弃
    if REL_EXCLUDE_TITLE.search(blob):
        return False
    # 2. 必须命中火灾+建筑关键词
    if not REL_MUST_HAVE_FIRE.search(blob):
        return False
    return True

# ========== GDELT（修正版）==========

def gdelt_search(query, start_dt, end_dt, max_records=250, retries=4):
    """GDELT检索（v4增加snippet字段）"""
    params = {
        'query': query,
        'mode': 'ArtList',
        'format': 'json',
        'maxrecords': min(max_records, 250),
        'startdatetime': start_dt.strftime('%Y%m%d%H%M%S'),
        'enddatetime': end_dt.strftime('%Y%m%d%H%M%S'),
        'sort': 'DateDesc',
        'sourcelang': 'eng',  # 先英文
    }
    backoff = GDELT_MIN_INTERVAL
    for attempt in range(retries):
        _gdelt_throttle()
        try:
            r = requests.get(GDELT_ENDPOINT, params=params, timeout=30,
                             headers={'User-Agent': 'Mozilla/5.0 (research bot)'})
            body = r.text.strip()
            if r.status_code == 429 or body.startswith('Please limit'):
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            if r.status_code == 200 and body.startswith('{'):
                try:
                    data = r.json()
                    articles = data.get('articles', [])
                    # v4: 立即用内容级过滤检查每条
                    filtered = []
                    for art in articles:
                        title = art.get('title', '')
                        snippet = art.get('snippet', '') or art.get('seendate', '')
                        if is_relevant_fire(title, snippet):
                            filtered.append(art)
                    return filtered
                except json.JSONDecodeError:
                    time.sleep(backoff)
                    continue
            else:
                time.sleep(backoff)
        except requests.RequestException:
            time.sleep(backoff)
    return []

# 中文GDELT搜索
def gdelt_search_cn(query, start_dt, end_dt, max_records=250, retries=4):
    params = {
        'query': query,
        'mode': 'ArtList',
        'format': 'json',
        'maxrecords': min(max_records, 250),
        'startdatetime': start_dt.strftime('%Y%m%d%H%M%S'),
        'enddatetime': end_dt.strftime('%Y%m%d%H%M%S'),
        'sort': 'DateDesc',
        'sourcelang': 'cmn',  # 中文
    }
    backoff = GDELT_MIN_INTERVAL
    for attempt in range(retries):
        _gdelt_throttle()
        try:
            r = requests.get(GDELT_ENDPOINT, params=params, timeout=30,
                             headers={'User-Agent': 'Mozilla/5.0 (research bot)'})
            body = r.text.strip()
            if r.status_code == 429 or body.startswith('Please limit'):
                time.sleep(backoff)
                backoff = min(backoff * 2, 60)
                continue
            if r.status_code == 200 and body.startswith('{'):
                try:
                    data = r.json()
                    articles = data.get('articles', [])
                    filtered = []
                    for art in articles:
                        title = art.get('title', '')
                        snippet = art.get('snippet', '') or ''
                        if is_relevant_fire(title, snippet):
                            filtered.append(art)
                    return filtered
                except json.JSONDecodeError:
                    time.sleep(backoff)
                    continue
            else:
                time.sleep(backoff)
        except requests.RequestException:
            time.sleep(backoff)
    return []

# ========== Google News RSS（主力数据源）==========

def generate_month_chunks(start_year=2018):
    chunks = []
    start = datetime(start_year, 1, 1)
    end = datetime.now()
    current = start
    while current < end:
        if current.month == 12:
            next_month = datetime(current.year + 1, 1, 1)
        else:
            next_month = datetime(current.year, current.month + 1, 1)
        if next_month > end:
            next_month = end
        after = current.strftime("%Y-%m-%d")
        before = (next_month - timedelta(days=1)).strftime("%Y-%m-%d")
        chunks.append((after, before))
        current = next_month
    return chunks

def google_news_rss_search(query, hl, gl, ceid, after, before):
    if not HAS_FEEDPARSER:
        return []
    results = []
    try:
        advanced = f'{query} after:{after} before:{before}'
        rss_url = (f"https://news.google.com/rss/search?"
                   f"q={quote_plus(advanced)}&hl={hl}&gl={gl}&ceid={ceid}")
        feed = feedparser.parse(rss_url)
        for entry in feed.entries:
            link = entry.get("link", "")
            if "url=" in link:
                m = re.search(r'url=([^&]+)', link)
                if m:
                    link = unquote(m.group(1))
            title = entry.get("title", "")
            date_str = entry.get("published", "")
            source = entry.get("source", {})
            media = source.get("title", "") if source else ""
            # v4: 内容级过滤
            if is_valid_url(link) and is_relevant_fire(title):
                results.append({
                    "url": link, "title": title,
                    "media": media, "time": date_str
                })
    except Exception:
        pass
    return results

# ========== Bing News ==========

def bing_news_search(query, market="zh-CN", first=0):
    results = []
    try:
        url = (f"https://www.bing.com/news/search?"
               f"q={quote_plus(query)}&cc={market.split('-')[1]}&first={first}"
               f"&setmkt={market}&format=RSS")
        r = requests.get(url, headers=rand_headers(), timeout=20)
        if r.status_code != 200:
            return results
        soup = BeautifulSoup(r.text, "xml")
        for item in soup.find_all("item"):
            try:
                title = item.find("title")
                link = item.find("link")
                pub = item.find("pubDate")
                src = item.find("source")
                title_text = title.get_text(strip=True) if title else ""
                link_url = link.get_text(strip=True) if link else ""
                date_text = pub.get_text(strip=True) if pub else ""
                media_text = src.get_text(strip=True) if src else ""
                if is_valid_url(link_url) and is_relevant_fire(title_text):
                    results.append({
                        "url": link_url, "title": title_text,
                        "media": media_text, "time": date_text
                    })
            except:
                continue
    except Exception:
        pass
    return results

# ========== 正文抓取（同v3，trafilatura→lxml回退）==========

def fetch_fulltext(url, timeout=20):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    try:
        if HAS_TRAFILATURA:
            downloaded = trafilatura.fetch_url(url)
            if downloaded:
                text = trafilatura.extract(downloaded, include_comments=False,
                                           include_tables=False)
                if text and len(text.strip()) > 50:
                    return text.strip()
        r = requests.get(url, headers=headers, timeout=timeout)
        if r.status_code != 200:
            return ""
        from lxml import html as lxml_html
        tree = lxml_html.fromstring(r.content)
        for bad in tree.xpath('//script | //style | //nav | //footer | //header'):
            bad.getparent().remove(bad)
        paras = tree.xpath('//p//text()')
        text = '\n'.join(t.strip() for t in paras if t.strip())
        return text if len(text) > 50 else ""
    except:
        return ""

# ========== 进度管理 ==========

def load_progress():
    if PROGRESS_FILE.exists():
        with open(PROGRESS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "collected": {},
        "searched_gn": [],
        "gdelt_done": False,
        "stats": {"total_urls": 0, "with_content": 0}
    }

def save_progress(p):
    p["stats"]["total_urls"] = len(p["collected"])
    p["stats"]["with_content"] = sum(
        1 for v in p["collected"].values()
        if v.get("content") and len(v["content"]) > 50
    )
    with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
        json.dump(p, f, ensure_ascii=False, indent=2)

def save_csv(p):
    rows = list(p["collected"].values())
    rows.sort(key=lambda x: x.get("time", ""), reverse=True)
    with open(OUTPUT_CSV, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["序号", "URL", "时间", "媒体/来源", "标题", "新闻正文"])
        for i, row in enumerate(rows, 1):
            w.writerow([i, row["url"], row.get("time", ""),
                        row.get("media", ""), row.get("title", ""),
                        row.get("content", "")])
    print(f"\n✅ CSV已保存: {OUTPUT_CSV} ({len(rows)} 条)")

def add_urls(p, items):
    added = 0
    for item in items:
        h = url_hash(item["url"])
        if h in p["collected"]:
            continue
        # v4: 二次过滤确认
        title = item.get("title", "")
        if not is_relevant_fire(title):
            continue
        p["collected"][h] = {
            "url": item["url"],
            "time": item.get("time", ""),
            "media": item.get("media", ""),
            "title": title,
            "content": ""
        }
        added += 1
    return added

# ========== 主流程 ==========

def run(target=TARGET_COUNT, urls_only=False, workers=16):
    p = load_progress()
    print("=" * 60)
    print("🔥 高层火灾新闻收集脚本 v4（修正版）")
    print(f"📋 当前已有: {p['stats']['total_urls']} 个URL | "
          f"{p['stats']['with_content']} 条有正文")
    print(f"🎯 目标: {target} 条")
    print(f"🔧 v4修复: 严格内容过滤，排除军事/山火假阳性")
    print("=" * 60)

    # ===== 阶段1: Google News RSS（主力，优先）=====
    if p["stats"]["total_urls"] < target and HAS_FEEDPARSER:
        print("\n[阶段1] Google News RSS 为主力数据源（标题级精准搜索）...")
        month_chunks = generate_month_chunks(2018)
        searched_gn = set(p.get("searched_gn", []))
        
        all_queries = [
            (GN_QUERIES_EN, "en-US", "US", "US:en", "EN"),
            (GN_QUERIES_ZH, "zh-CN", "CN", "CN:zh", "ZH"),
            (GN_QUERIES_ZH_2, "zh-CN", "CN", "CN:zh", "ZH2"),
            (GN_QUERIES_ZH_3, "zh-CN", "CN", "CN:zh", "ZH3"),
        ]

        for query, hl, gl, ceid, label in all_queries:
            for after, before in month_chunks:
                if p["stats"]["total_urls"] >= target:
                    break
                chunk_key = f"{label}_{after}_{before}"
                if chunk_key in searched_gn:
                    continue
                time.sleep(1)
                items = google_news_rss_search(query, hl, gl, ceid, after, before)
                added = add_urls(p, items)
                p["searched_gn"].append(chunk_key)
                if added > 0:
                    print(f"  GN {label} [{after[:7]}]: +{added} (总计={len(p['collected'])})")
                    save_progress(p)

    print(f"\n  Google News RSS完成，当前总计 {len(p['collected'])} URL")

    # ===== 阶段2: GDELT（补充，回溯36个月）=====
    if not p["gdelt_done"] and p["stats"]["total_urls"] < target:
        print("\n[阶段2] GDELT 补充收集（精确短语，回溯36个月）...")
        now = datetime.now(timezone.utc)
        months_back = 36

        for qi, query in enumerate(GDELT_QUERIES_STRICT, 1):
            if p["stats"]["total_urls"] >= target:
                break
            print(f"  [{qi}/{len(GDELT_QUERIES_STRICT)}] 检索: {query[:80]}...")
            for m in range(months_back):
                if p["stats"]["total_urls"] >= target:
                    break
                end_dt = now - timedelta(days=30 * m)
                start_dt = now - timedelta(days=30 * (m + 1))
                articles = gdelt_search(query, start_dt, end_dt, max_records=250)
                items = []
                for art in articles:
                    url = art.get('url', '')
                    if not url or not is_valid_url(url):
                        continue
                    items.append({
                        "url": url,
                        "title": art.get('title', ''),
                        "media": art.get('domain', domain(url)),
                        "time": art.get('seendate', ''),
                    })
                added = add_urls(p, items)
                if added > 0:
                    print(f"    m={m} +{added} (总计={len(p['collected'])})")

            # 中文补充
            if p["stats"]["total_urls"] < target and "中文" in query or "高层" in query or "火灾" in query:
                for m in range(months_back):
                    if p["stats"]["total_urls"] >= target:
                        break
                    end_dt = now - timedelta(days=30 * m)
                    start_dt = now - timedelta(days=30 * (m + 1))
                    articles = gdelt_search_cn(query, start_dt, end_dt, max_records=250)
                    items = []
                    for art in articles:
                        url = art.get('url', '')
                        if not url or not is_valid_url(url):
                            continue
                        items.append({
                            "url": url,
                            "title": art.get('title', ''),
                            "media": art.get('domain', domain(url)),
                            "time": art.get('seendate', ''),
                        })
                    added = add_urls(p, items)
                    if added > 0:
                        print(f"    CN m={m} +{added} (总计={len(p['collected'])})")

            save_progress(p)
        p["gdelt_done"] = True
        save_progress(p)
        print(f"  GDELT完成，总计 {len(p['collected'])} URL")

    # ===== 阶段2B: Bing News（补充）=====
    if p["stats"]["total_urls"] < target:
        print("\n[阶段2B] Bing News 补充搜索...")
        bn_keywords = [
            ("高层火灾", "zh-CN"), ("高楼火灾", "zh-CN"),
            ("高层建筑火灾", "zh-CN"), ("住宅楼火灾", "zh-CN"),
            ("high-rise fire", "en-US"), ("skyscraper fire", "en-US"),
            ("apartment building fire", "en-US"),
        ]
        for kw, mkt in bn_keywords:
            for page in range(3):
                if p["stats"]["total_urls"] >= target:
                    break
                time.sleep(2)
                items = bing_news_search(kw, mkt, page * 10)
                added = add_urls(p, items)
                if added > 0:
                    print(f"  Bing [{kw} p{page}]: +{added} (总计={len(p['collected'])})")
                    save_progress(p)

    # ===== 阶段3: 并行抓取正文 =====
    if not urls_only:
        rows = list(p["collected"].values())
        to_fetch = [(i, r) for i, r in enumerate(rows)
                    if not r.get("content") or len(r["content"]) < 50]
        if to_fetch:
            print(f"\n[阶段3] 并行抓取正文（{workers}线程）: {len(to_fetch)} 条待抓取...")
            done = 0
            with ThreadPoolExecutor(max_workers=workers) as ex:
                futs = {ex.submit(fetch_fulltext, r["url"]): (i, r)
                        for i, r in to_fetch}
                for fut in as_completed(futs):
                    i, row = futs[fut]
                    try:
                        text = fut.result()
                        if text and len(text) > 50:
                            row["content"] = text
                    except:
                        pass
                    done += 1
                    if done % 50 == 0:
                        print(f"  ...已抓 {done}/{len(to_fetch)}")
                        save_progress(p)
                        save_csv(p)

        save_progress(p)
        save_csv(p)

    # 最终输出
    total = len(p["collected"])
    with_c = p["stats"]["with_content"]
    print(f"\n{'='*60}")
    print(f"📊 最终统计:")
    print(f"  收集URL总数: {total}")
    print(f"  有正文的: {with_c}")
    print(f"  输出文件: {OUTPUT_CSV}")
    print(f"{'='*60}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="高层火灾新闻收集 v4 (修正版)")
    parser.add_argument("--target", type=int, default=TARGET_COUNT)
    parser.add_argument("--reset", action="store_true")
    parser.add_argument("--urls-only", action="store_true")
    parser.add_argument("--workers", type=int, default=16)
    args = parser.parse_args()

    if args.reset and PROGRESS_FILE.exists():
        PROGRESS_FILE.unlink()
        print("🔄 进度已重置")

    run(target=args.target, urls_only=args.urls_only, workers=args.workers)
