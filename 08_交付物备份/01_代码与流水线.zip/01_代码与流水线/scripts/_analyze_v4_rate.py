# -*- coding: utf-8 -*-
"""分析 v4 76 条：Grok 判 K 的火灾事件里，用户保留率 = 4/76 = 5.3%。
这量化了"Grok 判 K → 用户保留"的转化率，用于估算全量路由量。"""
import csv, os

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

# v4 76 条的用户标注
v4 = {}
with open(os.path.join(D, "_v4_用户标注.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        v4[int(r["gid"])] = int(r["label"])

keep = {g for g, v in v4.items() if v == 1}
drop = {g for g, v in v4.items() if v == 0}
print(f"v4 共 {len(v4)} 条: 用户保留 {len(keep)} 剔 {len(drop)}")
print(f"Grok判K→用户保留率: {len(keep)/len(v4):.1%}")

# 全量候选 6742，按此比例估算
total_cand = 6742
est_keep = total_cand * len(keep) / len(v4)
est_route = total_cand * 0.26  # 26% 判 K
print(f"\n全量估算（候选 6742，判K率26%）:")
print(f"  Grok 判 K（路由给人）: ~{est_route:.0f} 条")
print(f"  其中用户预计保留: ~{est_keep:.0f} 条 ({len(keep)/len(v4):.1%})")

# 用户保留的 4 条特征（都是长正文 + 强叙事）
print("\n=== 用户保留的 4 条（为什么保留）===")
for g in sorted(keep):
    print(f"  gid{g}: 高叙事火灾")
