# -*- coding: utf-8 -*-
"""合并 v4 标注进金标准：76 条 = 4 保 + 72 剔 → 金标准 v5。"""
import csv, os, openpyxl

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

# 现有金标准
labels = {}
with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        labels[int(r["gid"])] = int(r["label"])
print(f"原金标准: {len(labels)} 条 (保{sum(1 for v in labels.values() if v==1)} 剔{sum(1 for v in labels.values() if v==0)})")

# v4 标注（1=保留，其余=0）
p = r"C:\Users\Administrator\Desktop\_批量试跑v4_78条交付.xlsx"
wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
v4 = {}
for row in wb.active.iter_rows(values_only=True):
    if row[0] is None or str(row[0]).strip() in ("编号", ""):
        continue
    gid = int(float(row[0]))
    v = str(row[4]).strip() if len(row) > 4 and row[4] is not None else ""
    v4[gid] = 1 if v == "1" else 0
print(f"v4 标注: {len(v4)} 条 (保{sum(1 for v in v4.values() if v==1)} 剔{sum(1 for v in v4.values() if v==0)})")

# 合并（v4 覆盖已存在的）
overlap = set(labels) & set(v4)
print(f"与现有金标准重叠: {len(overlap)} 条")
for g in overlap:
    print(f"  gid{g}: 旧={labels[g]} 新={v4[g]}")

for g, v in v4.items():
    labels[g] = v
print(f"\n合并后金标准: {len(labels)} 条 (保{sum(1 for v in labels.values() if v==1)} 剔{sum(1 for v in labels.values() if v==0)})")

# 写回
rows_all = {}
with open(os.path.join(D, "第三轮_含正文_筛选草稿.csv"), encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        rows_all[i + 1] = {"title": row[1] if len(row) > 1 else "",
                           "body": row[4] if len(row) > 4 else ""}

with open(os.path.join(D, "_merged_user_labels.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["gid", "label", "title", "L"])
    for gid, lab in sorted(labels.items()):
        w.writerow([gid, lab, rows_all[gid]["title"][:80], len(rows_all[gid]["body"] or "")])
print("已更新 _merged_user_labels.csv")
