# -*- coding: utf-8 -*-
import os, sys, subprocess
sys.stdout.reconfigure(encoding='utf-8')
scripts = r'D:\BaiduSyncdisk\chi2027\朱倩\scripts'
todel = ['_probe_pool.py','_probe_coverage.py','_probe_coverage2.py','_iter8_loop.py','_iter8_v2.py','_iter8_v3.py','_iter8_v4.py','_iter8_v5.py','_iter8_semantic.py','_iter8_cand_semantic.py','_filter_res.py','_check_dup.py','_final_clean.py','_check_progress.py','_validate_prompt40.py','_cleanup8.py']
for fn in todel:
    fp = os.path.join(scripts, fn)
    if os.path.exists(fp):
        subprocess.run(['cmd', '/c', 'del', '/f', '/q', fp], capture_output=True)
        if not os.path.exists(fp):
            print('del', fn)
        else:
            print('FAIL', fn)
print('--- 工作流残留检查 ---')
for fn in sorted(os.listdir(r'D:\BaiduSyncdisk\chi2027\朱倩\工作流')):
    if '_iter8' in fn or '第8轮' in fn:
        print(' ', fn)
