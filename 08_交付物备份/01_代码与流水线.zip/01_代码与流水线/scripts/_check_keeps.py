# -*- coding: utf-8 -*-
"""确认 24 条保留的来源构成 + few-shot 示例准备。"""
import csv, os
from collections import Counter
csv.field_size_limit(10**9)

D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

labels = {}
with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        labels[int(r["gid"])] = (int(r["label"]), r["title"])

keeps = {g: t for g, (l, t) in labels.items() if l == 1}
drops = {g: t for g, (l, t) in labels.items() if l == 0}
print(f"总标注: {len(labels)} = 保留 {len(keeps)} + 剔除 {len(drops)}")

# 保留的 gid 是否都在草稿范围（有正文）
rows = {}
with open(os.path.join(D, "第三轮_含正文_筛选草稿.csv"), encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        gid = i + 1
        if gid in keeps:
            rows[gid] = {"title": row[1] if len(row) > 1 else "",
                         "body": row[4] if len(row) > 4 else ""}
print(f"保留条且有正文: {len(rows)}")
for gid in sorted(keeps.keys()):
    print(f"  gid{gid:>5} L={len(rows.get(gid,{}).get('body') or ''):>6} {keeps[gid][:50]}")
