# -*- coding: utf-8 -*-
"""从 Crossref 拉取全部引用元数据，生成 references.bib（防幻觉引用）。"""
import json, time, urllib.request, urllib.parse, os, re

BASE = "https://api.crossref.org/works/"

# (cite_key, doi_or_search, kind)
ITEMS = [
    ("delapena2010immersive",      "10.1162/PRES_a_00005",                "doi"),
    ("feelingnews2023",            "10.1080/21670811.2022.2155205",       "doi"),
    ("embracing2024",              "10.3390/journalmedia5040093",         "doi"),
    ("beyondbeingthere2026",       "10.1145/3772363.3799004",             "doi"),
    ("storyliving2022",            "10.3389/frvir.2022.779148",           "doi"),
    ("recitkit2025",               None,                                  "arxiv"),
    ("slater1997five",             "10.1162/pres.1997.6.6.603",           "doi"),
    ("kilteni2012embodiment",      "10.1162/PRES_a_00124",                "doi"),
    ("herrera2018building",        "10.1371/journal.pone.0204494",        "doi"),
    ("evrd2025",                   "10.1016/j.ijhcs.2024.103397",         "doi"),
    ("cultivating2024",            "10.1007/s00779-024-01812-w",          "doi"),
    ("vrscoping2024",              "10.1007/s10055-024-00946-9",          "doi"),
    ("shockingrealities2025",      "10.1145/3715336.3735809",             "doi"),
    ("equitable2025",              "10.1145/3770755",                     "doi"),
    ("inclusiveavatar2025",        "10.1145/3706598.3714230",             "doi"),
    ("tigwell2021",                "10.1145/3411764.3445620",             "doi"),
    ("visualimpairment2025",       "10.1007/s10055-025-01150-z",          "doi"),
    ("legacysphere2024",           "10.1145/3613904.3641923",             "doi"),
    ("ahn2013embodied",            "10.1080/15213269.2012.755877",        "doi"),
    ("ahn2014short",               "10.1016/j.chb.2014.07.025",           "doi"),
    ("page2021prisma",             "10.1136/bmj.n71",                     "doi"),
    ("machinetobeanother",         None,                                  "misc"),
]

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "WorkBuddy-bib/1.0 (mailto:research@example.com)"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))

def auth(entry):
    a = entry.get("author", [])
    names = []
    for x in a:
        fam = x.get("family", ""); giv = x.get("given", "")
        if not fam:
            continue
        initials = "".join([p[0] for p in giv.replace("-", " ").split() if p]) if giv else ""
        names.append(f"{fam}, {initials},")
    if not names:
        names = [entry.get("container-title", ["Unknown"])[0] if entry.get("container-title") else "Unknown"]
    return "\n".join(names) if names else "Unknown"

def clean(s):
    if not s:
        return ""
    s = re.sub(r"[{}]", "", s)
    return s.replace("&", "\\&")

def get_doi(key):
    meta = fetch(BASE + urllib.parse.quote(key))
    return meta.get("message")

def get_arxiv():
    url = "http://export.arxiv.org/api/query?id_list=2508.18670"
    req = urllib.request.Request(url, headers={"User-Agent": "WorkBuddy-bib/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        xml = r.read().decode("utf-8")
    title = re.search(r"<title>(.*?)</title>", xml, re.S)
    title = title.group(1).strip() if title else "RecitKit: A Spatial Toolkit for Designing Human-Centered Spatial Storytelling in VR"
    authors = re.findall(r"<name>(.*?)</name>", xml)
    return {
        "title": [title], "author": [{"family": a.split()[-1] if a.split() else "", "given": " ".join(a.split()[:-1]) if len(a.split()) > 1 else ""} for a in authors],
        "year": "2025", "note": "arXiv preprint arXiv:2508.18670"
    }

MISC_BIB = """@misc{machinetobeanother,
  title        = {The Machine to Be Another},
  author       = {BeAnotherLab},
  year         = {2013},
  howpublished = {\\url{https://beanotherlab.org}},
  note         = {Embodiment performance installation for perspective-taking and empathy}
}
"""

out = []
for key, doi, kind in ITEMS:
    try:
        if kind == "doi":
            m = get_doi(doi)
            if m.get("message"):
                m = m["message"]
            entry_type = "inproceedings" if "Proceedings" in (m.get("container-title", [""])[0]) or (m.get("type") == "proceedings-article") else "article"
            title = clean(m["title"][0]) if m.get("title") else key
            authors = auth(m)
            year = m.get("issued", {}).get("date-parts", [[None]])[0][0] or m.get("published-print", {}).get("date-parts", [[None]])[0][0]
            vol = m.get("volume", ""); num = m.get("issue", ""); pages = m.get("page", "")
            journal = clean(m.get("container-title", [""])[0]) if m.get("container-title") else ""
            d = m.get("DOI", doi)
            lines = [f"@{entry_type}{{{key},", f"  title        = {{{title}}},", f"  author       = {{{authors}}}"]
            if journal: lines.append(f"  journal      = {{{journal}}},")
            if vol: lines.append(f"  volume       = {{{vol}}},")
            if num: lines.append(f"  number       = {{{num}}},")
            if pages: lines.append(f"  pages        = {{{pages}}},")
            lines.append(f"  year         = {{{year}}},")
            lines.append(f"  doi          = {{{d}}},\n}}")
            out.append("\n".join(lines))
        elif kind == "arxiv":
            m = get_arxiv()
            title = clean(m["title"][0])
            authors = auth(m)
            lines = [f"@misc{{recitkit2025,", f"  title        = {{{title}}},", f"  author       = {{{authors}}}",
                     "  year         = {2025},", "  eprint       = {2508.18670},", "  archiveprefix= {arXiv},",
                     "  howpublished = {\\url{https://arxiv.org/abs/2508.18670}},\n}"]
            out.append("\n".join(lines))
        elif kind == "misc":
            out.append(MISC_BIB.strip())
        print(f"[OK] {key}")
        time.sleep(0.4)
    except Exception as e:
        print(f"[FAIL] {key}: {e}")

bib = "\n\n".join(out) + "\n"
script_dir = os.path.dirname(os.path.abspath(__file__))
target = os.path.join(script_dir, "..", "relatedwork", "overleaf", "references.bib")
os.makedirs(os.path.dirname(target), exist_ok=True)
with open(target, "w", encoding="utf-8") as f:
    f.write(bib)
print("WROTE", os.path.abspath(target), len(bib), "bytes")
