# -*- coding: utf-8 -*-
import csv, os
base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
p = os.path.join(base, "工作流", "_al_待判.csv")
with open(p, encoding="utf-8-sig") as f:
    rows = list(csv.reader(f))
print("总行数:", len(rows) - 1)
print("表头:", rows[0])
src = {}
for r in rows[1:]:
    s = r[3]
    src[s] = src.get(s, 0) + 1
print("来源分布:", src)
print("前6条:")
for r in rows[1:7]:
    print("  gid", r[0], "|", r[3], "|", r[4], "|", r[1][:40])
