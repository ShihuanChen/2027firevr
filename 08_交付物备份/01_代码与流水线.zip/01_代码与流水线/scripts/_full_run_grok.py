# -*- coding: utf-8 -*-
"""
全量 Grok 正文语义判断：候选池（排除已判403）全部跑完，断点续传。
复用 v4 抽样 checkpoint，避免重复调用。
"""
import csv, os, json, urllib.request, time, yaml, traceback, random
from concurrent.futures import ThreadPoolExecutor, as_completed

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")
OUT = os.path.join(D, "_全量_grok判定.csv")
CKPT = os.path.join(D, "_批量试跑v4_checkpoint.csv")  # 复用已有断点
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36"

PROMPT_TMPL = (
    "阅读这篇新闻报道的【正文】，判断它是否在报道一场【真实的建筑火灾事件】"
    "（住宅/公寓/高楼/商场/工厂/仓库等建筑的火灾、爆炸起火、或火灾导致的救援疏散）。\n"
    "回答规则：是火灾事件报道 → K；不是（正文主要讲政治、娱乐、战争、政策、自然灾害、"
    "消防安全宣传、行业报道等，即使提到 fire 或火灾）→ D。只回答一个字母。\n\n标题:{t}\n正文:{b}"
)

def grok_vote(BASE, KEY, MODEL, title, body):
    payload = {"model": MODEL,
               "messages": [{"role": "user", "content": PROMPT_TMPL.format(t=(title or "")[:150], b=(body or "")[:1200])}],
               "temperature": 0, "max_tokens": 300}
    for attempt in range(3):
        req = urllib.request.Request(
            BASE + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": "Bearer " + KEY, "Content-Type": "application/json",
                     "User-Agent": UA, "Accept": "*/*"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode("utf-8"))
                content = data["choices"][0]["message"]["content"]
                if "</think>" in content:
                    content = content.split("</think>")[-1]
                content = content.upper()
                for ch in content:
                    if ch in ("K", "D"):
                        return ch
                return "E"
        except Exception:
            time.sleep(2)
    return "E"

def run():
    with open(os.path.join(D, "config.yaml"), encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cred = cfg["credentials"]
    BASE, KEY, MODEL = cred["base_url"].rstrip("/"), cred["api_key"], cred["model_name"]
    print(f"model={MODEL} 并发=6 全量正文语义", flush=True)

    # 已判 403（最新金标准）
    labelled = set()
    with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            labelled.add(int(r["gid"]))
    print(f"已判: {len(labelled)}", flush=True)

    # 候选池
    items = []
    with open(SRC, encoding="utf-8") as f:
        reader = csv.reader(f); next(reader)
        for i, row in enumerate(reader):
            gid = i + 1
            body = row[4] if len(row) > 4 else ""
            if gid in labelled or len(body or "") < 300:
                continue
            items.append({"gid": gid, "title": row[1] if len(row) > 1 else "",
                          "body": body})
    print(f"候选池: {len(items)}", flush=True)

    # 恢复断点
    results = {}
    if os.path.exists(CKPT):
        with open(CKPT, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                g = int(r["gid"])
                v = r["grok"]
                if v in ("K", "D", "E"):
                    results[g] = v
        print(f"断点恢复: {len(results)} 条", flush=True)

    todo = [it for it in items if it["gid"] not in results]
    print(f"待跑: {len(todo)}", flush=True)

    t0 = time.time()
    BATCH = 100
    total_done = len(results)
    for bi in range(0, len(todo), BATCH):
        batch = todo[bi:bi+BATCH]
        with ThreadPoolExecutor(max_workers=6) as ex:
            futs = {ex.submit(grok_vote, BASE, KEY, MODEL, it["title"], it["body"]): it["gid"]
                    for it in batch}
            for fut in as_completed(futs):
                gid = futs[fut]
                results[gid] = fut.result()
        # 存断点
        with open(CKPT, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["gid", "grok"])
            for g, v in results.items():
                w.writerow([g, v])
        total_done = len(results)
        el = time.time() - t0
        remain = el / total_done * (len(items) - total_done) if total_done else 0
        print(f"  批次{bi//BATCH+1} 完成, 累计 {total_done}/{len(items)}, 用时{el:.0f}s, 预计剩余{remain:.0f}s", flush=True)

    # 统计
    keep = [g for g, v in results.items() if v == "K"]
    drop = [g for g, v in results.items() if v == "D"]
    err = [g for g, v in results.items() if v == "E"]
    print(f"\n=== 全量 Grok 判定完成 ===", flush=True)
    print(f"火灾事件(K): {len(keep)} | 非火灾(D): {len(drop)} | 错误(E): {len(err)}", flush=True)
    print(f"总用时 {time.time()-t0:.0f}s", flush=True)

    # 输出
    body_map = {it["gid"]: it for it in items}
    with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["gid", "标题", "grok判定", "正文(前2000)"])
        for gid in sorted(results.keys()):
            if gid in body_map:
                it = body_map[gid]
                w.writerow([gid, it["title"][:80], results[gid],
                            it["body"][:2000].replace("\n", " ").replace("\r", "")])
    print(f"输出: {OUT}", flush=True)

with open(os.path.join(D, "_全量_grok_log.txt"), "w", encoding="utf-8") as outf:
    try:
        run()
    except Exception:
        traceback.print_exc(file=outf)
print("DONE")
