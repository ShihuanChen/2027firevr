# -*- coding: utf-8 -*-
"""Grok 语义票 GoldSet 评估 v2：并发 6 线程 + 缩短输入。"""
import csv, os, json, urllib.request, urllib.error, time, yaml, sys, traceback
from concurrent.futures import ThreadPoolExecutor, as_completed

LOG = r"D:\BaiduSyncdisk\chi2027\朱倩\scripts\_grok_result.txt"
CSV = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流\第三轮_含正文_筛选草稿.csv"
GOLD = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流\人机协作_GoldSet_103.csv"
CFG = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流\config.yaml"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36"

PROMPT_TMPL = (
    "判断这篇火灾报道是否适合VR场景重建：是否含可重建的空间细节(楼层/走廊/楼梯/窗户/通道)、"
    "身体动作(爬行/扶墙/跳下/逃生路线)、感官描写(烟雾/声音/温度)、或弱势群体(老人/儿童/残障/孕妇/听障/视障)的逃生经历？"
    "只回答一个字母：K=适合重建,D=不适合。\n标题:{t}\n正文:{b}"
)

def grok_vote(args):
    BASE, KEY, MODEL, title, body = args
    payload = {"model": MODEL,
               "messages": [{"role": "user", "content": PROMPT_TMPL.format(t=(title or "")[:150], b=(body or "")[:800])}],
               "temperature": 0, "max_tokens": 300}
    for attempt in range(2):
        req = urllib.request.Request(
            BASE + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": "Bearer " + KEY, "Content-Type": "application/json",
                     "User-Agent": UA, "Accept": "*/*"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode("utf-8"))
                content = data["choices"][0]["message"]["content"]
                # 跳过 <think> 块，取最终答案的第一个 K/D
                if "</think>" in content:
                    content = content.split("</think>")[-1]
                content = content.upper()
                for ch in content:
                    if ch in ("K", "D"):
                        return ch
                return "E:noKD"
        except Exception:
            time.sleep(2)
    return "E"

def run():
    csv.field_size_limit(10**9)
    with open(CFG, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cred = cfg["credentials"]
    BASE, KEY, MODEL = cred["base_url"].rstrip("/"), cred["api_key"], cred["model_name"]
    print(f"model={MODEL} 并发=6", flush=True)

    rows = []
    with open(CSV, encoding="utf-8") as f:
        reader = csv.reader(f); next(reader)
        for i, row in enumerate(reader):
            rows.append({"gid": i + 1, "title": row[1] if len(row) > 1 else "",
                         "body": row[4] if len(row) > 4 else ""})

    gold = []
    with open(GOLD, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            lab = str(r.get("keep_label", "")).strip()
            if lab in ("1", "0.5", "0"):
                i = int(r["idx"])
                gold.append({"label": 1 if lab in ("1", "0.5") else 0,
                             "title": rows[i-1]["title"], "body": rows[i-1]["body"]})

    t0 = time.time()
    tasks = [(BASE, KEY, MODEL, g["title"], g["body"]) for g in gold]
    answers = [None] * len(tasks)
    with ThreadPoolExecutor(max_workers=6) as ex:
        futs = {ex.submit(grok_vote, t): i for i, t in enumerate(tasks)}
        done = 0
        for fut in as_completed(futs):
            idx = futs[fut]
            answers[idx] = fut.result()
            done += 1
            if done % 20 == 0:
                print(f"  进度 {done}/{len(tasks)}, {time.time()-t0:.0f}s", flush=True)

    TP = FP = TN = FN = 0
    detail = []
    for g, ans in zip(gold, answers):
        pred = 1 if ans == "K" else 0
        if pred == 1 and g["label"] == 1: TP += 1
        elif pred == 1 and g["label"] == 0: FP += 1
        elif pred == 0 and g["label"] == 1: FN += 1
        else: TN += 1
        detail.append((g["label"], pred, ans))

    P = TP / (TP + FP) if TP + FP else 0
    R = TP / (TP + FN) if TP + FN else 0
    F1 = 2 * P * R / (P + R) if P + R else 0
    acc = (TP + TN) / len(gold)

    print("\n=== Grok-4.5 GoldSet 103 评估（并发6）===", flush=True)
    print(f"混淆矩阵   AI=保留   AI=剔除")
    print(f"人工保留11  {TP:>4}     {FN:>4}")
    print(f"人工剔除92  {FP:>4}     {TN:>4}")
    print(f"\nPrecision = {P:.1%}")
    print(f"Recall    = {R:.1%}")
    print(f"F1        = {F1:.1%}")
    print(f"Accuracy  = {acc:.1%}")
    print(f"误留率    = {FP/(TP+FP) if TP+FP else 0:.1%}")
    print(f"误删率    = {FN/(TP+FN) if TP+FN else 0:.1%}")
    print(f"总用时    = {time.time()-t0:.0f}s", flush=True)

    print("\n=== 11 条人工保留的 Grok 判断 ===", flush=True)
    for (lab, pred, ans) in detail:
        if lab == 1:
            mark = "OK  " if pred == 1 else "MISS"
            print(f"  [{mark}] grok={ans}", flush=True)
    errs = [a for a in answers if not a or a.startswith("E")]
    print(f"\n错误/超时: {len(errs)} 条", flush=True)

with open(LOG, "w", encoding="utf-8") as outf:
    try:
        run()
    except Exception:
        traceback.print_exc(file=outf)
print("DONE")
