# -*- coding: utf-8 -*-
"""
金标准 v2 分层抽样：按 长度×场景×人物×弱势群体 四维分层，随机抽 ~180 条。
排除旧 GoldSet 顺序样本(idx 1-103)避免重叠污染。
输出: 工作流/_goldset_v2_分层抽样.csv
"""
import csv, os, random, re

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")
OUT = os.path.join(D, "_goldset_v2_分层抽样.csv")

# 词表（与 committee 一致的具身特征）
SCENE_W = [
    "stairwell","staircase","corridor","balcony","fire escape","crawling","crawl",
    "trapped","trap","black smoke","alarm",
    "楼梯","走廊","通道","阳台","窗口","窗框","浓烟","火势",
    "被困","逃生","跳下","绳索","床单","扶着墙","弯腰","匍匐","天台","窗台",
]
PERSON_W = [
    "said","says","told","recalled","remembered","described","witness","survivor",
    "victim","rescued","escaped","告诉记者","回忆","描述","幸存者","目击者",
    "亲眼","听到","闻到",
]
VULN_W = [
    "wheelchair","blind","deaf","hearing","visual","disabilit","elderly","disabled",
    "pregnant","轮椅","盲人","聋","听障","视障","残疾","老人","孕妇",
]
VULN_W2 = ["child","baby","infant","儿童","婴儿"]

EXCLUDE_PAT = [
    re.compile(r"(missile|drone|airstrike|air strike|military|war\b|bomb|iran|israel|ukraine|russia)", re.I),
    re.compile(r"(fire department|fire chief|fire truck|fire station|fire.*training|fire.*budget)", re.I),
    re.compile(r"(review|trailer|game\b|movie\b|tv show|comic|solicit|nfl|nba|mlb)", re.I),
    re.compile(r"(trump|biden|election|campaign|vote|president|senator|congress)", re.I),
    re.compile(r"政府工作报告|隐患排查|消防检查|消防演练|春节|国庆", re.I),
    re.compile(r"召开.*会议|部署.*工作|开展.*活动|推进.*建设", re.I),
]

def cw(text, words):
    t = (" " + (text or "").lower() + " ")
    return sum(1 for w in words if w in t)

def stratify(title, body):
    t = (title + " " + (body or "")[:2000]).lower()
    L = len(body or "")
    sc = cw(t, SCENE_W)
    pr = cw(t, PERSON_W)
    vg = cw(t, VULN_W) + 0.5 * cw(t, VULN_W2)
    # 分层桶
    len_b = "S" if L < 1500 else ("M" if L < 4000 else "L")
    sc_b = "H" if sc >= 3 else ("M" if sc >= 1 else "L")
    pr_b = "Y" if pr >= 1 else "N"
    vg_b = "Y" if vg >= 1 else "N"
    return f"{len_b}_{sc_b}{pr_b}{vg_b}", {"L": L, "sc": sc, "pr": pr, "vg": round(vg, 1)}

# 读取并分层
print("读取数据...")
buckets = {}
items = []
with open(SRC, encoding="utf-8") as f:
    reader = csv.reader(f)
    next(reader)
    for i, row in enumerate(reader):
        gid = i + 1
        if gid <= 103:  # 排除旧 GoldSet 顺序样本
            continue
        title = row[1] if len(row) > 1 else ""
        body = row[4] if len(row) > 4 else ""
        if len(body or "") < 400:
            continue
        if any(p.search(title) for p in EXCLUDE_PAT):
            continue
        key, feat = stratify(title, body)
        buckets.setdefault(key, []).append({
            "gid": gid, "title": title, "body": body, "L": len(body), "feat": feat})

print(f"分层桶数: {len(buckets)}, 总候选: {sum(len(v) for v in buckets.values())}")

# 分层抽样：每桶按比例抽，上限控制
random.seed(20260803)
TARGET = 180
per_bucket = {}
total = sum(len(v) for v in buckets.values())
remaining = TARGET
# 第一遍：每桶按占比分配
alloc = {}
for k, v in sorted(buckets.items(), key=lambda x: -len(x[1])):
    n = max(1, round(len(v) / total * TARGET)) if len(buckets) > 40 else 1
    alloc[k] = n
# 若超出目标，从桶内缩减（保留小桶1条）
while sum(alloc.values()) > TARGET:
    # 从最大分配且>1的桶减1
    big = [k for k, n in alloc.items() if n > 1 and len(buckets[k]) > 1]
    if not big:
        break
    k = max(big, key=lambda x: alloc[x])
    alloc[k] -= 1
# 若不足，从剩余多的桶补
while sum(alloc.values()) < TARGET:
    cand = [k for k in buckets if alloc[k] < len(buckets[k])]
    if not cand:
        break
    k = random.choice(cand)
    alloc[k] += 1

selected = []
for k, n in alloc.items():
    pool = buckets[k]
    if len(pool) <= n:
        chosen = pool
    else:
        chosen = random.sample(pool, n)
    selected.extend(chosen)

# 打乱顺序（避免同层集中）
random.shuffle(selected)
print(f"实际抽样: {len(selected)} 条")

# 输出
with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["编号", "标题", "字数", "分层特征", "正文(前2500)", "用户填1/0"])
    for s in selected:
        ft = s["feat"]
        fstr = f'L{ft["L"]} S{ft["sc"]} P{ft["pr"]} VG{ft["vg"]}'
        w.writerow([s["gid"], s["title"][:80], s["L"], fstr,
                    s["body"][:2500].replace("\n", " ").replace("\r", ""), ""])

print(f"输出: {OUT}")

# 分层覆盖统计
from collections import Counter
cov = Counter()
for k, n in alloc.items():
    cov[k] = n
print(f"\n分层覆盖: {len(cov)} 个桶")
print("抽样分布（前20桶）:")
for k, n in sorted(cov.items(), key=lambda x: -x[1])[:20]:
    print(f"  {k:14} x{n}")
