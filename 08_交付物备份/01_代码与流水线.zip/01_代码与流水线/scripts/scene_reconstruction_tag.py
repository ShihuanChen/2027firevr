#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VR火灾场景还原指标 — 第二轮重新打标
聚焦: 空间/声音/视觉/时间/身体/社交 六维场景重建指标
输出打标CSV + 方法论Memo
"""
import csv, os, re, json
from datetime import datetime
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TODAY  = datetime.now().strftime("%Y%m%d")

# 尝试用最新的补充正文文件，没有则回退到第二轮打标
CANDIDATES = [
    os.path.join(ROOT, "data", f"高层火灾_补充正文_{TODAY}.csv"),
    os.path.join(ROOT, "data", "高层火灾_第二轮打标_20260701.csv"),
    os.path.join(ROOT, "data", "高层火灾新闻可用精选_20260701.csv"),
]
INPUT = None
for c in CANDIDATES:
    if os.path.exists(c):
        INPUT = c
        break
if not INPUT:
    print("ERROR: No input file found!")
    exit(1)

print(f"Input: {INPUT}")

OUT_CSV   = os.path.join(ROOT, "data", f"场景还原指标_打标_{TODAY}.csv")
OUT_MEMO  = os.path.join(ROOT, "data", f"VR场景还原方法论Memo_{TODAY}.md")
OUT_JSON  = os.path.join(ROOT, "data", f"场景指标统计_{TODAY}.json")

# ============================================================
# 六维场景重建指标体系
# ============================================================

SCENE_DIMENSIONS = {

    # ── 1. 空间指标 (Spatial) ──
    "S_楼层位置": {
        "高层(≥10层)":   [r"\b(?:1[0-9]|[2-9]\d)\s*(?:层|楼|F|floor|story|storey)", r"high.?rise", r"高层"],
        "中层(4-9层)":    [r"\b[4-9]\s*(?:层|楼|F|floor|story|storey)", r"mid.?rise"],
        "低层(1-3层)":    [r"\b[1-3]\s*(?:层|楼|F|floor|story|storey)", r"ground\s*floor", r"first\s*floor"],
        "顶楼/阁楼":      [r"top\s*floor", r"attic", r"penthouse", r"roof", r"顶楼", r"阁楼"],
        "地下室":         [r"basement", r"地下室", r"地下"],
    },
    "S_建筑构造": {
        "楼梯间":         [r"stairwell", r"staircase", r"stairway", r"stairs", r"楼梯", r"楼道"],
        "走廊/过道":      [r"hallway", r"corridor", r"走廊", r"过道"],
        "阳台":           [r"balcony", r"阳台", r"露台"],
        "电梯":           [r"elevator", r"lift", r"电梯"],
        "窗户/逃生口":    [r"window", r"窗户", r"窗"],
        "防火门":         [r"fire\s*door", r"防火门"],
        "避难层":         [r"refuge\s*(?:floor|area)", r"避难层"],
    },
    "S_空间约束": {
        "能见度<3m":      [r"couldn'?t\s*see", r"零能见度", r"zero\s*visibilit", r"no\s*visibilit", r"看不(?:见|清)"],
        "浓烟灌满":       [r"smoke.*fill", r"filled.*smoke", r"engulf", r"灌满", r"弥漫"],
        "通道堵塞":       [r"block(?:ed|ing).*(?:hallway|corridor|stair|exit)", r"堵塞", r"堵住"],
        "出口不明":       [r"(?:couldn'?t|could\s*not)\s*find.*(?:exit|way\s*out)", r"找不到.*出口"],
    },

    # ── 2. 声音指标 (Auditory) ──
    "A_警报类": {
        "火警铃":         [r"fire\s*alarm", r"smoke\s*alarm", r"火警", r"警报.*响", r"警铃"],
        "消防车警笛":     [r"siren", r"fire\s*truck", r"警笛", r"消防车"],
        "邻里呼喊":       [r"scream", r"yell", r"shout", r"喊叫", r"尖叫", r"大叫"],
        "敲门/拍门":      [r"knock(?:ing)?\s*(?:on|at).*door", r"bang(?:ing)?\s*on.*door", r"拍门", r"敲门"],
    },
    "A_环境声": {
        "爆炸声":         [r"explosion", r"blast", r"boom", r"爆炸", r"巨响"],
        "燃烧声":         [r"crackl", r"roar.*fire", r"fire.*roar", r"燃烧.*声"],
        "坍塌声":         [r"collaps", r"crash", r"坍塌", r"倒塌"],
        "玻璃碎裂":       [r"glass.*(?:break|shatter|crack)", r"玻璃.*碎"],
    },
    "A_信息可达性": {
        "听障-警报无效":  [r"deaf.*(?:alarm|alert|hear)", r"couldn'?t\s*hear", r"听不到", r"听不见", r"听障"],
        "视觉警报替代":    [r"strobe.*light", r"visual.*alarm", r"闪光", r"视觉.*警"],
        "信息延迟":        [r"(?:delayed|late).*(?:alert|warning|notif)", r"延迟.*警", r"才发现.*火"],
    },

    # ── 3. 视觉指标 (Visual) ──
    "V_烟雾视觉": {
        "黑烟":           [r"black\s*smoke", r"黑烟", r"浓黑"],
        "白烟/灰烟":      [r"white\s*smoke", r"gray\s*smoke", r"grey\s*smoke", r"白烟"],
        "浓烟滚滚":       [r"thick\s*smoke", r"heavy\s*smoke", r"dense\s*smoke", r"浓烟", r"滚滚"],
        "烟雾层降":        [r"smoke.*descend", r"smoke.*layer", r"smoke.*ceiling", r"烟层"],
        "烟囱效应":        [r"chimney\s*effect", r"stack\s*effect", r"烟囱效应"],
    },
    "V_火焰视觉": {
        "明火可见":       [r"flame", r"fire\s*visible", r"火光", r"火焰", r"明火"],
        "外墙燃烧":       [r"exterior.*(?:burn|fire|flame)", r"cladding.*fire", r"外墙.*火", r"外立面"],
        "窗户喷火":       [r"flames?\s*(?:from|out\s*of|through).*window", r"窗户.*喷.*火"],
        "黑烟柱":         [r"plume.*smoke", r"column.*smoke", r"烟柱"],
    },
    "V_光照条件": {
        "黑暗":           [r"dark", r"blackout", r"黑暗", r"漆黑"],
        "断电":           [r"power\s*(?:out|outage|cut|fail)", r"断电", r"停电"],
        "应急灯":         [r"emergency\s*light", r"应急灯"],
        "火光照明":       [r"fire.*(?:illuminat|light|glow)", r"火光.*照"],
    },

    # ── 4. 时间指标 (Temporal) ──
    "T_事件时间": {
        "深夜/凌晨":      [r"midnight", r"early\s*(?:morning|hour)", r"凌晨", r"深夜", r"半夜"],
        "清晨":           [r"morning", r"dawn", r"清晨", r"早上"],
        "傍晚":           [r"evening", r"dusk", r"傍晚", r"黄昏"],
        "白天":           [r"afternoon", r"mid.?day", r"白天", r"下午"],
    },
    "T_蔓延速度": {
        "快速蔓延(<10min)":[r"rapid.*spread", r"quick.*spread", r"快速.*蔓延", r"迅速.*蔓延"],
        "数层/分":        [r"\d+\s*(?:floor|story|storey|layer).*per\s*(?:minute|second)", r"层.*/.*分"],
        "闪燃/爆燃":      [r"flashover", r"backdraft", r"deflagration", r"闪燃", r"爆燃"],
    },
    "T_响应时间": {
        "消防<5min到达":  [r"(?:respond|arrive|dispatch).*?(?:minute|\d+\s*min)", r"消防.*?分钟.*?到达"],
        "疏散耗时":       [r"evacuat.*?(?:time|minute|hour|second)", r"疏散.*分钟", r"逃.*分钟"],
        "被困时间":       [r"trapped.*?(?:minute|hour)", r"被困.*分钟", r"困.*小时"],
    },

    # ── 5. 身体感知 (Somatic) ──
    "B_温度与触觉": {
        "高温/灼热":      [r"heat", r"scorch", r"灼热", r"滚烫", r"高温"],
        "呼吸困难":       [r"(?:hard|difficult|struggle).*breathe", r"呼吸困难", r"窒息"],
        "烟雾刺激":       [r"smoke\s*inhalation", r"irritat.*eye", r"cough", r"呛", r"刺激"],
        "体力耗尽":       [r"exhaust", r"fatigue", r"体力", r"筋疲力尽"],
    },
    "B_身体约束": {
        "老年人步速":     [r"elderly.*(?:slow|walk|pace|speed)", r"slow.*old.*(?:man|woman)", r"老人.*慢", r"蹒跚"],
        "轮椅不可通行":   [r"wheelchair.*(?:can'?t|can\s*not|unable|stuck)", r"轮椅.*(?:无法|不能|卡)"],
        "儿童身体限制":   [r"child.*(?:too\s*small|short|can'?t.*reach)", r"小孩.*(?:够不着|太小)"],
        "跌倒":           [r"fall|trip|stumble|slip", r"跌倒", r"摔倒", r"绊倒"],
    },
    "B_感官剥夺": {
        "视觉障碍":       [r"(?:blind|visual.*impair|vision.*loss|low.?vision)", r"视障", r"失明", r"看不见"],
        "听觉障碍":       [r"(?:deaf|hearing.*impair|hard\s*of\s*hearing)", r"听障", r"聋", r"听不见"],
        "触觉障碍":       [r"(?:numb|can'?t\s*feel|lost.*sensation)", r"麻木"],
    },

    # ── 6. 社交/人群 (Social) ──
    "C_人群密度": {
        "拥挤":           [r"crowd", r"jam", r"congest", r"拥挤", r"人潮", r"挤满"],
        "独自一人":       [r"alone", r"by\s*(?:her|him|them)self", r"独自", r"一个人"],
        "家庭单元":       [r"family", r"parent.*child", r"couple", r"一家", r"母子", r"父子"],
    },
    "C_互动行为": {
        "互助逃生":       [r"help(?:ed|ing)?\s*(?:other|neighbor|each)", r"assist.*escape", r"互助", r"帮助.*逃"],
        "等待救援":       [r"wait(?:ing)?\s*(?:for|rescue|help|firefighter)", r"等待.*救援"],
        "返回救人/物":    [r"(?:went|go|run).*back\s*(?:in|inside|to.*rescue)", r"返回.*(?:救|取)"],
        "指挥疏散":       [r"(?:direct|guide|lead).*evacuat", r"指挥.*疏散", r"引导.*逃"],
        "恐慌奔逃":       [r"panic", r"rush(?:ed)?.out", r"fled", r"chaos", r"恐慌", r"蜂拥"],
    },
    "C_弱势群体": {
        "老年人":         [r"elderly", r"senior", r"old\s*(?:woman|man|person|resident)", r"老人", r"长者", r"老年"],
        "儿童":           [r"child(?:ren)?|baby|infant|toddler|kids?", r"儿童", r"小孩", r"婴儿"],
        "残障者":         [r"disab(?:led|ility)", r"残疾人", r"残障"],
        "宠物":           [r"pet|dog|cat|animal", r"宠物", r"猫", r"狗"],
        "孕妇":           [r"pregnant", r"孕妇"],
    },
}

def tag_scene(text):
    """对文本进行六维场景重建指标打标"""
    if not text or len(text) < 50:
        return {}
    text_lower = text.lower()
    tags = {}
    for dim_group, subdims in SCENE_DIMENSIONS.items():
        for label, patterns in subdims.items():
            for pat in patterns:
                if re.search(pat, text_lower):
                    key_short = dim_group.split("_")[0]  # S/A/V/T/B/C
                    tags.setdefault(key_short, [])
                    tags[key_short].append(label)
                    break
    return tags

def extract_numbers(text):
    """提取关键数字"""
    if not text: return {}
    nums = {}
    # 楼层数
    m = re.search(r"(\d+)\s*(?:[- ]?(?:story|storey|floor|层)[-\s]*(?:build|apart|complex|block))", text, re.I)
    if m: nums["total_floors"] = m.group(1)
    # 起火楼层
    m = re.search(r"(?:fire\s*(?:start|break|origin|began).*?(?:on|at|from).*?)?(\d+)(?:st|nd|rd|th)?\s*(?:floor|story|storey|层)", text, re.I)
    if m: nums["fire_floor"] = m.group(1)
    # 伤亡
    m = re.search(r"(\d+)\s*(?:people|person|resident|victim)s?\s*(?:kill|dead|died|death|fatal)", text, re.I)
    if m: nums["deaths"] = m.group(1)
    m = re.search(r"(\d+)\s*(?:people|person|resident|victim)s?\s*(?:injur|hurt|hospitali)", text, re.I)
    if m: nums["injured"] = m.group(1)
    # 疏散人数
    m = re.search(r"(\d+)\s*(?:people|resident|household)s?\s*(?:displaced|evacuat)", text, re.I)
    if m: nums["displaced"] = m.group(1)
    # 响应时间
    m = re.search(r"(\d+)\s*minute.*?(?:respond|arrive|dispatch)", text, re.I)
    if m: nums["response_min"] = m.group(1)
    return nums

def scene_score(tags, nums):
    """场景还原度评分"""
    score = 0
    for dim in ["S", "A", "V", "T", "B", "C"]:
        if dim in tags:
            score += len(tags[dim])
    if nums:
        score += len(nums) * 0.5
    return score

def tier_from_score(s):
    if s >= 12: return "S+"
    elif s >= 8: return "S"
    elif s >= 5: return "A"
    elif s >= 3: return "B"
    else: return "C"

# ============================================================
# 主流程
# ============================================================
print("Reading input...")
with open(INPUT, "r", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    all_rows = list(reader)
    fieldnames = reader.fieldnames

print(f"Total records: {len(all_rows)}")

# 打标
tagged = []
stats = Counter()
dim_stats = {dim: Counter() for dim in ["S","A","V","T","B","C"]}

for r in all_rows:
    title = r.get("title", "")
    content = r.get("content", "")
    text = f"{title}\n{content}" if content else title
    
    tags = tag_scene(text)
    nums = extract_numbers(text)
    score = scene_score(tags, nums)
    tier = tier_from_score(score)
    
    # 统计
    for dim, labels in tags.items():
        for l in labels:
            dim_stats[dim][l] += 1
    
    # 构建输出行
    new_row = dict(r)
    new_row["scene_tags"] = " | ".join(f"{dim}:{','.join(labels)}" for dim, labels in sorted(tags.items()))
    new_row["extracted_numbers"] = json.dumps(nums, ensure_ascii=False) if nums else ""
    new_row["scene_recon_score"] = str(score)
    new_row["scene_tier"] = tier
    
    # 分类标记
    if content and len(content) > 50 and not content.startswith("error:") and not content.startswith("We're Sorry"):
        new_row["content_quality"] = "有正文"
    elif content and len(content) > 20:
        new_row["content_quality"] = "低质正文"
    else:
        new_row["content_quality"] = "无正文"
    
    tagged.append(new_row)

# 排序：scene_recon_score降序
tagged.sort(key=lambda x: -float(x.get("scene_recon_score", 0)))

# 输出CSV
NEW_FIELDS = fieldnames + ["scene_tags", "extracted_numbers", "scene_recon_score", "scene_tier", "content_quality"]
with open(OUT_CSV, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=NEW_FIELDS, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(tagged)

print(f"Output CSV: {OUT_CSV}")

# ============================================================
# 生成方法论Memo
# ============================================================
lines = []
lines.append("# VR火灾场景还原方法论 Memo")
lines.append(f"> 基于 {len([r for r in all_rows if r.get('content','').strip() and len(r['content'].strip())>50])} 篇有正文的高层火灾新闻分析")
lines.append(f"> 生成时间: {TODAY}")
lines.append("")

# Tier分布
tier_counts = Counter(r["scene_tier"] for r in tagged)
lines.append("## 场景还原度Tier分布")
lines.append("")
lines.append("| Tier | 数量 | 场景还原潜力 |")
lines.append("|:---|:---|:---|")
for t in ["S+", "S", "A", "B", "C"]:
    cnt = tier_counts.get(t, 0)
    meaning = {"S+": "极丰富：多维度完整覆盖，可直接转VR关卡",
               "S": "丰富：4+维度有细节",
               "A": "良好：3维度有细节",
               "B": "基础：1-2维度有信息",
               "C": "不足：仅有标题信息"}[t]
    lines.append(f"| **{t}** | {cnt} | {meaning} |")
lines.append("")

# 各维度分析
dim_names = {
    "S": ("空间指标", ["楼层位置", "建筑构造", "空间约束"]),
    "A": ("声音指标", ["警报类", "环境声", "信息可达性"]),
    "V": ("视觉指标", ["烟雾视觉", "火焰视觉", "光照条件"]),
    "T": ("时间指标", ["事件时间", "蔓延速度", "响应时间"]),
    "B": ("身体感知", ["温度触觉", "身体约束", "感官剥夺"]),
    "C": ("社交人群", ["人群密度", "互动行为", "弱势群体"]),
}

lines.append("## 六维场景重建指标分析")
lines.append("")

for dim_key, (dim_name, sub_groups) in dim_names.items():
    lines.append(f"### {dim_name} ({dim_key})")
    lines.append("")
    ds = dim_stats.get(dim_key, {})
    if ds:
        lines.append("| 标签 | 命中次数 | VR场景设计建议 |")
        lines.append("|:---|:---|:---|")
        for tag, cnt in sorted(ds.items(), key=lambda x: -x[1]):
            # 自动生成VR建议
            suggestion = ""
            if dim_key == "S":
                if "楼梯间" in tag: suggestion = "核心逃生路径建模，需模拟烟雾灌入动态"
                elif "高层" in tag: suggestion = "场景高度设定，垂直方向需≥10层空间感"
                elif "能见度" in tag: suggestion = "后处理shader模拟，<3m时仅显示邻近轮廓"
                elif "浓烟灌满" in tag: suggestion = "体积雾+粒子系统，从天花板向下沉降"
                elif "走廊" in tag: suggestion = "线性路径设计，分支节点放置决策点"
                elif "阳台" in tag: suggestion = "可交互救援点（云梯/邻居帮助）"
                elif "电梯" in tag: suggestion = '置于禁用状态，作为"无助感"触发器'
                elif "窗户" in tag: suggestion = "可打破逃生/呼救/烟雾入口"
            elif dim_key == "A":
                if "火警铃" in tag: suggestion = "3D空间化音频，距离衰减+混响"
                elif "邻里呼喊" in tag: suggestion = "空间化人声NPC，恐慌/指示两种模式"
                elif "敲门" in tag: suggestion = "近场音效，触觉反馈可结合手柄振动"
                elif "爆炸声" in tag: suggestion = "低频冲击+画面震动+光效同步"
                elif "听障" in tag: suggestion = "核心机制：关闭警报音轨，仅保留视觉暗示"
                elif "视觉警报" in tag: suggestion = "频闪+颜色编码+触觉振动替代警报"
            elif dim_key == "V":
                if "黑烟" in tag: suggestion = "粒子颜色#1a1a1a，不透明度0.7-0.95"
                elif "浓烟滚滚" in tag: suggestion = "体积雾密度1.5x，降低对比度"
                elif "明火可见" in tag: suggestion = "动态火焰shader+光照探头"
                elif "黑暗" in tag: suggestion = "环境光降至0.05，仅靠火焰/应急灯"
                elif "断电" in tag: suggestion = "触发器：火警后N秒全楼熄灯"
            elif dim_key == "T":
                if "深夜" in tag: suggestion = "场景光照预设：月光+路灯+应急灯"
                if "快速蔓延" in tag: suggestion = "火势扩展速度参数≥2层/分钟"
                if "闪燃" in tag: suggestion = "爆发性事件触发器，倒计时+视觉警告"
                if "疏散耗时" in tag: suggestion = "玩家步速×楼层数=预计时间，与火势赛跑"
            elif dim_key == "B":
                if "高温" in tag: suggestion = "屏幕边缘热度渐晕+呼吸音效加速"
                if "呼吸困难" in tag: suggestion = "耐力条加速消耗+屏效颗粒感"
                if "烟雾刺激" in tag: suggestion = "咳嗽音效触发+短暂视线模糊"
                if "老年人步速" in tag: suggestion = "移动速度降至0.4-0.6x，楼梯更慢"
                if "轮椅" in tag: suggestion = "楼梯完全不可通过，强制等待救援路线"
                if "跌倒" in tag: suggestion = "概率事件（体力<20%时触发）"
            elif dim_key == "C":
                if "拥挤" in tag: suggestion = "NPC人群碰撞+移动减速"
                if "互助逃生" in tag: suggestion = "NPC可响应玩家求助/提供线索"
                if "等待救援" in tag: suggestion = "固定位置等待+焦虑倒计时"
                if "老年人" in tag: suggestion = "衰减步速+增加喘息停顿"
                if "儿童" in tag: suggestion = "摄像机高度降至105cm+视线遮挡"
                if "宠物" in tag: suggestion = "跟随AI+可能走失的分支事件"
            lines.append(f"| {tag} | {cnt} | {suggestion} |")
    else:
        lines.append("*(无标签命中)*")
    lines.append("")

# 提取关键数字汇总
lines.append("## 关键场景参数汇总")
lines.append("")
all_nums = Counter()
for r in tagged:
    ns = r.get("extracted_numbers", "")
    if ns:
        try:
            for k, v in json.loads(ns).items():
                all_nums[f"{k}={v}"] += 1
        except:
            pass
if all_nums:
    lines.append("| 参数 | 频率 | VR应用 |")
    lines.append("|:---|:---|:---|")
    for nv, cnt in all_nums.most_common(20):
        lines.append(f"| {nv} | {cnt} | - |")
lines.append("")

# S+/S级精选案例
lines.append("## S+/S级精选案例")
lines.append("")
s_count = 0
for r in tagged:
    if r.get("scene_tier") in ("S+", "S") and r.get("content_quality") == "有正文":
        s_count += 1
        if s_count > 15:
            break
        title = r.get("title", "")[:80]
        lines.append(f"### [{r['scene_tier']}] {title}")
        lines.append(f"- **场景标签**: {r.get('scene_tags', '')}")
        lines.append(f"- **关键数字**: {r.get('extracted_numbers', '')}")
        content = r.get("content", "")[:300].replace("\n", " ")
        lines.append(f"- **正文摘要**: {content}...")
        lines.append("")

lines.append("## 使用方法")
lines.append("")
lines.append("1. 从打标CSV筛选 `scene_tier` = S+ 或 S，优先阅读正文")
lines.append("2. 按六维标签（S/A/V/T/B/C）分类提取可建模的场景元素")
lines.append("3. 对有 `extracted_numbers` 的记录提取具体参数（楼层/时间/人数）")
lines.append("4. 交叉引用多个同类型新闻验证场景参数的典型性")
lines.append("")

with open(OUT_MEMO, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

# JSON统计
json_out = {
    "total_records": len(all_rows),
    "has_content": sum(1 for r in tagged if r.get("content_quality") == "有正文"),
    "tier_distribution": dict(tier_counts),
    "dimension_stats": {dim: dict(cnt) for dim, cnt in dim_stats.items()},
    "generated_at": TODAY,
}
with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(json_out, f, ensure_ascii=False, indent=2)

print(f"Memo: {OUT_MEMO}")
print(f"JSON: {OUT_JSON}")

print("\n=== 场景还原度分布 ===")
for t in ["S+", "S", "A", "B", "C"]:
    print(f"  Tier {t}: {tier_counts.get(t, 0)}")
print(f"\n维度覆盖:")
for dim_key, (dim_name, sub_groups) in dim_names.items():
    cnt = len(dim_stats[dim_key])
    print(f"  {dim_key}({dim_name[0]}): {cnt} 个标签命中")
