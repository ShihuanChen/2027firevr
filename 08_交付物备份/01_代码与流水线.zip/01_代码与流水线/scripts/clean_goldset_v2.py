# -*- coding: utf-8 -*-
"""
金标准 v2 净化：剔除乱码/空标题/重复/明显无关，从原分层池补充替代条目，保持 180 条。
"""
import csv, os, random, re
from collections import Counter

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")
GOLD = os.path.join(D, "_goldset_v2_分层抽样.csv")
OUT = os.path.join(D, "_goldset_v2_分层抽样_净化.csv")

# 明显无关/垃圾特征
JUNK_PAT = [
    re.compile(r"what are we playing|game review|unearthing a glorious|sponsored|advertorial", re.I),
    re.compile(r"^[\?\?？\s]+$"),  # 纯乱码/问号标题
]
def is_bad(title):
    t = (title or "").strip()
    if not t:
        return True
    if len(t) < 12:
        return True
    if any(p.search(t) for p in JUNK_PAT):
        return True
    return False

def norm(t):
    t = t.lower()
    t = re.sub(r"[^a-z0-9\u4e00-\u9fff ]", "", t)
    return " ".join(t.split())

# 读取现有抽样
rows = []
with open(GOLD, encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        rows.append(r)

# 标记坏条目
bad_idx = []
seen = {}
for i, r in enumerate(rows):
    nt = norm(r["标题"])
    if is_bad(r["标题"]) or nt in seen:
        bad_idx.append(i)
        continue
    seen[nt] = i
print(f"坏/重复条目: {len(bad_idx)}")

# 重新从全量池挑替代（排除旧 goldset 1-103、已选 gid、坏 gid）
keep_gids = {r["编号"] for j, r in enumerate(rows) if j not in bad_idx}
pool = []
with open(SRC, encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        gid = i + 1
        if gid <= 103 or str(gid) in keep_gids:
            continue
        title = row[1] if len(row) > 1 else ""
        body = row[4] if len(row) > 4 else ""
        if len(body or "") < 400 or is_bad(title):
            continue
        pool.append({"gid": gid, "title": title, "body": body, "L": len(body)})
print(f"替代候选池: {len(pool)}")

random.seed(20260803)
subs = random.sample(pool, len(bad_idx))
# 替换坏条目（保持原位置顺序大致稳定：把替代条目按 gid 插入排序）
for i, sub in zip(bad_idx, subs):
    rows[i] = {"编号": sub["gid"], "标题": sub["title"][:80], "字数": sub["L"],
               "分层特征": "REPLACED", "正文(前2500)": sub["body"][:2500].replace("\n", " ").replace("\r", ""),
               "用户填1/0": ""}

# 按编号排序便于阅读
rows.sort(key=lambda r: int(r["编号"]))

with open(OUT, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(list(rows[0].keys()))
    for r in rows:
        w.writerow([r[k] for k in rows[0].keys()])

print(f"输出: {OUT}, 共 {len(rows)} 条")

# 复查
titles2 = [norm(r["标题"]) for r in rows]
dups = {k: v for k, v in Counter(titles2).items() if v > 1}
bads = sum(1 for r in rows if is_bad(r["标题"]))
print(f"复查: 重复组 {len(dups)}, 坏条目 {bads}")
