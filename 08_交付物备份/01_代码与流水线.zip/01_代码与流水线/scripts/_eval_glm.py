# -*- coding: utf-8 -*-
"""决定性验证：GLM 语义票在 GoldSet 103 上的 P/R/F1（与 committee 联合）。"""
import csv, os, sys, re, json, urllib.request, time

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

# 读取 config（PyYAML）
config = {}
try:
    import yaml
    with open(os.path.join(D, "config.yaml"), encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    cred = cfg.get("credentials", {}) or {}
    config = {k: str(cred[k]).strip() for k in ("api_key", "base_url", "model_name") if k in cred}
except Exception as e:
    print("config 读取失败:", e)
print("config:", {k: (v[:8] + "..." if k == "api_key" else v) for k, v in config.items()})

def glm_vote(title, body):
    """调用 GLM 判断是否适合 VR 重建，返回 K/D + 原始回答"""
    url = config.get("base_url", "").rstrip("/") + "/chat/completions"
    prompt = (
        "你是新闻语料筛选专家。判断这篇火灾报道是否适合用于VR场景重建："
        "它是否包含可重建的空间细节（楼层/走廊/楼梯/房间布局）、身体动作、感官描写（烟雾/声音/温度）、"
        "或弱势群体（老人/儿童/残障/孕妇）的逃生经历？"
        "只回答一个字母：K=适合重建(保留), D=不适合(剔除)。\n\n标题: "
        + (title or "")[:200] + "\n正文: " + (body or "")[:1500]
    )
    req = urllib.request.Request(
        url,
        data=json.dumps({"model": config.get("model_name", ""),
                         "messages": [{"role": "user", "content": prompt}],
                         "temperature": 0}).encode("utf-8"),
        headers={"Authorization": "Bearer " + config.get("api_key", ""),
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = json.loads(r.read().decode("utf-8"))
    ans = data["choices"][0]["message"]["content"].strip().upper()
    return ans

# 加载数据
rows = []
with open(os.path.join(D, "第三轮_含正文_筛选草稿.csv"), encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        rows.append({"gid": i + 1, "title": row[1] if len(row) > 1 else "",
                     "body": row[4] if len(row) > 4 else ""})

gold = []
with open(os.path.join(D, "人机协作_GoldSet_103.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        lab = str(r.get("keep_label", "")).strip()
        if lab in ("1", "0.5", "0"):
            i = int(r["idx"])
            gold.append({"label": 1 if lab in ("1", "0.5") else 0,
                         "title": rows[i-1]["title"], "body": rows[i-1]["body"]})

# 跑 GLM
TP = FP = TN = FN = 0
detail = []
for g in gold:
    ans = glm_vote(g["title"], g["body"])
    pred = 1 if ans.startswith("K") else 0
    if pred == 1 and g["label"] == 1: TP += 1
    elif pred == 1 and g["label"] == 0: FP += 1
    elif pred == 0 and g["label"] == 1: FN += 1
    else: TN += 1
    detail.append((g["label"], pred, ans))
    time.sleep(0.3)

P = TP / (TP + FP) if TP + FP else 0
R = TP / (TP + FN) if TP + FN else 0
F1 = 2 * P * R / (P + R) if P + R else 0
acc = (TP + TN) / len(gold)

print("\n=== GLM 语义票在 GoldSet 103 上的评估 ===")
print(f"混淆矩阵   AI=保留   AI=剔除")
print(f"人工保留11  {TP:>4}     {FN:>4}")
print(f"人工剔除92  {FP:>4}     {TN:>4}")
print(f"\nPrecision = {P:.1%}")
print(f"Recall    = {R:.1%}")
print(f"F1        = {F1:.1%}")
print(f"Accuracy  = {acc:.1%}")
print(f"误留率    = {FP/(TP+FP) if TP+FP else 0:.1%}")
print(f"误删率    = {FN/(TP+FN) if TP+FN else 0:.1%}")
