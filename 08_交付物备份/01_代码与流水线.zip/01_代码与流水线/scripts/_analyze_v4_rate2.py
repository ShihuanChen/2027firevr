# -*- coding: utf-8 -*-
"""分析 v4 76 条保留率（直接从 xlsx 读，正确处理'以下全是0'）。"""
import openpyxl, os

D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
p = r"C:\Users\Administrator\Desktop\_批量试跑v4_78条交付.xlsx"

wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
v4 = {}
for row in wb.active.iter_rows(values_only=True):
    if row[0] is None or str(row[0]).strip() in ("编号", ""):
        continue
    gid = int(float(row[0]))
    v = str(row[4]).strip() if len(row) > 4 and row[4] is not None else ""
    v4[gid] = 1 if v == "1" else 0

keep = {g for g, v in v4.items() if v == 1}
drop = {g for g, v in v4.items() if v == 0}
print(f"v4 共 {len(v4)} 条: 用户保留 {len(keep)} 剔 {len(drop)}")
print(f"Grok判K→用户保留率: {len(keep)/len(v4):.1%}")

total_cand = 6742
est_route = total_cand * 0.26
est_keep = total_cand * len(keep) / len(v4)
print(f"\n全量估算（候选 6742，判K率26%）:")
print(f"  Grok 判 K（路由给人）: ~{est_route:.0f} 条")
print(f"  其中用户预计保留: ~{est_keep:.0f} 条")

print("\n=== 用户保留的 4 条 ===")
for g in sorted(keep):
    print(f"  gid{g}")
