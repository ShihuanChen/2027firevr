#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增量文献检索与去重工具
Task 1: Incremental Literature Retrieval with Absolute Deduplication
"""

import csv
import hashlib
from urllib.parse import urlparse, parse_qs, urljoin
import re
from datetime import datetime
from pathlib import Path

class URLNormalizer:
    """标准化URL，用于精确去重"""

    @staticmethod
    def normalize_url(url):
        """去除UTM、锚点、移动端参数"""
        # 移除查询参数中的跟踪参数
        parsed = urlparse(url)

        # 去除的参数列表
        skip_params = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_content',
                      'fbclid', 'gclid', 'msclkid', 'ref', 'src'}

        query_params = parse_qs(parsed.query, keep_blank_values=True)
        cleaned_params = {k: v for k, v in query_params.items()
                         if k.lower() not in skip_params}

        # 重建URL（不含锚点和追踪参数）
        if cleaned_params:
            new_query = '&'.join([f"{k}={v[0]}" for k, v in cleaned_params.items()])
            canonical = f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}"
        else:
            canonical = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"

        return canonical.lower()

    @staticmethod
    def extract_domain(url):
        """提取域名"""
        parsed = urlparse(url)
        return parsed.netloc

class TextNormalizer:
    """标准化文本用于相似度比对"""

    @staticmethod
    def normalize_title(title):
        """标题标准化：小写、删除标点、多余空格"""
        title = title.lower()
        title = re.sub(r'[^\w\s一-鿿]', '', title)  # 保留汉字和字母
        title = re.sub(r'\s+', ' ', title).strip()
        return title

    @staticmethod
    def compute_text_hash(title, body_excerpt):
        """计算标题+正文前500字的哈希"""
        text = f"{title}|{body_excerpt[:500]}"
        return hashlib.md5(text.encode('utf-8')).hexdigest()

class DeduplicationEngine:
    """去重引擎"""

    def __init__(self, existing_registry_path=None):
        """初始化已有的registry"""
        self.registry = {}
        self.url_registry = {}
        self.event_registry = {}

        if existing_registry_path and Path(existing_registry_path).exists():
            self.load_registry(existing_registry_path)

    def load_registry(self, filepath):
        """加载已有的source_registry"""
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                self.url_registry[row['canonical_url']] = row
                self.event_registry[row['event_key']] = row

    def check_dedup_status(self, url, title, body_excerpt, event_key, published_date):
        """检查重复状态"""

        canonical_url = URLNormalizer.normalize_url(url)
        domain = URLNormalizer.extract_domain(url)
        title_norm = TextNormalizer.normalize_title(title)
        hash_value = TextNormalizer.compute_text_hash(title, body_excerpt)

        result = {
            'canonical_url': canonical_url,
            'domain': domain,
            'title_norm': title_norm,
            'event_key': event_key,
            'published_date': published_date,
            'hash_title_body': hash_value,
            'duplicate_status': 'new',
            'decision': 'pending',
            'reason': ''
        }

        # 1. URL完全一致 -> same_url
        if canonical_url in self.url_registry:
            result['duplicate_status'] = 'same_url'
            result['decision'] = 'exclude'
            result['reason'] = '相同URL'
            return result

        # 2. 事件键相同 -> 检查是否同一事件的不同报道
        if event_key in self.event_registry:
            existing = self.event_registry[event_key]

            # 2a. 哈希相同 -> 几乎相同文本
            if hash_value == existing['hash_title_body']:
                result['duplicate_status'] = 'near_duplicate'
                result['decision'] = 'pending'  # 需要人工判断
                result['reason'] = '文本相似度极高'
                return result

            # 2b. 同标题、同发布时间 -> 转载
            if (title_norm == existing['title_norm'] and
                published_date == existing['published_date']):
                result['duplicate_status'] = 'syndication'
                result['decision'] = 'pending'
                result['reason'] = '可能是转载，需检查信息增量'
                return result

        # 3. 都通过 -> 新数据
        result['duplicate_status'] = 'new'
        result['decision'] = 'pending'
        result['reason'] = '新增数据'
        return result

class IncrementSearchManager:
    """增量检索管理器"""

    # 推荐的检索式（中英文）
    SEARCH_QUERIES = {
        'chinese': [
            '高层 火灾 疏散 老人 OR 残疾 OR 孕妇 OR 儿童',
            '火灾 警报 听障 聋人 疏散',
            '火灾 疏散 视障 盲人 楼梯 烟雾',
            '养老院 高层 火灾 疏散 老人 行动不便',
            '公寓 火灾 儿童 楼梯 烟雾 逃生',
            '火灾 调查报告 疏散 残疾人 高层',
        ],
        'english': [
            '"high-rise fire" evacuation disability resident',
            '"fire alarm" deaf "hard of hearing" evacuation',
            '"visually impaired" fire evacuation stairs smoke',
            '"older adults" fire evacuation "walking speed" smoke stairs',
            'children fire evacuation smoke "walking speed" stairs',
            '"pregnant women" fire evacuation "high-rise" mobility',
        ]
    }

    # 优先来源
    PRIORITY_SOURCES = [
        'NIST高层疏散研究',
        'GOV.UK高层住宅火灾疏散快速证据综述',
        'NFPA残障人士疏散指南',
        'Fire Safety Journal',
        'Safety Science',
        'Buildings期刊',
        'ACM CHI',
        'IEEE VR',
        'DIS',
        'TVCG'
    ]

def generate_dedup_report(dedup_results, output_path='dedup_report.csv'):
    """生成去重报告"""
    fieldnames = ['canonical_url', 'domain', 'title_norm', 'event_key',
                  'published_date', 'hash_title_body', 'duplicate_status',
                  'decision', 'reason']

    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for result in dedup_results:
            writer.writerow({k: result.get(k, '') for k in fieldnames})

    print(f"去重报告已生成: {output_path}")

if __name__ == "__main__":
    # 示例使用
    print("=" * 60)
    print("VR灾害叙事项目 - 增量检索与去重工具")
    print("=" * 60)

    # 初始化去重引擎
    engine = DeduplicationEngine()

    # 测试URL标准化
    test_url = "https://example.com/article/123?utm_source=facebook&ref=test#section"
    normalized = URLNormalizer.normalize_url(test_url)
    print(f"\n测试URL标准化:")
    print(f"  原始: {test_url}")
    print(f"  标准化: {normalized}")

    # 显示推荐的检索策略
    print(f"\n推荐的中文检索式:")
    for i, query in enumerate(IncrementSearchManager.SEARCH_QUERIES['chinese'], 1):
        print(f"  {i}. {query}")

    print(f"\n推荐的英文检索式:")
    for i, query in enumerate(IncrementSearchManager.SEARCH_QUERIES['english'], 1):
        print(f"  {i}. {query}")

    print(f"\n优先纳入的权威来源:")
    for source in IncrementSearchManager.PRIORITY_SOURCES:
        print(f"  - {source}")
