#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二轮筛选+打标：从119篇正文中提取VR高层火灾系统设计标准
输出：
  1. 打标后的CSV（含11个VR相关维度）
  2. 筛选统计报告
  3. VR设计标准提取摘要
"""
import csv, os, re, json
from datetime import datetime
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT  = os.path.join(ROOT, "data", "高层火灾新闻可用精选_20260701.csv")
TODAY  = datetime.now().strftime("%Y%m%d")
OUT_TAGGED  = os.path.join(ROOT, "data", f"高层火灾_第二轮打标_{TODAY}.csv")
OUT_REPORT  = os.path.join(ROOT, "data", f"VR设计标准提取_{TODAY}.md")
OUT_STATS   = os.path.join(ROOT, "data", f"第二轮统计_{TODAY}.json")

# ============================================================
# 1. VR设计维度定义
# ============================================================
FIRE_CAUSES = {
    "electrical":    [r"electrical\s*(fire|fault|intake|room|short)", r"wiring", r"power\s*surge", r"overload"],
    "gas_leak":      [r"gas\s*leak", r"gas\s*explosion", r"natural\s*gas", r"LPG", r"propane", r"pipeline"],
    "cooking":       [r"cooking", r"kitchen\s*fire", r"stove", r"unattended\s*(cooking|food|pan|pot)"],
    "arson":         [r"arson", r"deliberately\s*set", r"suspect.*fire", r"intentionally.*set"],
    "lithium_battery":[r"lithium", r"battery\s*fire", r"e-bike", r"e-scooter", r"charg(?:ing|er)"],
    "smoking":       [r"cigarette", r"smoking", r"discarded\s*cigarette"],
    "heater":        [r"space\s*heater", r"heater", r"heating\s*device"],
    "candle":        [r"candle", r"incense"],
    "chimney":       [r"chimney", r"fireplace"],
    "unknown":       [],
}

BUILDING_TYPES = {
    "high_rise":    [r"high.?rise", r"tower\s*block", r"\d{2,}\s*[- ]?story", r"\d{2,}\s*[- ]?storey", r"\d{2,}\s*[- ]?floor\s*building", r"skyscraper", r"高楼", r"高层"],
    "mid_rise":     [r"\b([4-9]|1[0-1])\s*[- ]?(?:story|storey|floor)\b", r"mid.?rise"],
    "low_rise":     [r"\b[1-3]\s*[- ]?(?:story|storey|floor)\b", r"two.?story", r"three.?story"],
    "apartment":    [r"apartment", r"flat", r"condo", r"公寓", r"住宅楼"],
    "office_tower": [r"office\s*(?:building|tower|block)", r"commercial\s*building"],
    "residential":  [r"residential", r"housing\s*complex", r"居民"],
}

RESCUE_METHODS = {
    "ladder_rescue":    [r"ladder", r"aerial\s*platform", r"truck.*rescued"],
    "window_rescue":    [r"window.*rescue", r"rescued.*window", r"balcony.*rescue"],
    "stairwell_evac":   [r"stairwell", r"staircase", r"stairs", r"楼梯", r"evacuat"],
    "firefighter_carry": [r"carried\s*out", r"firefighter.*carried", r"removed.*unconscious"],
    "self_evac":        [r"self.?evacuat", r"escaped", r"fled", r"got\s*out"],
}

SMOKE_PATTERNS = {
    "stairwell_smoke":  [r"smoke.*stairwell", r"stairwell.*smoke", r"楼梯.*烟"],
    "floor_spread":     [r"spread.*floor", r"floor.*spread", r"filled.*floor"],
    "entire_building":  [r"entire\s*building", r"throughout.*building", r"filled.*building"],
    "black_smoke":      [r"black\s*smoke", r"thick\s*smoke", r"heavy\s*smoke", r"浓烟"],
    "toxic_smoke":      [r"toxic\s*smoke", r"poisonous", r"有毒"],
    "zero_visibility":  [r"(?:couldn'?t|could\s*not)\s*see", r"zero\s*visibility", r"no\s*visibility", r"看不(?:见|清)"],
}

HUMAN_BEHAVIORS = {
    "panic":            [r"panic", r"chaos", r"scream", r"混乱", r"恐慌"],
    "helping_others":   [r"help(?:ed|ing)?\s*(?:other|neighbor)", r"rescued\s*(?:other|neighbor)", r"knocking.*doors", r"alert(?:ed|ing)"],
    "return_inside":    [r"went\s*back\s*(?:in|inside)", r"re.?enter", r"returned.*inside"],
    "refuse_evac":      [r"refuse.*evacuat", r"refuse.*leave", r"不愿.*离开"],
    "pet_rescue":       [r"pet.*rescue", r"rescued.*(?:dog|cat|pet)", r"(?:dog|cat).*rescue"],
    "child_rescue":     [r"child.*rescue", r"baby.*rescue", r"carried.*child"],
}

CASUALTY_PATTERNS = {
    "death":        [r"(?:killed|dead|died|death|fatal|丧生|死亡|烧死)", r"charred\s*to\s*death"],
    "serious_injury":[r"serious(?:ly)?\s*(?:injur|hurt)", r"critical", r"hospitali[sz]ed", r"burn\s*center", r"重伤"],
    "minor_injury":  [r"minor\s*(?:injur|hurt)", r"smoke\s*inhalation", r"treated.*scene", r"轻伤"],
    "no_injury":     [r"no\s*(?:one|injuries|reported)", r"uninjured", r"unhurt", r"无人.*伤亡"],
}

SENSORY_DETAILS = {
    "sound_explosion":  [r"explosion", r"blast", r"boom", r"爆炸"],
    "sound_alarm":      [r"(?:fire\s*)?alarm", r"siren", r"警报"],
    "smell":            [r"smell(?:ed)?", r"odor", r"气味", r"闻到"],
    "heat_feel":        [r"heat", r"hot", r"灼热", r"滚烫"],
    "visual_flames":    [r"flame", r"fire\s*visible", r"火焰", r"火光"],
}

VR_RELEVANCE = {
    "scenario_design":      [r"scenario", r"场景"],
    "evacuation_challenge": [r"trapped", r"stuck", r"被困", r"无法.*逃"],
    "elderly_vulnerable":   [r"elderly", r"senior", r"老年人?", r"old\s*(?:woman|man|person)"],
    "child_vulnerable":     [r"child(?:ren)?", r"baby", r"infant", r"儿童", r"小孩"],
    "disability_vulnerable":[r"disab(?:led|ility)", r"wheelchair", r"残疾人?"],
    "pet_involved":         [r"pet", r"dog", r"cat", r"宠物", r"猫", r"狗"],
}

ALL_DIMS = {
    "fire_cause": FIRE_CAUSES,
    "building_type": BUILDING_TYPES,
    "rescue_method": RESCUE_METHODS,
    "smoke_pattern": SMOKE_PATTERNS,
    "human_behavior": HUMAN_BEHAVIORS,
    "casualty_level": CASUALTY_PATTERNS,
    "sensory_detail": SENSORY_DETAILS,
    "vr_relevance": VR_RELEVANCE,
}

def tag_text(text):
    """对一段文本打所有维度的标签"""
    if not text:
        return {k: [] for k in ALL_DIMS}
    text_lower = text.lower()
    tags = {}
    for dim, subdims in ALL_DIMS.items():
        tags[dim] = []
        for label, patterns in subdims.items():
            if label == "unknown":
                continue
            for pat in patterns:
                if re.search(pat, text_lower):
                    if label not in tags[dim]:
                        tags[dim].append(label)
                    break
        if not tags[dim] and dim == "fire_cause":
            tags[dim].append("unknown")
        elif not tags[dim] and dim == "building_type":
            # Try to infer from title
            pass
    return tags

def extract_casualty_numbers(text):
    """提取伤亡数字"""
    if not text:
        return "N/A"
    nums = []
    # 死亡
    m = re.search(r"(\d+)\s*(?:people|person|residents?|victims?|individuals?).*?(?:kill|dead|died|death|fatal)", text, re.I)
    if m: nums.append(f"{m.group(1)} dead")
    # 受伤
    m = re.search(r"(\d+)\s*(?:people|person|residents?|victims?).*?(?:injur|hurt|hospitali)", text, re.I)
    if m: nums.append(f"{m.group(1)} injured")
    # 送医
    m = re.search(r"(\d+)\s*(?:people|person|residents?).*?(?:transported|taken|rushed)\s*to\s*(?:hospital|burn)", text, re.I)
    if m: nums.append(f"{m.group(1)} hospitalized")
    # 疏散/流离失所
    m = re.search(r"(\d+)\s*(?:people|resident|household|family|unit)s?\s*(?:displaced|evacuat)", text, re.I)
    if m: nums.append(f"{m.group(1)} displaced")
    return "; ".join(nums) if nums else "N/A"

def extract_fire_spread_info(text):
    """提取火势蔓延关键信息"""
    if not text: return "N/A"
    info = []
    m = re.search(r"(?:fire\s*was\s*)?contained?\s*(?:to|within?)\s*(?:a\s*)?(single\s*unit|one\s*unit|one\s*apartment|one\s*room|the\s*unit)", text, re.I)
    if m: info.append(f"contained_to={m.group(1)}")
    m = re.search(r"spread\s*(?:to|across|through)\s*(?:the\s*)?(\w+(?:\s+\w+){0,3})", text, re.I)
    if m: info.append(f"spread_to={m.group(1)}")
    m = re.search(r"(\d+)\s*(?:units?|apartments?|flats?)\s*(?:affected|damaged|displaced)", text, re.I)
    if m: info.append(f"units_affected={m.group(1)}")
    return "; ".join(info) if info else "N/A"

def quality_score(tags, text):
    """综合评分：内容越丰富、VR相关性越高，分数越高"""
    if not text: return 1
    score = 0
    # 有正文 +2
    score += 2
    # 正文长度
    if len(text) > 500: score += 2
    elif len(text) > 200: score += 1
    # 有伤亡信息
    if tags["casualty_level"]: score += len(tags["casualty_level"])
    # 有救援方法
    if tags["rescue_method"]: score += len(tags["rescue_method"])
    # 有人类行为
    if tags["human_behavior"]: score += len(tags["human_behavior"])
    # 有感官细节
    if tags["sensory_detail"]: score += len(tags["sensory_detail"])
    # 有烟雾描述
    if tags["smoke_pattern"]: score += len(tags["smoke_pattern"])
    return score

def tier_from_score(score):
    if score >= 10: return "S"       # 最佳VR素材
    elif score >= 7: return "A"      # 优秀
    elif score >= 5: return "B"      # 良好
    elif score >= 3: return "C"      # 可用
    else: return "D"                  # 参考

# ============================================================
# 2. 读取 & 分析
# ============================================================
print("="*60)
print("第二阶段：VR维度打标 & 筛选")
print("="*60)

with open(INPUT, "r", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    all_rows = list(reader)

print(f"输入记录总数: {len(all_rows)}")

# 分类：有正文 vs 仅有标题
has_content = []
title_only = []
for r in all_rows:
    c = (r.get("content") or "").strip()
    if c and len(c) > 50 and not c.startswith("error:") and not c.startswith("We're Sorry"):
        has_content.append(r)
    else:
        title_only.append(r)

print(f"有有效正文: {len(has_content)}")
print(f"仅有标题: {len(title_only)}")

# 打标
tagged = []
for r in has_content:
    text = (r.get("title") or "") + "\n" + (r.get("content") or "")
    tags = tag_text(text)
    qs = quality_score(tags, text)
    tier = tier_from_score(qs)
    casualty = extract_casualty_numbers(text)
    fire_spread = extract_fire_spread_info(text)
    tagged.append({
        **r,
        "fire_cause": ";".join(tags["fire_cause"]),
        "building_type": ";".join(tags["building_type"]),
        "rescue_method": ";".join(tags["rescue_method"]),
        "smoke_pattern": ";".join(tags["smoke_pattern"]),
        "human_behavior": ";".join(tags["human_behavior"]),
        "casualty_level": ";".join(tags["casualty_level"]),
        "sensory_detail": ";".join(tags["sensory_detail"]),
        "vr_relevance": ";".join(tags["vr_relevance"]),
        "quality_tier": tier,
        "quality_score": str(qs),
        "casualty_summary": casualty,
        "fire_spread_info": fire_spread,
        "round2_status": "内容分析完成",
    })

# 标题仅打少量标签
for r in title_only:
    title = r.get("title", "")
    t = tag_text(title)
    # 只对标题做基本分类
    tagged.append({
        **r,
        "fire_cause": ";".join(t["fire_cause"]) or "unknown",
        "building_type": ";".join(t["building_type"]),
        "rescue_method": ";".join(t["rescue_method"]),
        "smoke_pattern": "",
        "human_behavior": "",
        "casualty_level": ";".join(t["casualty_level"]),
        "sensory_detail": "",
        "vr_relevance": "",
        "quality_tier": "D",
        "quality_score": "1",
        "casualty_summary": "N/A",
        "fire_spread_info": "N/A",
        "round2_status": "仅有标题",
    })

print(f"打标完成，共 {len(tagged)} 条")

# ============================================================
# 3. 输出打标CSV
# ============================================================
FIELD_ORDER = [
    "title", "url", "source", "published_at", "language",
    "fire_cause", "building_type", "rescue_method", "smoke_pattern",
    "human_behavior", "casualty_level", "sensory_detail", "vr_relevance",
    "quality_tier", "quality_score", "casualty_summary", "fire_spread_info",
    "content", "fetch_status", "screening_status", "round2_status",
    "origin_file", "notes",
]

with open(OUT_TAGGED, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.DictWriter(f, fieldnames=FIELD_ORDER, extrasaction="ignore")
    writer.writeheader()
    for r in sorted(tagged, key=lambda x: (-int(x.get("quality_score", "0")), x.get("title", ""))):
        writer.writerow(r)

print(f"打标CSV已输出: {OUT_TAGGED}")

# ============================================================
# 4. 统计 & 生成报告
# ============================================================
# 统计各维度
stats = {}
for dim in ALL_DIMS:
    cnt = Counter()
    for r in tagged:
        vals = r.get(dim, "")
        if vals:
            for v in vals.split(";"):
                v = v.strip()
                if v:
                    cnt[v] += 1
    stats[dim] = dict(cnt.most_common())

tier_dist = Counter(r["quality_tier"] for r in tagged)

# JSON统计
json_stats = {
    "total_input": len(all_rows),
    "has_content": len(has_content),
    "title_only": len(title_only),
    "dimension_stats": {k: dict(v) for k, v in stats.items()},
    "tier_distribution": dict(tier_dist.most_common()),
    "generated_at": TODAY,
}

with open(OUT_STATS, "w", encoding="utf-8") as f:
    json.dump(json_stats, f, ensure_ascii=False, indent=2)
print(f"统计JSON: {OUT_STATS}")

# ============================================================
# 5. VR设计标准提取报告 (Markdown)
# ============================================================
report_lines = []
report_lines.append(f"# 高层火灾新闻分析 — VR系统设计标准提取")
report_lines.append(f"> 生成时间: {TODAY} | 分析记录: {len(has_content)} 篇有正文新闻")
report_lines.append("")

# ---- Tier分布 ----
report_lines.append("## 一、素材质量分布")
report_lines.append("")
report_lines.append("| Tier | 条数 | 含义 |")
report_lines.append("|:---|:---|:---|")
for t in ["S", "A", "B", "C", "D"]:
    cnt = tier_dist.get(t, 0)
    meaning = {"S": "最佳VR场景素材（丰富细节+多维标签）", "A": "优秀（多维度信息齐全）",
               "B": "良好（有正文但细节有限）", "C": "可用（有正文但信息较单薄）",
               "D": "参考（仅标题或低质正文）"}[t]
    report_lines.append(f"| **{t}** | {cnt} | {meaning} |")
report_lines.append("")

# ---- 各维度分析 ----
dim_labels = {
    "fire_cause": ("火灾原因", "fire_cause"),
    "building_type": ("建筑类型", "building_type"),
    "rescue_method": ("救援方式", "rescue_method"),
    "smoke_pattern": ("烟雾蔓延模式", "smoke_pattern"),
    "human_behavior": ("人类行为特征", "human_behavior"),
    "casualty_level": ("伤亡等级", "casualty_level"),
    "sensory_detail": ("感官细节", "sensory_detail"),
    "vr_relevance": ("VR场景相关性", "vr_relevance"),
}

report_lines.append("## 二、各维度标签分布")
report_lines.append("")
for dim_key, (label, col_name) in dim_labels.items():
    report_lines.append(f"### {label}")
    report_lines.append("")
    dim_stats = stats.get(dim_key, {})
    if dim_stats:
        report_lines.append("| 标签 | 出现次数 | 占比 |")
        report_lines.append("|:---|:---|:---|")
        total = sum(dim_stats.values())
        for tag, cnt in sorted(dim_stats.items(), key=lambda x: -x[1]):
            pct = f"{100*cnt/total:.1f}%" if total else "0%"
            report_lines.append(f"| {tag} | {cnt} | {pct} |")
    else:
        report_lines.append("*(无标签命中)*")
    report_lines.append("")

# ---- S/A Tier 精选案例 ----
report_lines.append("## 三、S/A级精选案例（VR场景设计直接参考）")
report_lines.append("")
for r in tagged:
    if r["quality_tier"] in ("S", "A"):
        title = r.get("title", "")[:100]
        report_lines.append(f"### [{r['quality_tier']}级] {title}")
        report_lines.append(f"- **火灾原因**: {r.get('fire_cause', 'N/A')}")
        report_lines.append(f"- **建筑类型**: {r.get('building_type', 'N/A')}")
        report_lines.append(f"- **救援方式**: {r.get('rescue_method', 'N/A')}")
        report_lines.append(f"- **烟雾模式**: {r.get('smoke_pattern', 'N/A')}")
        report_lines.append(f"- **人类行为**: {r.get('human_behavior', 'N/A')}")
        report_lines.append(f"- **伤亡**: {r.get('casualty_summary', 'N/A')}")
        report_lines.append(f"- **感官细节**: {r.get('sensory_detail', 'N/A')}")
        report_lines.append(f"- **VR相关**: {r.get('vr_relevance', 'N/A')}")
        report_lines.append(f"- **火势信息**: {r.get('fire_spread_info', 'N/A')}")
        # 截取正文摘要
        content = r.get("content", "")[:300].replace("\n", " ")
        report_lines.append(f"- **正文摘要**: {content}...")
        report_lines.append("")

# ---- VR系统设计建议 ----
report_lines.append("## 四、VR高层火灾系统设计建议（基于新闻分析）")
report_lines.append("")

# 从统计中总结
fire_causes_top = stats.get("fire_cause", {})
report_lines.append("### 4.1 火灾起因场景设计")
report_lines.append("")
report_lines.append("根据119篇有正文新闻统计，建议VR系统覆盖以下起火原因场景：")
report_lines.append("")
if fire_causes_top:
    for cause, cnt in sorted(fire_causes_top.items(), key=lambda x: -x[1])[:6]:
        report_lines.append(f"- **{cause}** ({cnt}篇)")

building_top = stats.get("building_type", {})
report_lines.append("")
report_lines.append("### 4.2 建筑类型覆盖建议")
report_lines.append("")
if building_top:
    for bt, cnt in sorted(building_top.items(), key=lambda x: -x[1])[:6]:
        report_lines.append(f"- **{bt}** ({cnt}篇)")

rescue_top = stats.get("rescue_method", {})
report_lines.append("")
report_lines.append("### 4.3 救援/逃生方式设计")
report_lines.append("")
if rescue_top:
    for rm, cnt in sorted(rescue_top.items(), key=lambda x: -x[1])[:8]:
        report_lines.append(f"- **{rm}** ({cnt}篇)")

smoke_top = stats.get("smoke_pattern", {})
report_lines.append("")
report_lines.append("### 4.4 烟雾系统设计要点")
report_lines.append("")
report_lines.append("新闻中频繁出现的烟雾特征，建议VR烟雾系统重点模拟：")
report_lines.append("")
if smoke_top:
    for sp, cnt in sorted(smoke_top.items(), key=lambda x: -x[1])[:6]:
        report_lines.append(f"- **{sp}** ({cnt}篇)")

behavior_top = stats.get("human_behavior", {})
report_lines.append("")
report_lines.append("### 4.5 NPC/AI行为建模")
report_lines.append("")
report_lines.append("新闻中提取的人类行为模式，可用于VR中NPC行为设计：")
report_lines.append("")
if behavior_top:
    for bh, cnt in sorted(behavior_top.items(), key=lambda x: -x[1])[:8]:
        report_lines.append(f"- **{bh}** ({cnt}篇)")

sensory_top = stats.get("sensory_detail", {})
report_lines.append("")
report_lines.append("### 4.6 感官沉浸设计")
report_lines.append("")
report_lines.append("高频感官关键词，指导VR视听效果设计：")
report_lines.append("")
if sensory_top:
    for sd, cnt in sorted(sensory_top.items(), key=lambda x: -x[1])[:6]:
        report_lines.append(f"- **{sd}** ({cnt}篇)")

report_lines.append("")
report_lines.append("## 五、数据文件索引")
report_lines.append("")
report_lines.append(f"- 打标全表: `{os.path.basename(OUT_TAGGED)}`")
report_lines.append(f"- 统计JSON: `{os.path.basename(OUT_STATS)}`")
report_lines.append(f"- 原始精选: `高层火灾新闻可用精选_20260701.csv`")
report_lines.append("")
report_lines.append("---")
report_lines.append(f"*自动生成于 {TODAY} | 脚本: analyze_and_tag.py*")

with open(OUT_REPORT, "w", encoding="utf-8") as f:
    f.write("\n".join(report_lines))
print(f"VR设计标准报告: {OUT_REPORT}")

# ============================================================
# 6. 打印摘要
# ============================================================
print("\n" + "="*60)
print("分析完成！摘要：")
print("="*60)
print(f"  Tier S (最佳VR素材):  {tier_dist.get('S', 0)} 篇")
print(f"  Tier A (优秀):        {tier_dist.get('A', 0)} 篇")
print(f"  Tier B (良好):        {tier_dist.get('B', 0)} 篇")
print(f"  Tier C (可用):        {tier_dist.get('C', 0)} 篇")
print(f"  Tier D (参考):        {tier_dist.get('D', 0)} 篇")
print(f"\n输出文件:")
print(f"  打标CSV: {OUT_TAGGED}")
print(f"  设计报告: {OUT_REPORT}")
print(f"  统计JSON: {OUT_STATS}")
