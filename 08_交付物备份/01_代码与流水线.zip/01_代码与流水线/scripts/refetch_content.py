#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""补抓缺失正文：对timeout和从未抓取的记录重新获取content"""
import csv, os, json, time, re, random
import concurrent.futures
import requests
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT  = os.path.join(ROOT, "data", "高层火灾_第二轮打标_20260701.csv")
TODAY  = datetime.now().strftime("%Y%m%d")
OUTPUT = os.path.join(ROOT, "data", f"高层火灾_补充正文_{TODAY}.csv")

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
}

SESSION = None

def get_session():
    global SESSION
    if SESSION is None:
        SESSION = requests.Session()
        SESSION.headers.update(HEADERS)
    return SESSION

def extract_text(html):
    """简单提取正文"""
    # 移除script/style
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.S | re.I)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.S | re.I)
    # 移除HTML标签
    text = re.sub(r'<[^>]+>', ' ', html)
    # 清理空白
    text = re.sub(r'\s+', ' ', text).strip()
    # 移除太短的行
    lines = [l.strip() for l in text.split('.') if len(l.strip()) > 20]
    return '. '.join(lines[:50])  # 最多50句

def fetch_one(row):
    url = row.get("url", "").strip()
    if not url or not url.startswith("http"):
        return {**row, "content": "", "fetch_status": "bad_url", "round2_status": "重试失败-bad_url"}
    
    session = get_session()
    try:
        resp = session.get(url, timeout=20, allow_redirects=True)
        if resp.status_code == 200:
            text = extract_text(resp.text)
            if len(text) > 100:
                return {**row, "content": text[:5000], "fetch_status": "refetched_ok", "round2_status": "补抓成功"}
            else:
                return {**row, "content": text, "fetch_status": "refetched_short", "round2_status": "补抓-内容过短"}
        elif resp.status_code == 403 or resp.status_code == 451:
            return {**row, "fetch_status": "blocked", "round2_status": "重试-blocked"}
        else:
            return {**row, "fetch_status": f"refetched_{resp.status_code}", "round2_status": f"重试-HTTP{resp.status_code}"}
    except requests.exceptions.Timeout:
        return {**row, "fetch_status": "timeout", "round2_status": "重试-timeout"}
    except Exception as e:
        return {**row, "fetch_status": f"error:{str(e)[:80]}", "round2_status": "重试-error"}

def main():
    with open(INPUT, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        all_rows = list(reader)
    
    # 筛选可重试的：timeout 或 从未抓取(空)
    to_refetch = []
    already_ok = []
    skipped = []
    
    for r in all_rows:
        fs = (r.get("fetch_status") or "").strip().lower()
        content = (r.get("content") or "").strip()
        
        # 已有正文的跳过
        if content and len(content) > 50 and not content.startswith("error:") and not content.startswith("We're Sorry"):
            already_ok.append(r)
            continue
        
        # blocked / 永久失败的跳过
        if "blocked" in fs or "451" in fs or "403" in fs:
            skipped.append(r)
            continue
        
        # timeout 或从未抓取 → 重试
        if "timeout" in fs or not fs:
            to_refetch.append(r)
        else:
            skipped.append(r)
    
    print(f"总计: {len(all_rows)}")
    print(f"已有正文(跳过): {len(already_ok)}")
    print(f"永久失败(跳过): {len(skipped)}")
    print(f"可重试: {len(to_refetch)}")
    
    if not to_refetch:
        print("无需重试，所有可抓的都已有正文或已永久失败。")
        return
    
    # 控制数量：最多抓500条
    target = min(500, len(to_refetch))
    to_refetch = to_refetch[:target]
    print(f"本批抓取: {len(to_refetch)} 条 (限500)")
    
    # 并发抓取
    results = []
    new_content_count = 0
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        futures = {executor.submit(fetch_one, r): i for i, r in enumerate(to_refetch)}
        for future in concurrent.futures.as_completed(futures):
            try:
                row = future.result()
                results.append(row)
                if "补抓成功" in str(row.get("round2_status", "")):
                    new_content_count += 1
                if len(results) % 20 == 0:
                    print(f"  进度: {len(results)}/{len(to_refetch)}, 新增正文: {new_content_count}")
            except Exception as e:
                idx = futures[future]
                results.append({**to_refetch[idx], "fetch_status": f"error:{str(e)[:80]}", "round2_status": "重试-exception"})
    
    # 合并：已有正文 + 跳过的 + 重试结果
    final = already_ok + skipped + results
    
    # 输出
    fieldnames = list(all_rows[0].keys())
    with open(OUTPUT, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(final)
    
    print(f"\n✅ 完成！新增正文: {new_content_count}/{len(to_refetch)}")
    print(f"   输出: {OUTPUT}")
    print(f"   总计: {len(final)} 条")

if __name__ == "__main__":
    main()
