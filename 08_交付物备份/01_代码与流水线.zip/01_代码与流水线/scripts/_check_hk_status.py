# -*- coding: utf-8 -*-
"""确认数据中宏福苑/香港火灾相关 gid 的判定状态。"""
import csv, os

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

gids = [451, 868, 1117, 1733, 2288, 5112, 5738, 5746, 5750, 5767,
        5787, 5794, 5800, 7920]

# 读全量判定（含标题）
judg = {}
with open(os.path.join(D, "_全量_grok判定.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        judg[int(r["gid"])] = (r["grok判定"], r["标题"][:50])

user_lab = {}
with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        user_lab[int(r["gid"])] = int(r["label"])

route = set()
with open(os.path.join(D, "_全量_路由表_K_最终.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        route.add(int(r["gid"]))

print("gid    Grok  用户判  路由表  标题")
for g in gids:
    if g in judg:
        j, t = judg[g]
    else:
        j, t = "无", "(不在判定文件)"
    ul = user_lab.get(g, "-")
    rt = "OK" if g in route else "--"
    print(f"{g:>5}   {j:>3}     {ul:>3}     {rt}   {t}")
