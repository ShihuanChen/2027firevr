# -*- coding: utf-8 -*-
"""用 GoldSet 103 条评估 committee 投票：混淆矩阵 + P/R/F1。"""
import csv, os, sys, re

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"

# ---- 与 active_learn_committee.py 相同的词表和投票逻辑（保持一致性）----
# v2 收紧版：移除泛词 window/floor/smoke/flame（几乎每篇都有），保留"具身可重建细节"
SCENE_W = [
    "stairwell","staircase","corridor","balcony","fire escape","crawling","crawl",
    "trapped","trap","black smoke","alarm",
    "楼梯","走廊","通道","阳台","窗口","窗框","浓烟","火势",
    "被困","逃生","跳下","绳索","床单","扶着墙","弯腰","匍匐","天台","窗台",
]
PERSON_W = [
    "said","says","told","recalled","remembered","described","witness","survivor",
    "victim","rescued","escaped","告诉记者","回忆","描述","幸存者","目击者",
    "亲眼","听到","闻到",
]
PROC_W = [
    "responded","dispatched","extinguished","investigate","hospitalized",
    "firefighter","fire department","消防员","救援","扑灭","灭火","送医","出动",
]
VULN_W = [
    "wheelchair","blind","deaf","hearing","visual","disabilit","elderly","disabled",
    "pregnant","轮椅","盲人","聋","听障","视障","残疾","老人","孕妇",
]
VULN_W2 = ["child","baby","infant","儿童","婴儿"]
EMOTION_W = [
    "scream","cry","panic","terrified","desperate","fear","afraid","terrifying",
    "尖叫","哭","恐慌","绝望","恐惧","害怕",
]
EXCLUDE_PAT = [
    re.compile(r"(missile|drone|airstrike|air strike|military|war\b|bomb|iran|israel|ukraine|russia)", re.I),
    re.compile(r"(fire department|fire chief|fire truck|fire station|fire.*training|fire.*budget)", re.I),
    re.compile(r"(review|trailer|game\b|movie\b|tv show|comic|solicit|nfl|nba|mlb)", re.I),
    re.compile(r"(trump|biden|election|campaign|vote|president|senator|congress)", re.I),
]
def cw(text, words):
    t = (" " + (text or "").lower() + " ")
    return sum(1 for w in words if w in t)

def vote1(title, body):
    t = (title + " " + (body or "")[:2000]).lower()
    sc = cw(t, SCENE_W); pc = cw(t, PROC_W)
    ratio = sc / (sc + pc + 1)
    return "keep" if (sc >= 4 and ratio >= 0.35) else "drop"

def vote2(body):
    L = len(body or ""); q = (body or "").count('"') + (body or "").count('“') + (body or "").count('”')
    if L >= 5000 or (L >= 2500 and q >= 6): return "keep"
    if L < 800: return "drop"
    return "mid"

def vote3(title, body):
    t = (title + " " + (body or "")[:3000]).lower()
    vg = cw(t, VULN_W) + 0.5 * cw(t, VULN_W2)
    pr = cw(t, PERSON_W); em = cw(t, EMOTION_W)
    if vg >= 1 and pr >= 2 and em >= 1: return "keep"
    if vg >= 2 and pr >= 1: return "keep"
    if vg == 0 and em == 0: return "drop"
    return "mid"

# ---- 加载数据 ----
rows = []
with open(os.path.join(D, "第三轮_含正文_筛选草稿.csv"), encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        rows.append({"gid": i + 1, "title": row[1] if len(row) > 1 else "",
                     "body": row[4] if len(row) > 4 else ""})

gold = []
with open(os.path.join(D, "人机协作_GoldSet_103.csv"), encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        lab = str(r.get("keep_label", "")).strip()
        if lab in ("1", "0.5", "0"):
            i = int(r["idx"])
            gold.append({"label": 1 if lab in ("1", "0.5") else 0,
                         "title": rows[i-1]["title"], "body": rows[i-1]["body"]})

# ---- 评估 ----
TP = FP = TN = FN = 0
detail = []
for g in gold:
    v1, v2, v3 = vote1(g["title"], g["body"]), vote2(g["body"]), vote3(g["title"], g["body"])
    votes = [v1, v2, v3]
    ai_keep = "keep" in votes  # 有保留票 = AI 倾向保留（路由给人，但这里近似"AI 判定保留"）
    pred = 1 if ai_keep else 0
    if pred == 1 and g["label"] == 1: TP += 1
    elif pred == 1 and g["label"] == 0: FP += 1
    elif pred == 0 and g["label"] == 1: FN += 1
    else: TN += 1
    detail.append((g["label"], pred, "/".join(votes)))

P = TP / (TP + FP) if TP + FP else 0
R = TP / (TP + FN) if TP + FN else 0
F1 = 2 * P * R / (P + R) if P + R else 0
acc = (TP + TN) / len(gold)

print("=== GoldSet 103 条评估（committee 三票，无 GLM）===")
print(f"混淆矩阵   AI=保留   AI=剔除")
print(f"人工保留11  {TP:>4}     {FN:>4}")
print(f"人工剔除92  {FP:>4}     {TN:>4}")
print(f"\nPrecision(保留精度) = {P:.1%}")
print(f"Recall   (保留召回) = {R:.1%}")
print(f"F1                = {F1:.1%}")
print(f"Accuracy          = {acc:.1%}")
print(f"\n误留率 false-retention = {FP/(TP+FP) if TP+FP else 0:.1%}（AI判保留中人工认为该剔除的比例）")
print(f"误删率 false-drop      = {FN/(TP+FN) if TP+FN else 0:.1%}（人工保留中AI判剔除的比例）")

print("\n=== 11 条人工保留的投票详情 ===")
for lab, pred, v in detail:
    if lab == 1:
        mark = "OK" if pred == 1 else "MISS"
        print(f"  [{mark}] votes={v:12} -> {g['title'][:50]}")
