# -*- coding: utf-8 -*-
"""查看 v4 交付表中所有非空标注列的原始内容，定位"以下全是0"位置。"""
import openpyxl

p = r"C:\Users\Administrator\Desktop\_批量试跑v4_78条交付.xlsx"
wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
ws = wb.active
rows = []
for i, row in enumerate(ws.iter_rows(values_only=True)):
    if i == 0 or row[0] is None:
        continue
    rows.append(list(row))

print("=== 所有有非空标注的条目 ===")
for r in rows:
    gid = int(r[0])
    v = str(r[4]).strip() if len(r) > 4 and r[4] is not None else ""
    if v:
        print(f"  gid{gid:>6} | 标注列=[{v}] | {str(r[1])[:50]}")

print(f"\n总行数: {len(rows)}")
