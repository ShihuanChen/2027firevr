import requests, re, json  
  
urls = [  
    'https://pudding.cool/2024/11/sitters-standers/',  
    'https://ydcpodcast.org/',  
    'https://pudding.cool/2024/03/teenagers/',  
    'https://pudding.cool/2022/12/yard-sale/',  
    'https://pudding.cool/2021/12/sesame/',  
    'https://pudding.cool/2021/08/spades/',  
]  
  
headers = {'User-Agent': 'Mozilla/5.0'}  
  
for url in urls: 
