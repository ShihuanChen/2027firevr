# -*- coding: utf-8 -*-
"""搜索用户补充的香港宏福苑系列标题是否在数据中。"""
import csv, os, re

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")

# 用户补充的关键词
KEYWORDS = [
    "宏福苑", "何伟豪", "爬窗救火", "爬窗", "唐平满", "浴室", "湿毛巾",
    "阿Will", "浓烟", "获救", "火劫", "殉职", "消防员", "Mayday",
    "炼狱", "竹脚手架", "竹棚", "爆竹", "爆裂声", "大火听证", "聽證",
]

rows = []
with open(SRC, encoding="utf-8") as f:
    reader = csv.reader(f); next(reader)
    for i, row in enumerate(reader):
        rows.append((i + 1, row[1] if len(row) > 1 else ""))

print(f"全量 {len(rows)} 条，搜索宏福苑系列...\n")
hits = {}
for gid, title in rows:
    t = title or ""
    for kw in KEYWORDS:
        if kw in t:
            hits.setdefault(gid, []).append(kw)

print(f"命中 {len(hits)} 条：")
for gid in sorted(hits):
    print(f"  gid{gid:>6} [{','.join(hits[gid])}] {rows[gid-1][1][:60]}")
