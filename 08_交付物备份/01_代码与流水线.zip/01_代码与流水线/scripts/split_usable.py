#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import csv, os
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TODAY = datetime.now().strftime("%Y%m%d")

TOTAL_PATH = os.path.join(ROOT, "data", f"高层火灾新闻总表_{TODAY}.csv")
GOOD_PATH = os.path.join(ROOT, "data", f"高层火灾新闻可用精选_{TODAY}.csv")
KEPT_PATH = os.path.join(ROOT, "data", f"高层火灾新闻Keep确认_{TODAY}.csv")

# 先读取全表
with open(TOTAL_PATH, "r", encoding="utf-8-sig") as f:
    reader = csv.DictReader(f)
    all_rows = list(reader)

# 可用 = 不是 Eliminate
good = [r for r in all_rows if r.get("screening_status", "").strip().lower() != "eliminate"]
# Keep确认 = 明确 Keep
kept = [r for r in all_rows if r.get("screening_status", "").strip().lower() == "keep"]

for path, rows in [(GOOD_PATH, good), (KEPT_PATH, kept)]:
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=reader.fieldnames)
        writer.writeheader()
        writer.writerows(rows)

print("可用精选: " + GOOD_PATH + " (" + str(len(good)) + "条)")
print("Keep确认: " + KEPT_PATH + " (" + str(len(kept)) + "条)")
print("全量总表: " + TOTAL_PATH + " (" + str(len(all_rows)) + "条)")

# 同时生成一个按语言分类的统计
from collections import Counter
lang = Counter(r.get("language","") or "unknown" for r in good)
print("\n可用精选语言分布:")
for k,v in lang.most_common():
    print("  " + k + ": " + str(v))

# 按来源文件分布
orig = Counter()
for r in good:
    for o in r.get("origin_file","").split(";"):
        o = o.strip()
        if o:
            orig[o] += 1
print("\n可用精选来源分布:")
for k,v in orig.most_common():
    print("  " + k + ": " + str(v))
