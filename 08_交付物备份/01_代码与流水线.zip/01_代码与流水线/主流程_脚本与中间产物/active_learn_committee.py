# -*- coding: utf-8 -*-
"""
active learning 筛选（committee 分歧度版）— 替代旧"聚类代表传播"。

原理（依据 Settles 2009 / Settles & Craven 2008）：
- 三个独立"评审"对每篇文章投票（保留？剔除？）
- 分歧度 = 票数不一致程度 → 分歧越大 = AI 越拿不准 = 最值得人工判（uncertainty sampling）
- 高置信剔除（三票全 drop）自动落定，不占人工
- 高置信保留（三票全 keep）进入候选保留集，但仍需人工确认（保留集代价最高）

用法（用系统 Python 3.11，装有 sklearn/pandas）：
    Python311/python.exe 工作流/active_learn_committee.py
    可选: --with-glm 启用 GLM API 第 4 票（需 config.yaml 有效 key）
    输出: 工作流/_al_待判.csv（你只需填 用户填1/0 列）
         工作流/_al_自动处理.csv（AI 已落定的，仅抽查用）
"""
import csv, os, re, sys, argparse, time
from collections import defaultdict

csv.field_size_limit(10**9)
D = r"D:\BaiduSyncdisk\chi2027\朱倩\工作流"
SRC = os.path.join(D, "第三轮_含正文_筛选草稿.csv")

# ---------- 词表（中英双语，覆盖 GDELT 英文为主 + 中文报道） ----------
SCENE_W = [
    "stairwell","staircase","corridor","balcony","fire escape","window","floor",
    "crawling","crawl","trapped","trap","smoke","flame","black smoke",
    "楼梯","走廊","通道","阳台","窗口","窗框","浓烟","黑烟","火势",
    "被困","逃生","跳下","绳索","床单","扶着墙","弯腰",
]
PERSON_W = [
    "said","says","told","recalled","remembered","described","witness","survivor",
    "victim","rescued","escaped","告诉记者","回忆","描述","幸存者","目击者",
    "亲眼","听到","闻到","我","他","她",
]
PROC_W = [
    "responded","dispatched","extinguished","investigate","hospitalized",
    "firefighter","fire department","消防员","救援","扑灭","灭火","送医","出动",
]
VULN_W = [
    "wheelchair","blind","deaf","hearing","visual","disabilit","elderly","disabled",
    "pregnant","child","baby","infant","轮椅","盲人","聋","听障","视障","残疾","老人","孕妇","儿童","婴儿",
]
EMOTION_W = [
    "scream","cry","panic","terrified","desperate","fear","afraid","terrifying",
    "尖叫","哭","恐慌","绝望","恐惧","害怕",
]

# 高置信剔除的模式（沿用 v1，由 103 条金标准验证）
EXCLUDE_PAT = [
    re.compile(r"(missile|drone|airstrike|air strike|military|war\b|bomb|iran|israel|ukraine|russia)", re.I),
    re.compile(r"(fire department|fire chief|fire truck|fire station|fire.*training|fire.*budget)", re.I),
    re.compile(r"(review|trailer|game\b|movie\b|tv show|comic|solicit|nfl|nba|mlb)", re.I),
    re.compile(r"(trump|biden|election|campaign|vote|president|senator|congress)", re.I),
    re.compile(r"政府工作报告|隐患排查|消防检查|消防演练|春节|国庆", re.I),
    re.compile(r"召开.*会议|部署.*工作|开展.*活动|推进.*建设", re.I),
]

def count_words(text, words):
    t = (" " + text.lower() + " ")
    return sum(1 for w in words if w in t)

# ---------- 三个评审 ----------
def vote_v1_keyword(title, body):
    """评审1: v1 关键词启发式（具身场景可重建性）"""
    t = (title + " " + body[:2000]).lower()
    sc = count_words(t, SCENE_W)
    pc = count_words(t, PROC_W)
    pr = count_words(t, PERSON_W)
    ratio = sc / (sc + pc + 1)
    if sc >= 4 and ratio >= 0.25:
        return "keep", {"scene": sc, "proc": pc, "ratio": round(ratio, 2)}
    return "drop", {"scene": sc, "proc": pc, "ratio": round(ratio, 2)}

def vote_length_struct(body):
    """评审2: 长度/结构启发式（叙事充分性）"""
    L = len(body or "")
    quotes = (body or "").count('"') + (body or "").count('“') + (body or "").count('”')
    if L >= 4000 or (L >= 2000 and quotes >= 4):
        return "keep", {"L": L, "quotes": quotes}
    if L < 800:
        return "drop", {"L": L, "quotes": quotes}
    return "mid", {"L": L, "quotes": quotes}

def vote_vulnerable_narrative(title, body):
    """评审3: 弱势群体 × 人物叙事（项目核心关注）"""
    t = (title + " " + body[:3000]).lower()
    vg = count_words(t, VULN_W)
    pr = count_words(t, PERSON_W)
    em = count_words(t, EMOTION_W)
    if vg >= 1 and pr >= 1:
        return "keep", {"vg": vg, "person": pr, "emotion": em}
    if em >= 3 and pr >= 2:
        return "keep", {"vg": vg, "person": pr, "emotion": em}
    if vg == 0 and em == 0:
        return "drop", {"vg": vg, "person": pr, "emotion": em}
    return "mid", {"vg": vg, "person": pr, "emotion": em}

def vote_glm(title, body, config):
    """评审4(可选): GLM 语义评分（五维 rubric 简化版）"""
    try:
        import requests
        url = config.get("base_url", "").rstrip("/") + "/chat/completions"
        api_key = config.get("api_key", "")
        if not api_key:
            return "mid", {"err": "no key"}
        prompt = (
            "你是新闻语料筛选专家。判断这篇火灾报道是否适合用于VR场景重建："
            "它是否包含可重建的空间细节（楼层/走廊/楼梯/房间布局）、身体动作、感官描写（烟雾/声音/温度）、"
            "或弱势群体（老人/儿童/残障/孕妇）的逃生经历？"
            "只回答一个字母：K=适合重建(保留), D=不适合(剔除)。\n\n标题: "
            + (title or "")[:200] + "\n正文: " + (body or "")[:1500]
        )
        resp = requests.post(url, headers={"Authorization": f"Bearer {api_key}"},
                             json={"model": config.get("model_name", ""), "messages": [{"role": "user", "content": prompt}], "temperature": 0},
                             timeout=30)
        ans = resp.json()["choices"][0]["message"]["content"].strip().upper()
        return ("keep" if ans.startswith("K") else "drop"), {"ans": ans}
    except Exception as e:
        return "mid", {"err": str(e)[:50]}

# ---------- 主流程 ----------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--with-glm", action="store_true", help="启用 GLM 第 4 票")
    ap.add_argument("--top", type=int, default=40, help="本轮交给人工的条数")
    args = ap.parse_args()

    # 加载 config（PyYAML）
    config = {}
    cfg_path = os.path.join(D, "config.yaml")
    try:
        import yaml
        with open(cfg_path, encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        cred = (cfg or {}).get("credentials", {}) or {}
        config = {k: str(cred[k]).strip() for k in ("api_key", "base_url", "model_name") if k in cred}
    except Exception:
        pass

    t0 = time.time()
    print("读取数据...")
    items = []
    with open(SRC, encoding="utf-8") as f:
        reader = csv.reader(f)
        next(reader)
        for i, row in enumerate(reader):
            gid = i + 1
            title = row[1] if len(row) > 1 else ""
            body = row[4] if len(row) > 4 else ""
            items.append({"gid": gid, "title": title, "body": body or "", "L": len(body or "")})
    print(f"  {len(items)} 条, {time.time()-t0:.1f}s")

    # 已人工标注的 gid（来自 GoldSet + batch-1/2，这些不重复路由给人）
    labeled_gids = set()
    gold = os.path.join(D, "人机协作_GoldSet_103.csv")
    if os.path.exists(gold):
        with open(gold, encoding="utf-8-sig", errors="ignore") as f:
            rdr = csv.DictReader(f)
            for r in rdr:
                if str(r.get("idx", "")).strip().isdigit():
                    labeled_gids.add(int(r["idx"]))
    # batch-1/2 用的是"统一编号"列，gid 与草稿行号不同，这里记录已填判断的行
    for fn in ["批次001_1-100.csv", "批次002_101-200_用户.csv"]:
        fp = os.path.join(D, fn)
        if not os.path.exists(fp):
            continue
        for enc in ["gbk", "utf-8-sig"]:
            try:
                with open(fp, encoding=enc) as f:
                    rdr = csv.reader(f); h = next(rdr)
                    jc = next((i for i, n in enumerate(h) if "用户" in n or "判断" in n or "1/0" in n), len(h) - 1)
                    for r in rdr:
                        j = (r[jc] if len(r) > jc else "").strip()
                        if j:
                            labeled_gids.add(-1)  # 保守标记：本批已处理，不重复路由
                break
            except Exception:
                continue

    print("委员会投票中...")
    scored = []
    n_glm = 0
    for it in items:
        if it["L"] < 400:
            continue
        if any(p.search(it["title"]) for p in EXCLUDE_PAT):
            continue
        v1, f1 = vote_v1_keyword(it["title"], it["body"])
        v2, f2 = vote_length_struct(it["body"])
        v3, f3 = vote_vulnerable_narrative(it["title"], it["body"])
        votes = [v1, v2, v3]
        if args.with_glm and "api_key" in config:
            v4, f4 = vote_glm(it["title"], it["body"], config)
            votes.append(v4)
            n_glm += 1
        n_keep = votes.count("keep"); n_drop = votes.count("drop")
        disagree = len(set(votes))  # 分歧度 1-3
        # 不确定度：0.5 的票最多 + 分歧最大
        uncertainty = n_keep + 0.5 * (len(votes) - n_keep - n_drop) if n_keep else 0.5 * (len(votes) - n_drop)
        # 保守自动剔除（v1 原则：AI 永不自动保留）：
        #   没有任何"保留"票（drop/mid 组合）→ 自动剔除
        #   有"保留"票 → 路由给人（保留权完全留给人工）
        if n_keep == 0:
            verdict = "auto_drop"
        else:
            verdict = "uncertain"
        scored.append({**it, "votes": votes, "disagree": disagree,
                       "uncertainty": uncertainty, "verdict": verdict,
                       "f1": f1, "f2": f2, "f3": f3})

    auto_drop = [s for s in scored if s["verdict"] == "auto_drop"]
    auto_keep = []
    uncertain = [s for s in scored if s["verdict"] == "uncertain"]
    uncertain.sort(key=lambda s: (-s["disagree"], -s["uncertainty"]))

    print(f"  全票剔除: {len(auto_drop)} | 全票保留: {len(auto_keep)} | 不确定: {len(uncertain)}"
          + (f" | GLM调用: {n_glm}" if args.with_glm else ""))

    # 输出：不确定集 top-N 给人判；自动剔除集抽样 15 条给人抽查（审计误删率）
    top_n = uncertain[:args.top]
    sample_n = 15
    sample = auto_drop[:sample_n]
    review = [("uncertain", s) for s in top_n] + [("audit", s) for s in sample]

    out_u = os.path.join(D, "_al_待判.csv")
    with open(out_u, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["编号", "标题", "字数", "来源", "投票", "分歧度", "正文(前2500)", "用户填1/0"])
        for tag, s in review:
            w.writerow([s["gid"], s["title"][:80], s["L"], tag, "/".join(s["votes"]), s["disagree"],
                        s["body"][:2500].replace("\n", " ").replace("\r", ""), ""])
    out_a = os.path.join(D, "_al_自动处理.csv")
    with open(out_a, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["编号", "标题", "字数", "判断", "投票"])
        for s in auto_keep:
            w.writerow([s["gid"], s["title"][:60], s["L"], "保留", "/".join(s["votes"])])
        for s in auto_drop:
            w.writerow([s["gid"], s["title"][:60], s["L"], "剔除", "/".join(s["votes"])])

    print(f"\n输出: {out_u} ({len(review)} 条待判 = {len(top_n)} 条不确定路由 + {sample_n} 条剔除审计)")
    print(f"      {out_a} ({len(auto_keep)+len(auto_drop)} 条自动处理，仅剔除 {len(auto_drop)}，AI 永不自动保留)")
    print(f"总用时 {time.time()-t0:.1f}s")

if __name__ == "__main__":
    main()
