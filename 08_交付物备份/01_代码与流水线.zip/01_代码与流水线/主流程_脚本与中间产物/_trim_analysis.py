﻿import os
# -*- coding: utf-8 -*-
import csv, sys
from collections import Counter
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(f"{ROOT}/_judge_table_合并.csv", encoding='utf-8-sig')))
SCARCE = {'视障','听障','轮椅','拄拐','孕妇','残疾','婴儿'}
def sc(v): return 1 if any(g in SCARCE for g in (v.split('+') if v else [])) else 0

print("=== 各来源层 value_score 分布 ===")
for layer in ['② 1446内补回','① 6666-1446漏网']:
    sub = [r for r in rows if r['来源层']==layer]
    vs = [int(r['正则_value']) for r in sub if r['正则_value'].isdigit()]
    print(f"\n{layer} (n={len(sub)}):")
    print("  value直方图:", dict(sorted(Counter(vs).items())))
    print("  稀缺命中:", sum(sc(r['正则_vulnerable']) for r in sub))
    if layer.startswith('②'):
        for vd in ['Y','N']:
            s=[r for r in sub if r['qwen判定']==vd]
            vv=[int(r['正则_value']) for r in s if r['正则_value'].isdigit()]
            print(f"    qwen{vd}: n={len(s)} value分布={dict(sorted(Counter(vv).items()))} 稀缺={sum(sc(r['正则_vulnerable']) for r in s)}")
    else:
        for kind in ['①clean','①mixed']:
            s=[r for r in sub if (('混合' in r['正则_fire_rel']) == (kind=='①mixed'))]
            vv=[int(r['正则_value']) for r in s if r['正则_value'].isdigit()]
            print(f"    {kind}: n={len(s)} value分布={dict(sorted(Counter(vv).items()))} 稀缺={sum(sc(r['正则_vulnerable']) for r in s)}")

