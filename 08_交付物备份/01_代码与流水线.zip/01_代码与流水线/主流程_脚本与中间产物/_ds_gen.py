# -*- coding: utf-8 -*-
import json, re, html

d = json.load(open('工作流/_verify.json', encoding='utf-8'))
fields = d['data']['fields']
rids   = d['data']['record_id_list']
recs   = d['data']['data']

def rec_to_dict(r):
    return {fields[i]: r[i] for i in range(len(fields))}

def g(rec, name):
    v = rec.get(name)
    if isinstance(v, list): return '、'.join(v) if v else ''
    return v or ''

def esc(s):
    return html.escape(str(s), quote=True)

# Build per-article note rows grouped by six-role persona
notes = []
for k, r in enumerate(recs):
    rec = rec_to_dict(r)
    rid = rids[k]
    code = g(rec, '编号')
    title = g(rec, '标题')
    # narrative layer
    nar = '｜'.join(filter(None, [g(rec,'叙事视角'), g(rec,'时间结构'), g(rec,'核心冲突'), g(rec,'情感弧线')]))
    # interaction layer
    inter = '｜'.join(filter(None, [g(rec,'交互_身体化角色'), g(rec,'交互_移动方式'),
                                     g(rec,'交互_交互动词'), g(rec,'交互_共情机制'), g(rec,'交互_沉浸反馈')]))
    vr = g(rec, 'VR场景对应角色')
    notes.append((rid, code, title, nar, inter, vr))

# group by persona (from 六角色对接 / 交互_身体化角色)
from collections import defaultdict
groups = defaultdict(list)
order = ['威廉 视障','阿May 听障','罗姐 轮椅','阿福 拄拐','陈伯 老年','King仔 儿童']
for n in notes:
    rec = rec_to_dict(recs[rids.index(n[0])])
    six = g(rec, '六角色对接')
    persona = six if six else '—（无特定弱势群体/普通成年人视角）'
    groups[persona].append(n)

json.dump({'notes': notes, 'groups': {k: [x[0] for x in v] for k,v in groups.items()}},
          open('工作流/_ds_notes.json','w',encoding='utf-8'), ensure_ascii=False)
print('total notes:', len(notes))
print('groups:', {k: len(v) for k,v in groups.items()})
# sample
print('SAMPLE note:', notes[0])
