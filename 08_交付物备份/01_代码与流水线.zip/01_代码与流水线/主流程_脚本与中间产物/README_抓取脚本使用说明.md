# 抓取脚本使用说明（real_scraper.py）

## 一、为什么之前报错

报错几乎可以肯定是 **`ModuleNotFoundError: No module named 'requests'`（或 'trafilatura'）**。

原因：`requests` / `trafilatura` 装在项目的虚拟环境 `.venv` 里，但你用的是**系统 Python**，两者不互通。

## 二、怎么运行（二选一）

脚本位置：`朱倩/工作流/real_scraper.py`

### 方式 A：直接用 .venv 里的 Python（推荐，免激活）

在 **`朱倩/工作流`** 目录下打开终端：

```bash
# Windows (Git Bash)
../../.venv/Scripts/python.exe real_scraper.py --max 250

# Windows (PowerShell / CMD)
..\..\.venv\Scripts\python.exe real_scraper.py --max 250
```

### 方式 B：先激活虚拟环境，再用 python

```bash
# Git Bash
source ../../.venv/Scripts/activate
python real_scraper.py --max 250

# PowerShell
..\..\.venv\Scripts\Activate.ps1
python real_scraper.py --max 250
```

### 如果仍报缺包，先装依赖：

```bash
../../.venv/Scripts/pip.exe install requests trafilatura
```

## 三、常用命令

| 目的 | 命令 |
|---|---|
| 全量抓取（目标数千条） | `python real_scraper.py --max 250` |
| 快速试跑（只收URL不抓正文，几分钟） | `python real_scraper.py --no-fulltext --months 3` |
| 控制回溯月数 | `python real_scraper.py --months 12` |
| 加大并发提速（默认16线程） | `python real_scraper.py --workers 32` |
| 自定义输出文件名 | `python real_scraper.py --out 第三轮.csv` |

## 三point五、为什么之前"卡不动" + 提速说明

旧版逐条串行抓正文，几千条 × 每条~2秒 = 数小时，所以看起来卡住。**v3 已重构为两阶段 + 并行**：

- **阶段1**：只做 GDELT 检索 + 去重 + 标题预筛（标题命中"山火/枪火"等排除词的直接丢弃，免抓正文）。
- **阶段2**：用**多线程并行抓正文**（默认16线程）。实测 16条/20秒，串行需~163秒 → **约8-16倍提速**。
- 想更快：`--workers 32`（网络好可设更高）；或先 `--no-fulltext` 几分钟拿到全部URL+标题清单，再决定是否抓正文。

> GDELT 检索本身仍受其"每5秒1次"硬限流约束（阶段1，约1小时），这是对方服务器规则，无法绕过；但**最耗时的正文抓取已并行化**。若只想快速看结果，先跑 `--no-fulltext`。


## 四、结果放在哪里 / 什么格式

**输出位置**：运行目录下的 CSV，默认文件名 `第三轮_真实抓取.csv`（在 `朱倩/工作流/` 内）。

**编码**：`utf-8-sig`，Excel / WPS 双击直接打开不乱码。

**字段**：前 5 列与你的 `数据新闻收集_第一轮_表格.csv` **完全对齐**，方便直接接入既有流程；后面是诊断列。

| 列名 | 说明 |
|---|---|
| 原始报道链接 | 文章 URL |
| 核心事件 | 标题 |
| 初筛结论 | **Keep**（high/medium且非重复）/ **Eliminate**（无关或近重复）/ **Pending** |
| 备注 | 域名 \| 日期 \| score=分数(等级) |
| 文本 | 抓取到的正文 |
| canonical_url | 规范化URL（去重用） |
| language | 语种 |
| query | 命中的检索式 |
| fetch_status | success / 404 / blocked / empty / error |
| text_length | 正文字数 |
| relevance_score | 相关性分数（越高越可能是目标案例） |
| relevance_tier | high / medium / low / excluded |
| near_duplicate | 是否近重复 |

**结果默认按 relevance_score 降序**——高价值案例（火灾×高层×弱势群体×细节齐全）自动排在最前，你从顶部往下精筛即可。

## 五、下一步

对 `初筛结论=Keep` 或 `relevance_tier=high/medium` 的条目，用 `待办5_新闻数据处理流程文档.md` 的五维评分（可接大模型）做 S2→S3 精筛。
