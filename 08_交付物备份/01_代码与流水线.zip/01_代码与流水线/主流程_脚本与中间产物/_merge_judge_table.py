﻿import os
# -*- coding: utf-8 -*-
"""把 ①正则漏网 + ②qwen复核 合成一张供人工判断的表。"""
import csv, sys
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))
LEAK = f"{ROOT}/_rescreen_6666_leak_v2.csv"
QWEN = f"{ROOT}/_qwen_1446_review.csv"
OUT  = f"{ROOT}/_judge_table_合并.csv"
SCARCE = {'视障','听障','轮椅','拄拐','孕妇','残疾','婴儿'}

def scarce_of(v):
    vs = v.split('+') if v else []
    return 1 if any(g in SCARCE for g in vs) else 0

# ---- ① 正则漏网 ----
rows = []
with open(LEAK, encoding='utf-8-sig') as fh:
    for r in csv.DictReader(fh):
        mixed = '混合' in (r.get('fire_rel') or '')
        rows.append({
            '来源层': '① 6666-1446漏网',
            'gid': r.get('gid',''),
            '标题': (r.get('标题') or '')[:80],
            '正则_fire_rel': r.get('fire_rel',''),
            '正则_high_rise': r.get('high_rise',''),
            '正则_vulnerable': r.get('vulnerable',''),
            '正则_value': r.get('value_score',''),
            'qwen判定': '—',
            'qwen理由': '',
            '人工判断': '',
            '_kind': '①mixed' if mixed else '①clean',
            '_scarce': scarce_of(r.get('vulnerable','')),
            '_val': int(r['value_score']) if (r.get('value_score') or '').isdigit() else 0,
        })

# ---- ② qwen 复核 ----
with open(QWEN, encoding='utf-8-sig') as fh:
    for r in csv.DictReader(fh):
        v = r.get('正则_value','')
        rows.append({
            '来源层': '② 1446内补回',
            'gid': r.get('gid',''),
            '标题': (r.get('标题') or '')[:80],
            '正则_fire_rel': r.get('正则_fire_rel',''),
            '正则_high_rise': r.get('正则_high_rise',''),
            '正则_vulnerable': r.get('正则_vulnerable',''),
            '正则_value': v,
            'qwen判定': r.get('qwen判定',''),
            'qwen理由': (r.get('qwen理由') or '')[:120],
            '人工判断': '',
            '_kind': '②Y' if r.get('qwen判定')=='Y' else '②N',
            '_scarce': scarce_of(r.get('正则_vulnerable','')),
            '_val': int(v) if (v or '').isdigit() else 0,
        })

# ---- 排序: ②Y(0) > ①clean(1) > ②N(2) > ①mixed(3); 同层 scarce+value 降序 ----
prio = {'②Y':0, '①clean':1, '②N':2, '①mixed':3}
rows.sort(key=lambda d: (prio[d['_kind']], -d['_scarce'], -d['_val']))

# ---- 输出 ----
flds = ['来源层','gid','标题','正则_fire_rel','正则_high_rise','正则_vulnerable',
        '正则_value','qwen判定','qwen理由','人工判断']
with open(OUT, 'w', encoding='utf-8-sig', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=flds + ['_kind','_scarce','_val'])
    w.writeheader()
    # 只写对外字段, 但保留内部排序辅助列也行; 这里去掉辅助列
    for d in rows:
        w.writerow({k: d[k] for k in flds})

# ---- 统计 ----
from collections import Counter
print("合并总条数:", len(rows))
print("来源层分布:", dict(Counter(d['来源层'] for d in rows)))
print("② qwen分布:", dict(Counter(d['qwen判定'] for d in rows if d['来源层'].startswith('②'))))
print("① 类型:", dict(Counter(d['_kind'] for d in rows if d['来源层'].startswith('①'))))
print("稀缺群体命中:", sum(1 for d in rows if d['_scarce']==1))
print("->", OUT)

