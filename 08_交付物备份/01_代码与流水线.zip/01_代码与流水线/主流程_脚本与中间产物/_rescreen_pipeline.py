﻿import os
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重筛管线 v3 — 只信 round2_persona 策划标签 + 高层分类器, 捞"带弱势群体标签但没进125"的真漏网。
连接键: 归一化标题 (125终稿'来源'是标签非URL)。
可复现: python _rescreen_pipeline.py
"""
import csv, sys, re, json
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))

def norm_title(t):
    t=(t or '').lower()
    t=re.sub(r'[^a-z0-9\u4e00-\u9fff]+',' ',t)
    return re.sub(r'\s+',' ',t).strip()

with open(f"{ROOT}/第三轮_含正文_筛选草稿.csv",encoding='utf-8-sig',newline='') as fh:
    r=csv.reader(fh); H=[c.strip() for c in next(r)]; ROWS=list(r)
def col(n): return H.index(n)
CI_LINK=col('原始报道链接'); CI_TITLE=col('核心事件'); CI_TEXT=col('文本')
CI_PERSONA=col('round2_persona'); CI_KEEP=col('是否保留（1保留/0去除）')
CI_REASON=col('原因'); CI_RELT=col('relevance_tier')

fin_titles=set()
with open(f"{ROOT}/_保留集_FINAL_完整版.csv",encoding='utf-8-sig',newline='') as fh:
    for row in csv.DictReader(fh):
        t=norm_title(row.get('标题'))
        if t: fin_titles.add(t)
try:
    bak=json.load(open(f"{ROOT}/_deleted_noise_backup.json",encoding='utf-8'))
    for rec in bak.get('records',[]):
        t=norm_title(rec.get('fields',{}).get('标题'))
        if t: fin_titles.add(t)
except Exception: pass

ANCHOR_HI={'宏福苑','格伦费尔','grenfell','明尚','伦敦大火','香港','hochhaus','olympic tower','bronx'}
NOISE=[r'firewood rack',r'fire truck shortage',r'\battorney\b',r'lawyer',r'ben crump',
        r'setting your design ablaze',r'voice to the voiceless',r'burnout',r'deepfake',
        r'photographs that defined',r'best .* rack',r'recipe',r'\bdiy\b']
HIGH=[r'high[-\s]?rise',r'skyscraper',r'\btower\b',r'高层',r'高楼',r'大厦',r'塔楼',r'宏福苑',
       r'格伦费尔',r'grenfell',r'明尚',r'伦敦大火',r'公寓楼',r'住宅楼',r'小区',r'苑',r'hochhaus',
       r'\b\d{1,2}(st|nd|rd|th)?\s*floor\b',r'第\s*\d+\s*层',r'\d{1,2}[-\s]?story',r'\d{1,2}[-\s]?storey',r'\d+\s*层']
LOW_T=[r'\bhouse\b',r'bungalow',r'single-?family',r'self-?built',r'自建房',r'民房',r'平房',r'cottage',
        r'\bvilla',r'独栋',r'房子',r'\bshop\b',r'store',r'铺面',r'商铺',r'五金店',r'church',r'cathedral',
        r'教堂',r'mosque',r'temple',r'寺庙',r'warehouse',r'仓库',r'factory',r'工厂',r'\bschool\b',r'学校',
        r'market',r'市场',r'slum',r'jhuggi',r'窝棚',r'帐篷']
APT=[r'apartment',r'condo',r'condominium',r'\bflat\b',r'公寓',r'住宅',r'residential',r'\bbuilding\b',r'\bblock\b',r'楼']

NEG=[r'brush fire',r'wildfire',r'forest fire',r'grass fire',r'wildland',r'vehicle fire',
      r'car fire',r'truck fire',r'motorcycle',r'two-wheeler',r'barn fire',r'field fire',
      r'pleads guilty',r'proposed .* rules',r'\baudit\b',r'conviction',r'investigation into',
      r'launches .* audit',r'policy',r'commentary',r'opinion',r'\blawsuit\b',r'settlement']

def classify_hi(title,body):
    t=title.lower(); b=body.lower()[:400]
    if any(re.search(p,(t+b)) for p in NOISE): return '噪声'
    if any(re.search(p,(t+b)) for p in NEG): return '非建筑/非事件'
    if any(re.search(p,(t+b)) for p in ANCHOR_HI): return '高层'
    hi=False
    for p in HIGH:
        m=re.search(p,(t+b))
        if m:
            num=re.search(r'(\d{1,2})',m.group(0))
            if num and int(num.group(1))>=5: hi=True; break
            if p in (r'high[-\s]?rise',r'skyscraper',r'高层',r'高楼',r'大厦',r'塔楼',r'宏福苑',
                     r'格伦费尔',r'grenfell',r'明尚',r'伦敦大火',r'公寓楼',r'住宅楼',r'小区',r'苑',r'hochhaus'): hi=True; break
            if p==r'\btower\b' and re.search(r'residential|apartment|building|住房|公寓',(t+b)): hi=True; break
    low=any(re.search(p,t) for p in LOW_T)
    if low and not hi: return '明确非高层'
    if hi: return '高层'
    if any(re.search(p,(t+b)) for p in APT): return '多层公寓'
    return '未知'

SCARCE={'visually_impaired':'视障','hearing_impaired':'听障','mobility_impaired':'行动不便',
        'wheelchair':'轮椅','pregnant':'孕妇','blind':'盲','disabled':'残疾','deaf':'听障'}
COMMON={'elderly':'老年','child':'儿童','senior':'老年'}

def vr_from_persona(persona_raw):
    p=(persona_raw or '').lower().strip()
    if not p or p=='none': return 0,[]
    score=0; tags=[]
    # 多标签用 , / 、 拆分
    toks=re.split(r'[,，/、]', p)
    for tok in toks:
        tok=tok.strip().lower()
        if tok in SCARCE: score+=3; tags.append('稀缺:'+SCARCE[tok])
        elif tok in COMMON: score+=2; tags.append(COMMON[tok])
    return score,tags

# ---------- 主循环: persona 策划标签 漏网 ----------
louwang=[]; in_final=0; persona_rows=0
for row in ROWS:
    title=row[CI_TITLE]; persona=row[CI_PERSONA]; keep=row[CI_KEEP].strip()
    nt=norm_title(title)
    if nt in fin_titles:
        in_final+=1; continue
    if (not persona) or persona.strip().lower()=='none':
        continue   # 无策划标签 -> 不进漏网(避免自由文本污染)
    persona_rows+=1
    sc,tags=vr_from_persona(persona)
    hi=classify_hi(title,row[CI_TEXT])
    if hi in ('噪声','明确非高层'):
        continue
    if hi=='高层': sc+=2; tags.append('高层')
    elif hi=='多层公寓': sc+=1; tags.append('多层公寓')
    if sc>=2:  # 至少命中一个群体
        louwang.append({'VR分':sc,'标签':'+'.join(tags),'是否高层':hi,
                        '原persona':persona,'原决策':keep,'核心事件':title[:78],
                        '链接':row[CI_LINK][:88],'原因':(row[CI_REASON] or '')[:36]})

# 稀缺优先排序
def rank(d):
    scarce = 1 if '稀缺' in d['标签'] else 0
    return (scarce, d['VR分'])
louwang.sort(key=rank, reverse=True)

with open(f"{ROOT}/_rescreen_louwang.csv",'w',encoding='utf-8-sig',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=['VR分','标签','是否高层','原persona','原决策','核心事件','链接','原因'])
    w.writeheader()
    for d in louwang: w.writerow(d)

print("8180 总:",len(ROWS),"| 命中终稿125:",in_final,"| 有persona标签:",persona_rows)
print(">>> persona漏网(带弱势群体标签/未进125/非噪声非低层):",len(louwang),"条")
print("\n--- 稀缺群体漏网 (视障/听障/轮椅/行动不便/孕妇, 最该捞) ---")
n=0
for d in louwang:
    if '稀缺' in d['标签']:
        n+=1
        print(f"  [VR{d['VR分']}|{d['是否高层']}|原{d['原决策']}] {d['标签']} | {d['核心事件'][:52]}")
        if n>=30: break
print(f"\n(稀缺漏网共 {sum(1 for d in louwang if '稀缺' in d['标签'])} 条)")
print("\n--- 普通群体漏网 TOP15 (老年/儿童) ---")
m=0
for d in louwang:
    if '稀缺' not in d['标签']:
        m+=1
        print(f"  [VR{d['VR分']}|{d['是否高层']}|原{d['原决策']}] {d['标签']} | {d['核心事件'][:52]}")
        if m>=15: break
print("\n-> _rescreen_louwang.csv")

