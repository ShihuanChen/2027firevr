import json
import subprocess

records = [
    {
        "编号": "4213",
        "正文/摘要": "随着城市天际线的不断拔高，大量早期建成的高层建筑逐渐进入“老龄化”周期，如何守住“云端”之上的安全底线，已成为社会各界关注的焦点。 国务院安委会近期部署开展高层建筑重大火灾风险隐患排查整治行动，聚焦有人员居住和活动的高层民用建筑开展排查整治，要求全面加强高层建筑消防安全管理，切实保障人民群众生命财产安全。 那么，建城时间久远、业态多元复杂、人口规模庞大的广州情况如何？日前，南都N视频记者兵分多路，对广州多片区域的高层商住楼宇进行了消防安全调查。在调查中记者发现，城市更新工作需要关注的消防问题，正从低矮的老旧小区，向高层高龄建筑延伸。 被挤占的疏散通道、老旧损坏的消防设施、不容忽视的潜藏风险、亟待提升的治理方式……看得见的“明患”和想得到的“隐患”交织潜伏在楼宇之间，围困着城市“生命线”，成为不容忽视的安全短板。 图为天河区尚德大厦，疏散通道及消火栓被堆积杂物阻挡。 被挤占的疏散通道： 杂物堆积仅能侧身过，记者险被绊倒 消火栓被遮挡，提示也无用 荔湾区金兰苑小区的剑兰大厦，1994年建成，23层高楼三座塔楼住着近500户人家。从鞋柜、自行车、婴儿车，到花盆、废旧家具、纸箱泡沫……五花八门的物品长年侵占大部分楼道与楼梯间。 记者随机走进一栋塔楼，22层中有20层可见杂物堆积。约两米宽、7米长的楼道内，少则几辆自行车、几盆大型盆景，多则各种杂物占据了2/3的通道，不少已覆上一层厚厚的灰尘，可见堆积时日之久。 荔湾区剑兰大厦的某层楼道内，堆积着各类私人物品，不少已覆上厚厚的灰尘。 越往高层，疏散通道杂物堆积越严重——消火栓几乎被埋没在杂物之中，楼梯间入口处仿佛成了“室外储藏室”，楼梯转角处被挤占得只剩侧身通行的空间，令人瞠目结舌。尤其在一楼梯间转角，堆积的杂物令脚下空间仅剩十来公分，记者背着背包侧身挤过，却因避开杂物险些被绊倒。 在这里，每个消防栓外都贴有物管巡查表，最新记录为今年1月5日，“箱体完好”“水带水枪”等栏目均被打钩，唯独“障碍物”一栏空着。 事实上，楼道墙上贴有不少物管的清理通知，最早可追溯到2018年，最近的是2025年6月。通知的语气从“部分楼道存在私人物品随意堆放的情况”的温馨提醒，渐变为“将联合政府部门清理”的严肃告诫，但杂物依旧。 2018年3月张贴的楼道杂物清理通知。 建成于2006年的尚德大厦坐落于天河区，是一座典型的包含公寓、写字楼及商场的商住结合楼宇，也存在较为明显的杂物堆积阻碍消防通道的情况。 大厦B座低层主要由多家食肆和两家酒店租赁使用。记者走访时发现，二楼一处防火卷帘门下，虽贴有“禁止堆放物品”的标语，仍有商家将装满食材的箱子放在此处；三楼的电竞酒店门口，几台清洁机器包围着消火栓。 从三楼顺着疏散通道往上，有的楼层并未安装照明设施，需要打开手电才方便行走。到了四层与五层，疏散通道堆满酒店使用的布草、塑料桶、垃圾车，以及储物柜等大件物品，不仅影响消火栓开启，也阻碍了疏散通道的正常出入。 在尚德大厦，疏散通道随意堆放的柜子等大件物品，将消火栓掩在了背后。 更严重的是，尽管贴有禁止吸烟的标语，仍有部分人员将消防通道视为吸烟场所。记者注意到，在堆放泡沫箱的角落地面，有多个烟头。 “我们这里是小户型，空间有限。”在大厦高层的商住结合区域，有不少居民将桌椅、鞋柜、自行车、快递箱等杂物放置在过道，部分杂物已经影响到消防器材的正常取用。但有租户认为，即使鞋柜摆到走廊也不会影响通行，“反正邻居也都是这样摆的。” 同样位于天河区的金泽大厦，是一座近30年楼龄的高层商住一体楼，临街一至三层有食肆、美容机构等业态，往上为居民楼，最高28楼，也存在同样情况。 “为保障消防通道通畅及公共安全，请各位业主/住户于12月5日前自行清理个人物品。”在该大厦负一层车库的安全出口，物管张贴的清理告示下就赫然有一处用木板围成的区域，堆满了大量泡沫箱等易燃品。 顺着疏散通道往上，出现了更多杂物堆积的情况。其中，杂物同时堵塞了二楼的一处安全出口和一旁的消火栓，且防火门被锁上。 天河区金泽大厦的疏散通道和安全出口同样存在杂物阻塞情况。 老旧坏损的消防设施： 闭门器坏损，防火门不常闭 灭火器失压，无法正常使用 广州拥有大量落成于20世纪90年代的高层建筑，它们或多或少面临消防设施老旧的情况。记者发现，有建筑的防火门呈敞开状态，无法自动关闭。若发生火灾，浓烟极易蔓延至疏散通道，届时逃生将变得困难甚至危险。 在一栋28年楼龄的高层商住一体楼内，记者从该栋楼的顶层步行至一楼过程中，发现了闭门器损坏致使防火门无法自动回弹关闭的情况，共有14个门未关闭。 记者走访调查期间，有大厦内的部分防火门闭门器坏损，无法自动闭合。 在记者反映情况的次日，该楼栋物管项目经理回复称此前已注意到该问题，于今年1月1日批量采购了配件，将尽快更换安装。1月13日晚，该楼的防火",
        "判定批次": ["边缘候选补判"],
        "视角": ["第三人称"],
        "叙事视角": ["官方/媒体全知"],
        "叙事结构": ["多线"],
        "情感标签": ["无助"],
        "VR可模拟性": "疏散通道杂物堆积、消火栓被遮挡、防火门闭门器损坏等场景可直接转化为VR环境障碍与交互限制",
        "身体主体": ["普通成年人", "老年人", "儿童"],
        "氛围叙事机制": ["信息呈现", "环境模拟", "V_framing"],
        "交互机制": ["限制模拟", "E3交互"]
    },
    {
        "编号": "1348",
        "正文/摘要": "Ghaziabad: A residential building in Indirapuram with 20 flats caught fire on Wednesday night after a skyshot firework exploded in the balcony of a second-floor house and started a blaze that reached the fifth floor within minutes. Crackers were being burst on the street at Friends Avenue – part of extended Diwali celebrations that NCR has been seeing, with Supreme Court's orders restricting cracker-bursting to a two-hour evening window largely ignored, and not enforced either. Six fire tenders took nearly three hours to extinguish the blaze. No resident was injured. An FIR was lodged against two persons.  Rescued residents said they had told people not to burst crackers near the house, but no one listened. Chief fire officer Rahul Pal said Vaishali fire station received information around 8.30pm that a fire had broken out at Divya Building in Shakti Khand 2. The fire officer in charge left for the site with three fire tenders. Fire tenders stationed at Kala Patthar, Indirapuram, and Atal Chowk, Vasundhara, for Diwali were also deployed.  \"It was observed that there were 20 flats, out of which the balconies of 12 that were covered with fibre sheets were burning intensely.  Considering the intensity of the blaze, a fire tender was also called from Sahibabad. The fire service unit, wearing breathing gear, entered the smoke-filled flats and brought the flames under control. There was no loss of life; however, items kept on balconies got burnt. Belongings inside the flats were safe,\" Pal said. The façade of the building was singed.  A police investigation revealed that two persons were bursting firecrackers at the building gate, and one of the skyshots went astray. The blaze spread quickly. Pal said some residents rushed to the terrace and jumped to the adjacent building. Around 20 were still trapped when the fire brigade reached and were evacuated.  Building resident Deepak Tyagi said his house was the first to catch fire as the firework came through the balcony and hi",
        "判定批次": ["边缘候选补判"],
        "视角": ["第三人称"],
        "叙事视角": ["官方/媒体全知"],
        "叙事结构": ["线性"],
        "情感标签": ["恐惧"],
        "VR可模拟性": "烟花射入阳台引发火势、住户向天台撤离并跳至相邻建筑",
        "身体主体": ["普通成年人", "儿童"],
        "氛围叙事机制": ["环境模拟", "多模态感知剥夺"],
        "交互机制": ["E3交互"]
    },
    {
        "编号": "5641",
        "正文/摘要": "Bristol council apology after over-60s 'stuck inside tower block behind broken door' \"This created a serious risk\" Council chiefs have apologised to residents of an over-60s tower block in South Bristol, after it took three days to fix the front door, leaving some elderly people inside unable to get out of the building. A formal complaint has been submitted by the tenants’ representative of the tower block, saying the council left many in the building in a potentially dangerous situation for days. Residents at Gilton House in Brislington first began reporting that the electric-powered mechanism on the only door out of the building had failed at around 3pm last Tuesday (July 1). It meant the door had to be opened manually, by over-riding the mechanism by force - something many residents couldn’t do, leaving them unable to get out of the building or calling on neighbours for help. Nigel Varley, who lives in the block and is the residents’ rep, said that was a potentially dangerous situation. “The door had to be pushed open,” he said. “It is very stiff and some of our residents with limited mobility found this either very difficult or impossible. Also, if the door-opening button was pushed, the door jammed until the electric motor stopped working,” he added. “This created a serious risk. If a fire had broken out and people evacuated, perhaps in smoke, the difficulty in opening the door would have created panic and possibly trapped people inside. “There is another fire escape but that is in the community room which is kept locked so residents evacuating in a hurry who left their key behind could not use it,” he claimed. However, the council said it is \"confident that there was no adverse impact on any tenant’s ability to evacuate the building\". Residents of Gilton House began to call Bristol City Council that Tuesday afternoon but said it was a challenge to persuade the city council of the seriousness of the situation. “The caller had difficulty in persuading the operat",
        "判定批次": ["边缘候选补判"],
        "视角": ["第三人称"],
        "叙事视角": ["目击者/邻居"],
        "叙事结构": ["线性"],
        "情感标签": ["愤怒"],
        "VR可模拟性": "老年住户因大门电动装置故障难以推开、社区活动室消防逃生门被锁",
        "身体主体": ["老年人"],
        "氛围叙事机制": ["信息呈现", "环境模拟", "V_framing"],
        "交互机制": ["限制模拟", "E3交互"]
    },
    {
        "编号": "7165",
        "正文/摘要": "Grenfell families' fury after government demolishes wall with handprints from night of deadly blaze The wall lay between the 12th and 14th floors and was completely blackened with smoke and covered in handprints following the blaze. Fury has grown after a wall showing the handprints of Grenfell Tower victims who were trapped in the building as the fire raged was destroyed - despite pleas from next of kin to preserve it. Listen to this article Relatives of the 72 people victims of the 2017 inferno in North Kensington, west London, found the wall during pre-demolition visits to the building in July last year. The wall lay between the 12th and 14th floors and was completely blackened with smoke following the blaze. Powerful images show the wall marked with prints of different sizes. The victims’ families had urged the Government to save these parts of the building from being destroyed and have threatened to take Housing Secretary Steve Reed to court over its demolition. It comes after his predecessor Angela Rayner vowed that the wall would not be destroyed. Read more: Government pressed over why Grenfell cladding ‘crooks’ not behind bars In July 2025, immediate families of the deceased entered Grenfell Tower for the first time. — GRENFELLNEXTOFKIN (@Grenfellnextkin) March 15, 2026 They saw the inscriptions and handprints left in the stairwell — powerful traces of the struggle for life that night. Families asked that these relics be preserved according to the… pic.twitter.com/ADXGwbBYN4 However, the government later said it would not keep any sections above the ninth floor due to concerns about sensitivity and the loss of life on the upper floors. Grenfell Next of Kin, a group made up of the families of Grenfell disaster victims, took to X to hit out at the demolition. It wrote in a lengthy post on Sunday: “On this Mother’s Day, Grenfell families remember mothers and children who they lost forever due to catastrophic State and Corporate negligence.“ But they’re also ask",
        "判定批次": ["边缘候选补判"],
        "视角": ["第三人称"],
        "叙事视角": ["家属/亲友"],
        "叙事结构": ["倒叙"],
        "情感标签": ["悲伤"],
        "VR可模拟性": "灾后纪念墙（手印）的保存与拆除争议，适合纪念馆/纪念碑式VR体验，非主动逃生场景",
        "身体主体": ["普通成年人"],
        "氛围叙事机制": ["信息呈现", "V_framing"],
        "交互机制": ["V处境困难"]
    }
]

payload = {"create_records": records}
json_path = "_batch_create_rescued.json"
with open(json_path, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False)
cmd = f'lark-cli base +record-batch-create --base-token MBmvbhTH1aYGRzsmFYpcbuU3n6f --table-id tbljjPOxZdQGDKUc --as user --json "@{json_path}"'
result = subprocess.run(cmd, capture_output=True, text=True, shell=True, encoding="utf-8", errors="replace")
print("STDOUT:", result.stdout)
print("STDERR:", result.stderr)
print("RETURN:", result.returncode)
