# -*- coding: utf-8 -*-
"""
闭环评估 A：金标准 403 条重算筛选精度 P/R/F1 + 正文有效层误杀评估
用法（在 工作流 目录下）: python _eval403_precision.py
复用规则（单一事实来源，不重写模型）:
  路1 关键词委员会: active_learn_committee.vote_*（三票 -> auto_drop/uncertain）
  路2 正则规则 v2:  _rescreen_6666_v2.classify_fire_v2（正反证据权衡）
输出:
  _eval403_gold.csv          403 子集 (gid,label,title)
  _eval403_with_text.csv     403 子集 + 正文长度/正文头
  _精度评估报告_403金标准.md  汇总报告
"""
import csv, os, re, sys
from collections import Counter

csv.field_size_limit(10**9)
D = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, D)
os.chdir(D)

import active_learn_committee as alc      # 路1
import _rescreen_6666_v2 as rs            # 路2（含 classify_fire_v2/classify_hi_v2/scan_groups/scan_sens）

def load_merged():
    out = []
    with open(os.path.join(D, "_merged_user_labels.csv"), encoding="utf-8-sig", errors="ignore", newline="") as f:
        for r in csv.DictReader(f):
            out.append({"gid": int(r["gid"]), "label": int(r["label"]), "title": r.get("title", ""), "L": int(r.get("L") or 0)})
    return out

def load_grok_gids():
    g = set()
    with open(os.path.join(D, "_全量_grok判定.csv"), encoding="utf-8-sig", errors="ignore", newline="") as f:
        for r in csv.DictReader(f):
            g.add(int(r["gid"]))
    return g

def load_draft():
    """gid = 行号(1-based)；返回 {gid: {title, body, fetch_status, text_length}}"""
    out = {}
    with open(os.path.join(D, "第三轮_含正文_筛选草稿.csv"), encoding="utf-8-sig", errors="ignore", newline="") as f:
        reader = csv.reader(f)
        header = [c.strip() for c in next(reader)]
        ci = {c: i for i, c in enumerate(header)}
        for i, row in enumerate(reader, start=1):
            g = i
            def gv(name):
                j = ci.get(name)
                return row[j] if (j is not None and j < len(row)) else ""
            out[g] = {"title": gv("核心事件"), "body": gv("文本"), "fetch_status": gv("fetch_status"), "text_length": gv("text_length")}
    return out

def load_goldset103():
    out = []
    with open(os.path.join(D, "人机协作_GoldSet_103.csv"), encoding="utf-8-sig", errors="ignore", newline="") as f:
        for r in csv.DictReader(f):
            out.append({"gid": int(r["idx"]), "keep_label": r["keep_label"], "reason": r.get("human_reason", ""),
                        "text_length": r.get("text_length", ""), "text_excerpt": r.get("text_excerpt", "")})
    return out

def metrics(truth, pred):
    """truth/pred: list of 0/1（正类=1）"""
    tp = sum(1 for t, p in zip(truth, pred) if t == 1 and p == 1)
    fp = sum(1 for t, p in zip(truth, pred) if t == 0 and p == 1)
    fn = sum(1 for t, p in zip(truth, pred) if t == 1 and p == 0)
    tn = sum(1 for t, p in zip(truth, pred) if t == 0 and p == 0)
    P = tp / (tp + fp) if tp + fp else 0
    R = tp / (tp + fn) if tp + fn else 0
    F1 = 2 * P * R / (P + R) if P + R else 0
    return {"TP": tp, "FP": fp, "FN": fn, "TN": tn, "P": P, "R": R, "F1": F1, "n_pred_keep": tp + fp}

def main():
    print("== Step 1: 提取 403 子集 ==")
    merged = load_merged()
    gids6666 = load_grok_gids()
    gold403 = [r for r in merged if r["gid"] not in gids6666]
    lab = Counter(r["label"] for r in gold403)
    print(f"  694 中池外 {len(gold403)} 条；label 分布 {dict(lab)}（预期 1:31 / 0:372）")
    keep31 = lab[1] == 31 and lab[0] == 372
    if not keep31:
        print("  !! 与预期 31/372 不符，继续但报告中标注差异")
    with open(os.path.join(D, "_eval403_gold.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f); w.writerow(["gid", "label", "title"])
        for r in sorted(gold403, key=lambda x: x["gid"]):
            w.writerow([r["gid"], r["label"], r["title"][:120]])
    gids403 = {r["gid"] for r in gold403}

    print("== Step 2: 补正文 ==")
    draft = load_draft()
    rows_text = []
    miss = []
    for r in sorted(gold403, key=lambda x: x["gid"]):
        d = draft.get(r["gid"])
        if d and d["body"]:
            rows_text.append({"gid": r["gid"], "label": r["label"], "title": r["title"],
                              "fetch_status": d["fetch_status"], "text_length": d["text_length"],
                              "text": d["body"]})
        else:
            miss.append(r["gid"])
    print(f"  正文命中 {len(rows_text)}/{len(gold403)}；缺失 {len(miss)} gid={miss[:20]}")
    with open(os.path.join(D, "_eval403_with_text.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f); w.writerow(["gid", "label", "title", "text_len", "fetch_status", "text_head200"])
        for r in rows_text:
            w.writerow([r["gid"], r["label"], r["title"][:120], len(r["text"]), r["fetch_status"],
                        r["text"][:200].replace("\n", " ")])
    print(f"  -> _eval403_with_text.csv 已写")

    print("== Step 3: 两路判定 ==")
    truth = [1 if r["label"] == 1 else 0 for r in rows_text]
    # ---- 路1 关键词委员会 ----
    pred1_funnel, pred1_strict, detail1 = [], [], []
    for r in rows_text:
        title, body = r["title"], r["text"]
        L = len(body)
        if L < 400:
            pred1_funnel.append(0); pred1_strict.append(0)
            detail1.append({"gid": r["gid"], "verdict": "short", "votes": [], "n_keep": 0}); continue
        if any(p.search(title) for p in alc.EXCLUDE_PAT):
            pred1_funnel.append(0); pred1_strict.append(0)
            detail1.append({"gid": r["gid"], "verdict": "excluded", "votes": [], "n_keep": 0}); continue
        v1, _ = alc.vote_v1_keyword(title, body)
        v2, _ = alc.vote_length_struct(body)
        v3, _ = alc.vote_vulnerable_narrative(title, body)
        n_keep = sum(1 for v in (v1, v2, v3) if v == "keep")
        # 漏斗口径：候选池 = 非 auto_drop（有任一 keep 票）
        funnel = 1 if n_keep >= 1 else 0
        # 严格口径（敏感性）：至少两票 keep 才算保留
        strict = 1 if n_keep >= 2 else 0
        pred1_funnel.append(funnel); pred1_strict.append(strict)
        detail1.append({"gid": r["gid"], "verdict": "uncertain" if funnel else "auto_drop", "votes": [v1, v2, v3], "n_keep": n_keep})
    m1f = metrics(truth, pred1_funnel); m1s = metrics(truth, pred1_strict)
    print(f"  路1 关键词委员会 漏斗口径: P={m1f['P']:.3f} R={m1f['R']:.3f} F1={m1f['F1']:.3f} (TP{ m1f['TP']}/FP{m1f['FP']}/FN{m1f['FN']})")
    print(f"  路1 严格口径(n_keep>=2):  P={m1s['P']:.3f} R={m1s['R']:.3f} F1={m1s['F1']:.3f} (TP{m1s['TP']}/FP{m1s['FP']}/FN{m1s['FN']})")
    # ---- 路2 规则 v2 ----
    pred2, detail2 = [], []
    for r in rows_text:
        fire_rel, pos, neg = rs.classify_fire_v2(r["title"], r["text"])
        keep = 1 if fire_rel in ("火灾相关", "火灾相关(混合)") else 0
        pred2.append(keep)
        detail2.append({"gid": r["gid"], "fire_rel": fire_rel})
    m2 = metrics(truth, pred2)
    print(f"  路2 规则 v2:              P={m2['P']:.3f} R={m2['R']:.3f} F1={m2['F1']:.3f} (TP{m2['TP']}/FP{m2['FP']}/FN{m2['FN']})")

    print("== Step 4: 正文有效层误杀评估 ==")
    gs = load_goldset103()
    in_pool = sum(1 for g in gs if g["gid"] in gids6666)
    out_pool = [g for g in gs if g["gid"] not in gids6666]
    keep_half = [g for g in gs if g["keep_label"] in ("1", "0.5")]
    keep_half_out = [g for g in keep_half if g["gid"] not in gids6666]
    print(f"  GoldSet103: 池内 {in_pool} / 池外 {len(out_pool)}")
    print(f"  真值(keep=1或0.5)共 {len(keep_half)} 条，被滤(池外) {len(keep_half_out)} 条 -> gid {[g['gid'] for g in keep_half_out]}")
    # 被滤原因：fetch_status
    st = Counter()
    for g in out_pool:
        d = draft.get(g["gid"], {})
        st[(d.get("fetch_status", "?"), (d.get("text_length", "?"))[:6])] += 1
    print(f"  池外 gid 的 fetch_status/text_length 分布(前10): {st.most_common(10)}")

    print("== Step 5: 写报告 ==")
    lines = []
    lines.append("# 精度评估报告：金标准 403 条重算 P/R/F1 + 正文有效层误杀")
    lines.append("")
    lines.append(f"- 评估日期：2026-08-20；口径：label 31 keep / 372 drop（`_merged_user_labels.csv` 文件权威，3 条 0.5 半保不计入二分类）")
    lines.append(f"- 403 子集来源：694 条人工金标准中 gid ∉ 6666 grok 池的 {len(gold403)} 条（另 291 条在池内=阶段三精判）；694 = 403 + 291")
    lines.append(f"- 正文命中 {len(rows_text)}/{len(gold403)}；缺失 gid：{miss if miss else '无'}")
    lines.append("")
    lines.append("## 一、两路判定 P/R/F1（正类=人工 keep=1，共 31 条）")
    lines.append("")
    lines.append("| 判定路 | 口径 | P | R | F1 | TP | FP | FN |")
    lines.append("|---|---|---|---|---|---|---|---|")
    lines.append(f"| 关键词委员会 | 漏斗（任一 keep 票=保留候选） | {m1f['P']:.3f} | {m1f['R']:.3f} | {m1f['F1']:.3f} | {m1f['TP']} | {m1f['FP']} | {m1f['FN']} |")
    lines.append(f"| 关键词委员会 | 严格（≥2 keep 票） | {m1s['P']:.3f} | {m1s['R']:.3f} | {m1s['F1']:.3f} | {m1s['TP']} | {m1s['FP']} | {m1s['FN']} |")
    lines.append(f"| 正则规则 v2 | 火灾相关/(混合) 即保留 | {m2['P']:.3f} | {m2['R']:.3f} | {m2['F1']:.3f} | {m2['TP']} | {m2['FP']} | {m2['FN']} |")
    lines.append("")
    lines.append("对照旧值（memory 记录，旧口径，仅参考）：关键词 P=14.4%/R=91.7%；Grok P=24.4%/R=41.7%；few-shot R=54.2%")
    lines.append("")
    lines.append("## 二、正文有效层（8180→6666）误杀评估（GoldSet103）")
    lines.append("")
    lines.append(f"- GoldSet103 共 103 条：池内 {in_pool} / 池外 {len(out_pool)}")
    lines.append(f"- 真值（keep=1 或 0.5）{len(keep_half)} 条中，被『正文有效』层滤掉 {len(keep_half_out)} 条：gid {[g['gid'] for g in keep_half_out]}")
    lines.append(f"- 池外 gid 的 fetch_status/text_length 分布：{st.most_common(10)}")
    lines.append("")
    lines.append("## 三、结论")
    lines.append("- 待报告完成后人工补充。")
    with open(os.path.join(D, "_精度评估报告_403金标准.md"), "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines))
    print("  -> _精度评估报告_403金标准.md 已写（结论段待补充）")

if __name__ == "__main__":
    main()
