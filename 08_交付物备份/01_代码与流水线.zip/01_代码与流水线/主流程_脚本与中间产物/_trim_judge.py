﻿import os
# -*- coding: utf-8 -*-
"""砍成一张可判断的小表(带正文): ②qwen核验保留(value>=4) + 全部稀缺(7)。"""
import csv, sys
from collections import Counter
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(f"{ROOT}/_judge_table_合并.csv", encoding='utf-8-sig')))

# 完整正文: 按 gid(=第三轮行号, 1-based) 从 第三轮_含正文_筛选草稿.csv 的 `文本` 列取
body_map = {}
gids = {r['gid'] for r in rows}
with open(f"{ROOT}/第三轮_含正文_筛选草稿.csv", encoding='utf-8-sig') as fh:
    rd = csv.reader(fh); h = next(rd); bi = h.index('文本')
    for i, line in enumerate(rd, 1):
        if str(i) in gids:
            body_map[str(i)] = line[bi]
            if len(body_map) == len(gids): break

SCARCE = {'视障','听障','轮椅','拄拐','孕妇','残疾','婴儿'}
def sc(v): return 1 if any(g in SCARCE for g in (v.split('+') if v else [])) else 0
def val(r): return int(r['正则_value']) if r['正则_value'].isdigit() else 0
def is_2Y(r): return r['来源层'].startswith('②') and r['qwen判定']=='Y'

# 主判断表: ②qwen核验保留(value>=4) + 全部稀缺(7, 来自①混合文)
short = [r for r in rows if (is_2Y(r) and val(r) >= 4) or sc(r['正则_vulnerable'])]
short.sort(key=lambda r: (0 if is_2Y(r) else 1, -val(r)))   # 核验保留在前, 稀缺混合文沉末

flds = ['来源层','gid','标题','正文','正则_fire_rel','正则_high_rise','正则_vulnerable','正则_value','qwen判定','qwen理由','人工判断']
miss = 0
with open(f"{ROOT}/_judge_shortlist.csv",'w',encoding='utf-8-sig',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=flds); w.writeheader()
    for d in short:
        d['正文'] = body_map.get(d['gid'], '')
        if not d['正文']: miss += 1
        w.writerow({k:d[k] for k in flds})

# parked 分类(不含正文, 节省体积)
def bucket(r):
    if is_2Y(r): return '② qwen已判保留但价值偏低(v3,弱保留)'
    if r['来源层'].startswith('②') and r['qwen判定']=='N': return '② qwen已判排除(信任,免审)'
    if r['来源层'].startswith('①') and '混合' in r['正则_fire_rel']: return '① 混合文(抓取揉一起,边界噪声,暂不审)'
    return '① 正则漏网·非稀缺(丢弃层复捞,未过语义,暂不审)'
parked = [r for r in rows if r not in short]
for r in parked: r['_b']=bucket(r)
park_cols=['来源层','gid','标题','正则_fire_rel','正则_high_rise','正则_vulnerable','正则_value','qwen判定','parked_原因']
with open(f"{ROOT}/_judge_parked.csv",'w',encoding='utf-8-sig',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=park_cols); w.writeheader()
    for d in parked: w.writerow({k:d.get(k,'') for k in park_cols})

print(f"主判断表(你审): {len(short)} 条 -> _judge_shortlist.csv  (正文缺失: {miss})")
print(f"  ②qwen核验保留(v>=4): {sum(1 for r in short if is_2Y(r))} | 稀缺(①混合文): {sum(sc(r['正则_vulnerable']) for r in short)}")
print(f"  正文取自足本 第三轮_含正文_筛选草稿.csv (完整文本, 按gid=行号)")
print(f"\nparked(暂不审): {len(parked)} 条 -> _judge_parked.csv")
print("  分类:", dict(Counter(r['_b'] for r in parked)))

