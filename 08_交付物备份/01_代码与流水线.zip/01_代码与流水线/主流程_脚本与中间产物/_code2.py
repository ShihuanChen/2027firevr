# -*- coding: utf-8 -*-
import json, re

d = json.load(open('工作流/_mainrecs_all.json', encoding='utf-8'))
fields = d['data']['fields']            # TRUE column order (field names)
rids   = d['data']['record_id_list']
recs   = d['data']['data']

def rec_to_dict(r):
    return {fields[i]: r[i] for i in range(len(fields))}

def is_empty(v):
    if v is None: return True
    if isinstance(v, list) and len(v) == 0: return True
    if isinstance(v, str) and v.strip() == '': return True
    return False

def get_text(rec):
    t = rec.get('正文/摘要') or rec.get('标题') or ''
    if isinstance(t, list): t = ' '.join(t)
    return t

def first_sentence_with(text, kws, limit=200):
    if not text: return ''
    sents = re.split(r'(?<=[.!?。！？])\s*', text)
    for s in sents:
        if any(k.lower() in s.lower() for k in kws):
            return s.strip()[:limit]
    return text.strip()[:limit]

# ---- static mappings ----
role2body = {
    '陈伯（老年）':'老年人','阿May（听障）':'听障者','罗姐（轮椅）':'轮椅使用者',
    '威廉（视障）':'视障者','King仔（儿童）':'儿童','阿福（拄拐）':'拄拐/助行器',
    '普通成年人':'普通成年人','救援者':'救援者'
}
body2role = {v:k for k,v in role2body.items()}
persona_clean = {
    '威廉 视障':'视障者(威廉)','阿May 听障':'听障者(阿May)','罗姐 轮椅':'轮椅使用者(罗姐)',
    '阿福 拄拐':'拄拐者(阿福)','陈伯 老年':'老年人(陈伯)','King仔 儿童':'儿童(King仔)'
}
named_personas = ['威廉 视障','阿May 听障','罗姐 轮椅','阿福 拄拐','陈伯 老年','King仔 儿童']

I1_KW = ['surviv','escap','fled','evacu','trap','died','dead','kill','fire','neighbor',
         'family','rescu','alarm','scream','smoke','carri','helped','pulled','called 911',
         'called fire','rushed','burn','injur','witness','recount','recall','mother','father',
         'daughter','son','husband','wife','panic','horror','desperate','survivor',
         '幸存','逃生','被困','遇难','救援','邻居','家属','惊恐','绝望']
I2_KW = ['escape','evacuat','flee','rescu','firefighter','neighbor','stair','stairwell','door',
         'window','break','carri','pull','crawl','climb','alert','alarm','called','scream',
         'knock','bang','wet towel','mask','helped','led out','guided','descend','rush','grab',
         'drag','lift','carry','wheelchair','warning','sirens','break windows','jump',
         '破门','拍门','呼救','爬行','攀爬','湿毛巾','火警','抱','牵','推轮椅','破窗','防火门',
         '逃生','撤离','救援','下楼','楼梯','示警','背']

def derive_building(rec):
    txt = get_text(rec).lower()
    savt = rec.get('SAVTBC_S空间') or ''
    if isinstance(savt, list): savt = ' '.join(savt)
    if '高层' in savt or re.search(r'high-?rise|tower (?:block|building)|high-rise apartment', txt):
        return '高层住宅'
    if re.search(r'hotel|mall|shopping|office|market|factory|warehouse|store ', txt):
        return '商业及其他'
    if re.search(r'\bhouse\b|two-story|one-story|single-family|bungalow|low-rise', txt):
        return '低层住宅'
    return '公寓(集合住宅)'

def derive_cause(rec):
    txt = get_text(rec).lower()
    if re.search(r'arson|deliberately|suspicious fire|set fire|accelerant', txt): return '纵火'
    if re.search(r'charg|e-bike|lithium|battery|power bank|ebike', txt): return '充电设备'
    if re.search(r'electrical|wiring|short circuit|faulty (?:wire|electric)', txt): return '电气'
    if re.search(r'cooking|kitchen|stove|grease|oven', txt): return '烹饪'
    if re.search(r'candle|smoking|cigarette|smoked', txt): return '用火不慎'
    return '不明'

def derive_casualty(rec):
    txt = get_text(rec).lower()
    if re.search(r'killed|died|dead|death|fatality|perish|lost their live', txt):
        if re.search(r'(?:several|multiple|at least \d|more than \d|dozens?|many) .*(?:killed|dead|died)|killed \d+|\d+ dead|\d+ killed', txt):
            return '群死群伤'
        return '死亡'
    return None

def derive_region(rec):
    txt = get_text(rec)
    tl = txt.lower()
    if re.search(r'hong kong|hongkong|\bhk\b|大埔|宏福|淘大|牛池湾', tl): return '中国香港'
    if re.search(r'grenfell|london|manchester|britain|\buk\b|united kingdom|england|scotland|paris|france|spain|italy|germany', tl): return '欧洲(含英国)'
    if re.search(r'dallas|new york|chicago|los angeles|houston|toronto|canada|united states|\bus\b|american|philadelphia|miami|boston|seattle', tl): return '北美'
    return '其他'

# ---------- main loop ----------
update = {}
filled = {}
for k, r in enumerate(recs):
    rec = rec_to_dict(r)
    rid = rids[k]
    ch = {}

    # I1证据句 (narrative evidence) : 125 empty -> fill all
    if is_empty(rec.get('I1证据句')):
        i1 = first_sentence_with(get_text(rec), I1_KW)
        if i1:
            ch['I1证据句'] = i1
            filled['I1证据句'] = filled.get('I1证据句',0)+1

    # I2证据句 (interaction evidence) : 125 empty -> fill all (English+Chinese keywords)
    if is_empty(rec.get('I2证据句')):
        i2 = first_sentence_with(get_text(rec), I2_KW)
        if i2:
            ch['I2证据句'] = i2
            filled['I2证据句'] = filled.get('I2证据句',0)+1

    # VR场景对应角色 (text) : 125 empty -> fill all
    if is_empty(rec.get('VR场景对应角色')):
        persona = None
        six = rec.get('六角色对接') or []
        if isinstance(six, list) and six: persona = six[0]
        if not persona:
            roles = rec.get('交互_身体化角色') or []
            for rp in roles:
                if rp in named_personas:
                    persona = rp; break
        if not persona:
            roles = rec.get('交互_身体化角色') or []
            if roles: persona = roles[0]
        pc = persona_clean.get(persona, persona) if persona else '普通成年人'
        mv = rec.get('交互_移动方式') or []
        move = mv[0] if isinstance(mv,list) and mv else ''
        bld = rec.get('建筑类型') or derive_building(rec)
        vr = f"{bld}｜{pc}｜{move}" if move else f"{bld}｜{pc}"
        ch['VR场景对应角色'] = vr
        filled['VR场景对应角色'] = filled.get('VR场景对应角色',0)+1

    # 场景特征 (text) : fill 38 empty
    if is_empty(rec.get('场景特征')):
        savt = rec.get('SAVTBC_S空间') or ''
        if isinstance(savt, list): savt = ' '.join(savt)
        sens = rec.get('感官主导') or []
        parts = []
        if savt.strip(): parts.append(savt.strip())
        if sens: parts.append('/'.join(sens))
        sf = '；'.join(parts) if parts else '空间/感官未标注'
        ch['场景特征'] = sf
        filled['场景特征'] = filled.get('场景特征',0)+1

    # 交互_身体化角色 (multi) : fill 8 empty
    if is_empty(rec.get('交互_身体化角色')):
        body = rec.get('身体主体') or []
        if isinstance(body, list) and body:
            roles = [body2role.get(b) for b in body if body2role.get(b)]
            if roles:
                ch['交互_身体化角色'] = roles
                filled['交互_身体化角色'] = filled.get('交互_身体化角色',0)+1
        if '交互_身体化角色' not in ch:
            ch['交互_身体化角色'] = ['普通成年人']
            filled['交互_身体化角色'] = filled.get('交互_身体化角色',0)+1

    # NEW analytical fields (all 125)
    ch['建筑类型'] = derive_building(rec)
    ch['火灾起因'] = derive_cause(rec)
    cas = derive_casualty(rec)
    if cas is None:
        txt = get_text(rec).lower()
        if re.search(r'injur|hospitaliz|hurt|burned', txt): cas = '轻伤'
        elif re.search(r'no (?:injur|casualt)|everyone (?:escaped|safe)|unscathed|no one (?:hurt|injured)', txt): cas = '无伤亡'
        else: cas = '不明'
    ch['伤亡等级'] = cas
    ch['地区'] = derive_region(rec)
    for f in ['建筑类型','火灾起因','伤亡等级','地区']:
        filled[f] = filled.get(f,0)+1

    if ch:
        update[rid] = ch

json.dump({'update_records': update}, open('工作流/_update2.json','w',encoding='utf-8'), ensure_ascii=False, indent=1)
print('records updated:', len(update))
print('filled:', json.dumps(filled, ensure_ascii=False))
rid0 = list(update.keys())[0]
print('SAMPLE', rid0, json.dumps(update[rid0], ensure_ascii=False)[:700])
