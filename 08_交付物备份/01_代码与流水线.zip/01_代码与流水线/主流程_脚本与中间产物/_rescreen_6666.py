﻿import os
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重筛 6666 断点 (论文4/5部分数据) — 按用户修正的口径:
  ① 6666之内、1446之外 (即 grok丢弃层 5220条): 有没有高层火灾+高价值被误杀、可还原?
  ② 1446之内、终稿113之外: 有没有高价值该补?
persona 只是高价值的一个分量(高层+火灾相关+弱势群体+具身信号), 不作门槛。
连接键: gid (1446 ⊆ 6666); 终稿用归一化标题 join。
可复现: python _rescreen_6666.py
"""
import csv, sys, re, json
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))

def norm_title(t):
    t = (t or '').lower()
    t = re.sub(r'[^a-z0-9一-鿿]+', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()

# ---------- 规则常量 (复用 pipeline v3) ----------
ANCHOR_HI = {'宏福苑','格伦费尔','grenfell','明尚','伦敦大火','香港','hochhaus','olympic tower','bronx'}
NOISE = [r'firewood rack', r'fire truck shortage', r'\battorney\b', r'lawyer', r'ben crump',
         r'setting your design ablaze', r'voice to the voiceless', r'burnout', r'deepfake',
         r'photographs that defined', r'best .* rack', r'recipe', r'\bdiy\b',
         r'gunfire', r'firefight', r'\bshooting\b', r'\bgunman\b', r'mass shooting', r'open fire']
HIGH = [r'high[-\s]?rise', r'skyscraper', r'\btower\b', r'高层', r'高楼', r'大厦', r'塔楼', r'宏福苑',
        r'格伦费尔', r'grenfell', r'明尚', r'伦敦大火', r'公寓楼', r'住宅楼', r'小区', r'苑', r'hochhaus',
        r'\b\d{1,2}(st|nd|rd|th)?\s*floor\b', r'第\s*\d+\s*层',
        r'\d{1,2}[-\s]?story', r'\d{1,2}[-\s]?storey', r'\d+\s*层']
LOW_T = [r'\bhouse\b', r'bungalow', r'single-?family', r'self-?built', r'自建房', r'民房', r'平房', r'cottage',
         r'\bvilla', r'独栋', r'房子', r'\bshop\b', r'store', r'铺面', r'商铺', r'五金店', r'church',
         r'cathedral', r'教堂', r'mosque', r'temple', r'寺庙', r'warehouse', r'仓库', r'factory', r'工厂',
         r'\bschool\b', r'学校', r'market', r'市场', r'slum', r'jhuggi', r'窝棚', r'帐篷']
APT = [r'apartment', r'condo', r'condominium', r'\bflat\b', r'公寓', r'住宅', r'residential',
       r'\bbuilding\b', r'\bblock\b', r'楼']
NEG = [r'brush fire', r'wildfire', r'forest fire', r'grass fire', r'wildland', r'vehicle fire',
       r'car fire', r'truck fire', r'motorcycle', r'two-wheeler', r'barn fire', r'field fire',
       r'pleads guilty', r'proposed .* rules', r'\baudit\b', r'conviction', r'investigation into',
       r'launches .* audit', r'\blawsuit\b', r'settlement']
# 非火灾事件: 政策/评论/演练/战争/风水/乱码 (有 fire 词但非真实火灾事件, 不进语料)
NEG_EVENT = [r'限高令', r'预言', r'评论', r'综述', r'宣传', r'工作综述', r'新标准', r'设计新标准',
            r'新规', r'政策', r'policy', r'commentary', r'opinion', r'laws to', r'new law', r'law to',
            r'演练', r'drill', r'training', r'escape plan', r'fire safety (laws|tips|advocates|plan|reminder)',
            r'阳宅', r'风水', r'宅基地', r'发财', r'TRASH', r'Mind Has Been', r'Has Been T',
            r'missile', r'drone attack', r'airstrike', r'shelling', r'Russian strike', r'strike on', r'\bwar\b',
            r'遭殃', r'导弹', r'攻击', r'attack']
# 严格火灾词: fire 排除 fired/firewall/firearm/firework/fireplace 等; 必须真有火灾语境
FIRE_POS = [r'blaze', r'inferno', r'conflagration', r'起火', r'失火', r'着火', r'火灾', r'火势',
            r'arson', r'纵火', r'firefighter', r'消防员', r'evacuat', r'逃生', r'flame',
            r'fire(?!d|wall|arm|work|place|pit|fight|fly|wood|proof|power|fighter|fight)',
            r'\bsmoke\b', r'烟']

VG = {'视障': [r'blind', r'visually impaired', r'视力', r'视障', r'盲人'],
       '听障': [r'\bdeaf\b', r'hearing impaired', r'听障', r'聋'],
       '儿童': [r'\bchild', r'children', r'kid', r'学生', r'婴儿', r'infant', r'\bbaby\b', r'儿童', r'幼儿园', r'小学'],
       '老年': [r'elder', r'elderly', r'老人', r'senior', r'aged', r'退休', r'老年', r'八旬', r'九旬'],
       '轮椅': [r'wheelchair'],
       '拄拐': [r'cane', r'crutch', r'拐杖', r'拄拐'],
       '孕妇': [r'pregnant', r'孕妇'],
       '残疾': [r'disab', r'残疾']}
SCARCE = {'视障', '听障', '轮椅', '拄拐', '孕妇', '残疾'}
SENS = {'楼梯': [r'stair', r'楼梯'], '电梯': [r'elevator', r'lift', r'电梯'], '烟': [r'\bsmoke\b', r'烟'],
        '警报': [r'alarm', r'警报', r'警铃'], '逃生': [r'escap', r'evacuat', r'逃生', r'撤离'],
        '救援': [r'rescu', r'救援'], '烧伤': [r'burn', r'烧伤'], '窗': [r'window', r'窗'],
        '阳台': [r'balcon', r'阳台'], '走廊': [r'corridor', r'hallway', r'走廊'],
        '消防员': [r'firefighter', r'消防员']}

def classify_fire(t, b):
    tb = (t + ' ' + b).lower()
    if any(re.search(p, tb) for p in NOISE): return '非火灾噪声'
    if any(re.search(p, tb) for p in NEG): return '非建筑火灾'
    if any(re.search(p, tb) for p in NEG_EVENT): return '非火灾事件'
    if any(re.search(p, tb) for p in FIRE_POS): return '火灾相关'
    return '未知'

def classify_hi(t, b):
    tb = (t + ' ' + b[:400]).lower()
    if any(re.search(p, tb) for p in NOISE): return '噪声'
    if any(re.search(p, tb) for p in NEG): return '非建筑/非事件'
    if any(re.search(p, tb) for p in ANCHOR_HI): return '高层'
    hi = False
    for p in HIGH:
        m = re.search(p, tb)
        if m:
            num = re.search(r'(\d{1,2})', m.group(0))
            if num and int(num.group(1)) >= 5: hi = True; break
            if p in (r'high[-\s]?rise', r'skyscraper', r'高层', r'高楼', r'大厦', r'塔楼', r'宏福苑',
                     r'格伦费尔', r'grenfell', r'明尚', r'伦敦大火', r'公寓楼', r'住宅楼', r'小区', r'苑', r'hochhaus'):
                hi = True; break
            if p == r'\btower\b' and re.search(r'residential|apartment|building|住房|公寓', tb): hi = True; break
    low = any(re.search(p, t.lower()) for p in LOW_T)
    if low and not hi: return '明确非高层'
    if hi: return '高层'
    if any(re.search(p, tb) for p in APT): return '多层公寓'
    return '未知'

def scan_groups(t, b):
    tb = (t + ' ' + b).lower()
    return [g for g, kws in VG.items() if any(re.search(k, tb) for k in kws)]

def scan_sens(t, b):
    tb = (t + ' ' + b).lower()
    return [g for g, kws in SENS.items() if any(re.search(k, tb) for k in kws)]

def value_score(hi, groups, sens):
    s = 0
    if hi == '高层': s += 3
    elif hi == '多层公寓': s += 2
    elif hi == '未知': s += 1
    for g in groups:
        s += 3 if g in SCARCE else 1
    if len(sens) >= 4: s += 2
    elif len(sens) >= 2: s += 1
    return s

# ---------- 字段定义 (供检查点与写出共用) ----------
FIELDS = ['gid', '标题', 'grok判定', 'fire_rel', 'high_rise', 'vulnerable', 'embodied',
          'value_score', 'in_1446', 'in_final', '参考persona(8180)', '正文(前200)']

# ---------- 加载 ----------
# 终稿标题集合 (含已删备份)
fin_titles = set()
with open(f"{ROOT}/_保留集_FINAL_完整版.csv", encoding='utf-8-sig', newline='') as fh:
    for row in csv.DictReader(fh):
        t = norm_title(row.get('标题'))
        if t: fin_titles.add(t)
try:
    bak = json.load(open(f"{ROOT}/_deleted_noise_backup.json", encoding='utf-8'))
    for rec in bak.get('records', []):
        t = norm_title(rec.get('fields', {}).get('标题'))
        if t: fin_titles.add(t)
except Exception: pass

# 1446 gids
gids_1446 = set()
with open(f"{ROOT}/_全量_路由表_K_最终.csv", encoding='utf-8-sig', newline='') as fh:
    for row in csv.DictReader(fh):
        g = (row.get('gid') or '').strip()
        if g: gids_1446.add(g)

# 8180 persona 参考 (title->persona)
persona_map = {}
with open(f"{ROOT}/第三轮_含正文_筛选草稿.csv", encoding='utf-8-sig', newline='') as fh:
    r = csv.reader(fh); H = [c.strip() for c in next(r)]
    ci_t = H.index('核心事件'); ci_p = H.index('round2_persona')
    for row in r:
        if ci_t < len(row) and ci_p < len(row):
            persona_map[norm_title(row[ci_t])] = (row[ci_p] or '').strip()

# 6666 主数据
with open(f"{ROOT}/_全量_grok判定.csv", encoding='utf-8-sig', newline='') as fh:
    r = csv.reader(fh); H6 = [c.strip() for c in next(r)]; ROWS6 = list(r)
gi = H6.index('gid'); gt = H6.index('标题'); gj = H6.index('grok判定'); gb = H6.index('正文(前2000)')

leak, add, full1446 = [], [], []
in_1446_total = in_final_total = 0
processed = 0

def flush_checkpoint():
    """定时落盘: 把已收集的部分结果写到检查点文件, 崩了也不丢"""
    try:
        cp = [('leak', leak, FIELDS), ('add', add, FIELDS)]
        for name, rows, flds in cp:
            with open(f"{ROOT}/_rescreen_checkpoint_{name}.csv", 'w', encoding='utf-8-sig', newline='') as fh:
                w = csv.DictWriter(fh, fieldnames=flds); w.writeheader()
                for d in rows: w.writerow(d)
        # full1446 单独存(含 建议标签 字段前体)
        with open(f"{ROOT}/_rescreen_checkpoint_full1446.csv", 'w', encoding='utf-8-sig', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDS + ['_partial']); w.writeheader()
            for d in full1446: w.writerow(d)
    except Exception as e:
        print("  [checkpoint warn]", e)

for row in ROWS6:
    gid = (row[gi] if gi < len(row) else '').strip()
    title = (row[gt] if gt < len(row) else '')
    body = (row[gb] if gb < len(row) else '')
    in_1446 = gid in gids_1446
    nt = norm_title(title)
    in_final = nt in fin_titles
    if in_1446: in_1446_total += 1
    if in_final: in_final_total += 1
    fire = classify_fire(title, body)
    hi = classify_hi(title, body)
    if fire == '非火灾事件':
        hi = '非事件'
    groups = scan_groups(title, body)
    sens = scan_sens(title, body)
    sc = value_score(hi, groups, sens)
    ref_persona = persona_map.get(nt, '')
    rec = {'gid': gid, '标题': title[:78], 'grok判定': (row[gj] if gj < len(row) else '').strip(),
           'fire_rel': fire, 'high_rise': hi, 'vulnerable': '+'.join(groups) if groups else '',
           'embodied': '+'.join(sens) if sens else '', 'value_score': sc,
           'in_1446': '是' if in_1446 else '否', 'in_final': '是' if in_final else '否',
           '参考persona(8180)': ref_persona, '正文(前200)': body[:200].replace('\n', ' ')}

    # ① 漏网: 6666内、1446外、火灾相关、高层/多层、高价值、未进终稿
    if (not in_1446) and fire == '火灾相关' and hi in ('高层', '多层公寓') and sc >= 4 and not in_final:
        leak.append(rec)
    # ② 补回: 1446内、终稿外、火灾相关、高层/多层、高价值
    if in_1446 and (not in_final) and fire == '火灾相关' and hi in ('高层', '多层公寓') and sc >= 4:
        add.append(rec)
    if in_1446:
        full1446.append(rec)

    processed += 1
    if processed % 1500 == 0:
        print(f"  [checkpoint] 已处理 {processed}/{len(ROWS6)} 条 -> 漏网{len(leak)} 补回{len(add)}")
        flush_checkpoint()

# 排序: 稀缺群体优先, 分数降序
def rank(d):
    scarce = 1 if any(g in SCARCE for g in (d['vulnerable'].split('+') if d['vulnerable'] else [])) else 0
    return (scarce, d['value_score'])
leak.sort(key=rank, reverse=True)
add.sort(key=rank, reverse=True)
full1446.sort(key=lambda d: (0 if d['fire_rel'] == '火灾相关' else 1, -d['value_score']))

# ---------- 先写出 leak/add (此时 dict 尚未加 建议标签, 避免字段污染) ----------
def write_csv(path, rows, fields):
    with open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields); w.writeheader()
        for d in rows: w.writerow(d)

FIELDS = ['gid', '标题', 'grok判定', 'fire_rel', 'high_rise', 'vulnerable', 'embodied',
          'value_score', 'in_1446', 'in_final', '参考persona(8180)', '正文(前200)']
write_csv(f"{ROOT}/_rescreen_6666_leak.csv", leak, FIELDS)
write_csv(f"{ROOT}/_rescreen_1446_add.csv", add, FIELDS)
flush_checkpoint()  # 终版落盘检查点

# 建议标签 (1446填充用)
def recommend(d):
    if d['in_final'] == '是': return '已在终稿'
    if d['fire_rel'] in ('非火灾噪声', '非建筑火灾'): return '排除(0)'
    if d['high_rise'] == '明确非高层': return '排除(0)'
    if d['fire_rel'] == '火灾相关' and d['high_rise'] in ('高层', '多层公寓') and d['value_score'] >= 4:
        return '建议保留(1)'
    if d['fire_rel'] == '火灾相关' and d['high_rise'] in ('高层', '多层公寓'): return '待定'
    return '待定'
for d in full1446:
    d['建议标签'] = recommend(d)

FULL_FIELDS = ['gid', '标题', 'grok判定', 'fire_rel', 'high_rise', 'vulnerable', 'embodied',
               'value_score', 'in_1446', 'in_final', '建议标签', '参考persona(8180)', '正文(前200)']
write_csv(f"{ROOT}/_rescreen_1446_full.csv", full1446, FULL_FIELDS)

# ---------- 汇总 ----------
print("6666 总:", len(ROWS6))
print("  ├ 在1446内:", in_1446_total, " | 在终稿113内:", in_final_total)
print("  └ 6666−1446 (丢弃层) =", len(ROWS6) - in_1446_total)
print("\n>>> ① 漏网 (丢弃层5220内, 高层火灾+高价值, 可还原):", len(leak), "条")
print(">>> ② 补回 (1446内, 终稿外, 高层火灾+高价值):", len(add), "条")
print("\n--- ① 漏网 TOP20 (稀缺群体优先) ---")
for d in leak[:20]:
    print(f"  [VR{d['value_score']}|{d['high_rise']}|{d['vulnerable'] or '-'}] {d['标题'][:50]} | gid={d['gid']}")
print("\n--- ② 补回 TOP20 ---")
for d in add[:20]:
    print(f"  [VR{d['value_score']}|{d['high_rise']}|{d['vulnerable'] or '-'}] {d['标题'][:50]} | gid={d['gid']}")

# 漏网按高价值分量分布
from collections import Counter
leak_scarce = sum(1 for d in leak if any(g in SCARCE for g in (d['vulnerable'].split('+') if d['vulnerable'] else [])))
print(f"\n① 漏网中 含稀缺群体(视障/听障/轮椅/拄拐/孕妇/残疾): {leak_scarce} 条")
print("-> _rescreen_6666_leak.csv / _rescreen_1446_add.csv / _rescreen_1446_full.csv")

