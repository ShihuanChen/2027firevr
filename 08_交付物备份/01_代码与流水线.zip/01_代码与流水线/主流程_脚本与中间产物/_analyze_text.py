﻿import os
import csv, json, sys, re
csv.field_size_limit(sys.maxsize)

ROOT = os.path.dirname(os.path.abspath(__file__))

# ---- 1. load retention ----
d = json.load(open(ROOT+"/_ret_full.json", encoding="utf-8"))
data = d["data"]
fids = data["field_id_list"]          # ['fldH1vlIFW','fldwH2oS4G','fldSRYle0E','fldFZx3y83']
fnames = data["fields"]                # ['编号','原始URL','正文/摘要','正文长度']
recs = data["data"]
ret = []
for rec in recs:
    item = {fnames[i]: (rec[i] if i < len(rec) else None) for i in range(len(fnames))}
    ret.append(item)
print("retention records:", len(ret))
# diagnostic on raw
url_nonnull = sum(1 for it in ret if (it.get("原始URL") or "").strip())
trunc = 0
for it in ret:
    cur = (it.get("正文/摘要") or "").strip()
    try: L = int(float(it.get("正文长度") or 0))
    except: L = 0
    if L and len(cur) < L - 50:
        trunc += 1
print("原始URL non-null:", url_nonnull, "/", len(ret))
print("正文/摘要 shorter than 正文长度-50 (likely truncated):", trunc)


def norm_url(u):
    if not u: return ""
    u = u.strip().lower()
    u = re.sub(r"^https?://", "", u)
    u = re.sub(r"^www\.", "", u)
    u = u.split("#")[0].split("?")[0].rstrip("/")
    return u

def norm_title(t):
    if not t: return ""
    return re.sub(r"\s+", " ", t.strip().lower())[:80]

# ---- 2. source maps ----
src = {}  # norm_url -> full text
src_title = {}  # norm_title -> full text

def add_source(path, url_col, text_col, title_col=None):
    n=0; added=0
    with open(path, encoding="utf-8-sig") as fh:
        r = csv.reader(fh); hdr = next(r)
        ui = hdr.index(url_col) if url_col in hdr else None
        ti = hdr.index(text_col)
        tii = hdr.index(title_col) if (title_col and title_col in hdr) else None
        for row in r:
            if len(row) <= max(ti, ui or 0): continue
            txt = row[ti].strip()
            if not txt: continue
            n+=1
            if ui is not None:
                nu = norm_url(row[ui])
                if nu and nu not in src:
                    src[nu] = txt; added+=1
            if tii is not None:
                nt = norm_title(row[tii])
                if nt and nt not in src_title:
                    src_title[nt] = txt
    print(f"  {path}: rows={n} url_added={added} src_size={len(src)}")

print("Building source maps...")
add_source(ROOT+"/第三轮_含正文_筛选草稿.csv", "原始报道链接", "文本", None)
add_source(ROOT+"/../../data/高层火灾新闻收集.csv", "URL", "新闻正文", "标题")
# GDELT content where available (also key by title)
add_source(ROOT+"/../../data/高层火灾新闻总表_20260701.csv", "url", "content", "title")

# ---- 2b. supplementary corpus md ----
md_map = {}  # bianhao-label -> full section text
import re as _re
md_path = ROOT+"/../../docs/补充语料_高价值报道.md"
try:
    lines = open(md_path, encoding="utf-8").read().split("\n")
    cur=None; buf=[]
    for ln in lines:
        m = _re.match(r"^###\s+(.*)$", ln)
        if m:
            if cur is not None:
                md_map[cur.strip()] = "\n".join(buf).strip()
            cur = m.group(1).strip()
            buf=[]
        elif cur is not None:
            buf.append(ln)
    if cur is not None:
        md_map[cur.strip()] = "\n".join(buf).strip()
    print(f"  md supplementary sections: {len(md_map)}")
except Exception as e:
    print("  md parse err:", e)


# ---- 3. analyze ----
matched_url=0; matched_title=0; current_empty=0; current_short=0; would_update=0; no_src=0
samples=[]
for it in ret:
    bianhao = it.get("编号") or ""
    url = it.get("原始URL") or ""
    cur = it.get("正文/摘要") or ""
    nu = norm_url(url)
    nt = norm_title(bianhao)
    full = src.get(nu) or src_title.get(nt) or md_map.get((bianhao or "").strip())
    if not cur.strip():
        current_empty += 1
    # heuristic truncation: not ending in terminal punctuation and length>50
    if len(cur.strip())>0 and len(cur.strip())<60:
        current_short += 1
    if full:
        if nu in src or (nu and src.get(nu)):
            matched_url += 1
        elif nt in src_title:
            matched_title += 1
        if len(full) > len(cur.strip())+50:
            would_update += 1
            if len(samples)<5:
                samples.append((bianhao[:40], len(cur), len(full), cur[-40:]))
    else:
        no_src += 1

print(f"\n--- ANALYSIS ---")
print(f"retention total           : {len(ret)}")
print(f"current 正文/摘要 empty   : {current_empty}")
print(f"current 正文/摘要 <60 chars: {current_short}")
print(f"matched by URL            : {matched_url}")
print(f"matched by TITLE          : {matched_title}")
print(f"would UPDATE (full>cur+50): {would_update}")
print(f"NO source found           : {no_src}")
print("\n--- samples (bianhao, cur_len, full_len, cur_tail) ---")
for s in samples: print(s)

# ---- 4. deep dive on no-source ----
print("\n--- NO-SOURCE records (bianhao | cur_len | 正文长度) ---")
ns=0
for it in ret:
    bianhao = (it.get("编号") or "").strip()
    url = (it.get("原始URL") or "").strip()
    cur = (it.get("正文/摘要") or "").strip()
    nu = norm_url(url); nt = norm_title(bianhao)
    full = src.get(nu) or src_title.get(nt)
    if not full:
        try: L = int(float(it.get("正文长度") or 0))
        except: L = 0
        ns+=1
        flag = "TRUNC" if (L and len(cur) < L-50) else "maybe-ok"
        if ns<=40:
            print(f"  [{flag}] cur={len(cur)} L={L} | {bianhao[:55]}")
print("total no-source:", ns)




