﻿import os
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
② 1446 内部、终稿外、高价值候选 -> qwen3.5-flash 语义复核 (Y/N + 理由)
复用 _s9_review_qwen.py 的接口(packyapi.ai / qwen3.5-flash), 串行+断点续传+重试。
候选来源: _rescreen_1446_full.csv 中 fire_rel∈(火灾相关,火灾相关(混合)) 且 high_rise∈(高层,多层公寓)
          且 in_final!=是 且 value_score>=阈值(默认4)。正文按 gid 从 _全量_grok判定.csv 取前2000字。
用法: python _qwen_review_1446.py [阈值]   # 阈值默认4; 用3则覆盖全部161条高价值候选
输出: _qwen_1446_review.csv (含 正则标签 + qwen判定 + 理由)
"""
import csv, sys, os, time, json, re
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.stdout.reconfigure(encoding='utf-8')

import urllib.request, urllib.error
BASE_URL = "https://www.packyapi.ai/v1"
API_KEY = "sk-Ce0ocw6NDUyIzL3MmNpq9ABQiISH3bmyUIm6IRim5EknHsRw"
MODEL = "qwen3.5-flash"
MAX_TOKENS = 300
BATCH = 25
OUT_FILE = '_qwen_1446_review.csv'
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

PROMPT = """你是新闻语料筛选器。判断这篇报道是否值得保留为 VR 高层火灾场景重建素材。

【保留标准（满足任一即 Y）】
I1 具身场景细节：正文含可被 VR 重建的空间/环境描写（楼梯、走廊、窗户、阳台、电梯、脚手架、浓烟、火焰蔓延、高温、能见度变化、逃生动作等）
I2 人物叙事：正文含具体人物的逃生/救援经历（谁在什么位置、做了什么动作：爬/跳/逃/被救/呼救、有何感受）
且事件应为高层建筑（高层公寓/住宅楼/塔楼）相关的真实火灾或火灾安全事件。

【排除标准（仅标题级判断）】
只有标题本身是纯伤亡通报/官方声明/纪念哀悼/法律进展/简报/政策评论时才判 N。
注意：正文中出现 "officials said"、"memorial"、Grenfell 纪念等词是新闻常态，不作为 N 的依据！只要正文有具身细节或人物叙事就判 Y。
若正文主要是政策/风水/战争/枪击/演练而非高层火灾场景，判 N。

输出格式（严格）：
判定: Y 或 N
理由: 一句话说明依据"""

def call_qwen(title, body, retries=5):
    text = f"标题：{title}\n正文：{body}"
    payload = {"model": MODEL, "messages": [
        {"role": "system", "content": PROMPT},
        {"role": "user", "content": text}],
        "max_tokens": MAX_TOKENS, "temperature": 0.0}
    for attempt in range(retries):
        try:
            req = urllib.request.Request(BASE_URL + "/chat/completions",
                data=json.dumps(payload).encode('utf-8'),
                headers={"Content-Type": "application/json", "Authorization": "Bearer " + API_KEY,
                         "User-Agent": UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=90) as resp:
                data = json.loads(resp.read().decode('utf-8'))
            return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            if e.code in (429, 503) and attempt < retries - 1:
                time.sleep(5 + attempt * 5); continue
            return f'__HTTP_{e.code}__'
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(3); continue
            return f'__ERR_{type(e).__name__}__'

def parse(content):
    if content.startswith('__'):
        return 'E', content
    if '<think>' in content:
        content = content.split('</think>')[-1]
    m = re.search(r'判定\s*[:：]\s*(Y|N|y|n)', content)
    verdict = m.group(1).upper() if m else 'E'
    r = re.search(r'理由\s*[:：]\s*(.+)', content, re.S)
    reason = r.group(1).strip()[:150] if r else ''
    return verdict, reason

def main(threshold=4):
    # 6666 正文 by gid
    body_map = {}
    with open(f"{ROOT}/_全量_grok判定.csv", encoding='utf-8-sig', newline='') as fh:
        r = csv.reader(fh); H = [c.strip() for c in next(r)]
        gi = H.index('gid'); gt = H.index('标题'); gb = H.index('正文(前2000)')
        for row in r:
            if gi < len(row):
                body_map[(row[gi] or '').strip()] = (row[gt] if gt < len(row) else '',
                                                      row[gb] if gb < len(row) else '')
    # 1446 候选
    cand = []
    with open(f"{ROOT}/_rescreen_1446_full.csv", encoding='utf-8-sig', newline='') as fh:
        for row in csv.DictReader(fh):
            if row.get('in_final') == '是': continue
            if row.get('fire_rel') not in ('火灾相关', '火灾相关(混合)'): continue
            if row.get('high_rise') not in ('高层', '多层公寓'): continue
            try: vs = int(row.get('value_score') or 0)
            except: vs = 0
            if vs < threshold: continue
            cand.append(row)
    print(f"候选(1446内/终稿外/火灾相关/高层或多层/value>={threshold}): {len(cand)} 条", flush=True)

    # 断点续传
    done = {}
    if os.path.exists(OUT_FILE):
        with open(OUT_FILE, encoding='utf-8-sig', newline='') as fh:
            for row in csv.DictReader(fh):
                done[row['gid']] = row
        print(f"断点续传: 已有 {len(done)} 条", flush=True)
    remaining = [c for c in cand if c['gid'] not in done]
    print(f"待处理: {len(remaining)} 条", flush=True)

    out_rows = list(done.values())
    t0 = time.time()
    for i, c in enumerate(remaining, 1):
        gid = c['gid']
        title, body = body_map.get(gid, (c.get('标题', ''), ''))
        body = (body or '')[:2000]
        content = call_qwen(title, body)
        if content.startswith('__'):
            time.sleep(4)
            content = call_qwen(title, body)
        verdict, reason = parse(content)
        out_rows.append({'gid': gid, '标题': c.get('标题', '')[:78],
                         '正则_fire_rel': c.get('fire_rel', ''), '正则_high_rise': c.get('high_rise', ''),
                         '正则_vulnerable': c.get('vulnerable', ''), '正则_value': c.get('value_score', ''),
                         'qwen判定': verdict, 'qwen理由': reason})
        if i % BATCH == 0:
            pd_write(out_rows)
            print(f"  {i}/{len(remaining)} 完成, 耗时 {time.time()-t0:.0f}s", flush=True)
    pd_write(out_rows)
    print("\n=== 完成 ===", flush=True)
    ys = sum(1 for r in out_rows if r['qwen判定'] == 'Y')
    ns = sum(1 for r in out_rows if r['qwen判定'] == 'N')
    es = sum(1 for r in out_rows if r['qwen判定'] == 'E')
    print(f"Y(建议保留): {ys} | N(排除): {ns} | E(错误): {es}", flush=True)
    print("-> _qwen_1446_review.csv", flush=True)

def pd_write(rows):
    flds = ['gid', '标题', '正则_fire_rel', '正则_high_rise', '正则_vulnerable', '正则_value', 'qwen判定', 'qwen理由']
    with open(f"{ROOT}/{OUT_FILE}", 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=flds); w.writeheader()
        for d in rows: w.writerow(d)

if __name__ == '__main__':
    th = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    main(th)

