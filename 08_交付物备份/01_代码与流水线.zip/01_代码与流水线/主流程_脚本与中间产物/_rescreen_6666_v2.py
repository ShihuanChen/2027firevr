﻿import os
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重筛 6666 丢弃层 (① 6666内/1446外) — 升级版: 正反证据权衡 (mashup-tolerant 但严谨)
设计动机: 抓取常把多篇揉进一条记录, 旧版"第一条命中即停"的硬级联会把混在一起的高价值火灾误杀;
          但无脑"有强火词就保留"又会把战争/枪击/风水文(正文里提了 firefighters)放进来。
本版平衡: 纯噪声事件(无核心火灾词)直接排除; 单弱词需高层/具身语境; 真火+混合噪声才标(混合)保留。
连接键: gid (1446 ⊆ 6666); 终稿用归一化标题 join。
可复现: python _rescreen_6666_v2.py
"""
import csv, sys, re, json
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))

def norm_title(t):
    t = (t or '').lower()
    t = re.sub(r'[^a-z0-9一-鿿]+', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()

# ---------- 规则常量 (重组: 区分 核心火灾词 / 弱词 / 暴力噪声 / 非事件 / 非建筑火 / 其他噪声) ----------
ANCHOR_HI = {'宏福苑','格伦费尔','grenfell','明尚','伦敦大火','香港','hochhaus','olympic tower','bronx'}
HIGH = [r'high[-\s]?rise', r'skyscraper', r'\btower\b', r'高层', r'高楼', r'大厦', r'塔楼', r'宏福苑',
        r'格伦费尔', r'grenfell', r'明尚', r'伦敦大火', r'公寓楼', r'住宅楼', r'小区', r'苑', r'hochhaus',
        r'\b\d{1,2}(st|nd|rd|th)?\s*floor\b', r'第\s*\d+\s*层',
        r'\d{1,2}[-\s]?story', r'\d{1,2}[-\s]?storey', r'\d+\s*层']
STRONG_HIGH = {r'high[-\s]?rise', r'skyscraper', r'高层', r'高楼', r'大厦', r'塔楼', r'宏福苑',
               r'格伦费尔', r'grenfell', r'明尚', r'伦敦大火', r'公寓楼', r'住宅楼', r'小区', r'苑', r'hochhaus'}
LOW_T = [r'\bhouse\b', r'bungalow', r'single-?family', r'self-?built', r'自建房', r'民房', r'平房', r'cottage',
         r'\bvilla', r'独栋', r'房子', r'\bshop\b', r'store', r'铺面', r'商铺', r'五金店', r'church',
         r'cathedral', r'教堂', r'mosque', r'temple', r'寺庙', r'warehouse', r'仓库', r'factory',
         r'\bschool\b', r'学校', r'market', r'市场', r'slum', r'jhuggi', r'窝棚', r'帐篷']
APT = [r'apartment', r'condo', r'condominium', r'\bflat\b', r'公寓', r'住宅', r'residential',
       r'\bbuilding\b', r'\bblock\b', r'楼']

# 核心火灾词(明确事件): 一旦出现即认定为真实火灾语境(强证据)
CORE_FIRE_EVENT = [r'起火', r'失火', r'着火', r'blaze', r'inferno', r'conflagration',
                   r'arson', r'纵火', r'firefighter', r'消防员']
# 弱核心词: "火灾" 一词多义(防火/火灾风险/风水语境), 不可单独定罪
CORE_FIRE_WEAK = [r'火灾']
# 弱火灾词: 需结合语境/数量权衡, 不可单独定罪
FIRE_WEAK = [r'evacuat', r'逃生', r'flame', r'\bsmoke\b', r'烟',
             r'fire(?!d|wall|arm|work|place|pit|fight|fly|wood|proof|power|fighter|fight)']
# 标题级乱码/无意义(直接排除, 不救): 含连续间隔单字母(如 "T - R - A - S - H") 或已知垃圾串
GARBLED_TITLE = [r'TRASH', r'Mind Has Been', r'Has Been T',
                 r'[A-Za-z]\s*[-–]\s*[A-Za-z](\s*[-–]\s*[A-Za-z]){3,}']
# 非火灾框架(政策/风水/预言/限高/地震): 仅"火灾"弱词时不算火
NONFIRE_FRAME = [r'限高令', r'预言', r'评论', r'综述', r'宣传', r'工作综述', r'新标准', r'设计新标准',
                 r'新规', r'政策', r'policy', r'commentary', r'opinion', r'laws to', r'new law', r'law to',
                 r'阳宅', r'风水', r'宅基地', r'发财', r'地震', r'earthquake', r'避险']
# 暴力/袭击噪声: 枪击/战争/导弹, 即便提了 firefighter 也不算火灾(除非同时有核心火词)
VIOLENCE = [r'gunfire', r'firefight', r'\bshooting\b', r'\bgunman\b', r'mass shooting', r'open fire',
            r'missile', r'drone attack', r'airstrike', r'shelling', r'Russian strike', r'strike on',
            r'\bwar\b', r'遭殃', r'导弹', r'攻击', r'attack']
# 非火灾事件: 政策/评论/演练/风水/地震避险/乱码(有 fire 词但非真实火灾事件)
NEG_EVENT = [r'限高令', r'预言', r'评论', r'综述', r'宣传', r'工作综述', r'新标准', r'设计新标准',
             r'新规', r'政策', r'policy', r'commentary', r'opinion', r'laws to', r'new law', r'law to',
             r'演练', r'drill', r'training', r'escape plan', r'fire safety (laws|tips|advocates|plan|reminder)',
             r'阳宅', r'风水', r'宅基地', r'发财', r'TRASH', r'Mind Has Been', r'Has Been T',
             r'地震', r'earthquake', r'避险']
# 非建筑火灾: 野火/车祸火/法律进展
NEG = [r'brush fire', r'wildfire', r'forest fire', r'grass fire', r'wildland', r'vehicle fire',
       r'car fire', r'truck fire', r'motorcycle', r'two-wheeler', r'barn fire', r'field fire',
       r'pleads guilty', r'proposed .* rules', r'\baudit\b', r'conviction', r'investigation into',
       r'launches .* audit', r'\blawsuit\b', r'settlement']
# 其他噪声: 与火灾无关的蹭词/误触发
NOISE_OTHER = [r'firewood rack', r'fire truck shortage', r'\battorney\b', r'lawyer', r'ben crump',
               r'setting your design ablaze', r'voice to the voiceless', r'burnout', r'deepfake',
               r'photographs that defined', r'best .* rack', r'recipe', r'\bdiy\b']

VG = {'视障': [r'blind', r'visually impaired', r'视力', r'视障', r'盲人'],
       '听障': [r'\bdeaf\b', r'hearing impaired', r'听障', r'聋'],
       '儿童': [r'\bchild', r'children', r'kid', r'学生', r'婴儿', r'infant', r'\bbaby\b', r'儿童', r'幼儿园', r'小学'],
       '老年': [r'elder', r'elderly', r'老人', r'senior', r'aged', r'退休', r'老年', r'八旬', r'九旬'],
       '轮椅': [r'wheelchair'],
       '拄拐': [r'cane', r'crutch', r'拐杖', r'拄拐'],
       '孕妇': [r'pregnant', r'孕妇'],
       '残疾': [r'disab', r'残疾']}
SCARCE = {'视障', '听障', '轮椅', '拄拐', '孕妇', '残疾'}
SENS = {'楼梯': [r'stair', r'楼梯'], '电梯': [r'elevator', r'lift', r'电梯'], '烟': [r'\bsmoke\b', r'烟'],
        '警报': [r'alarm', r'警报', r'警铃'], '逃生': [r'escap', r'evacuat', r'逃生', r'撤离'],
        '救援': [r'rescu', r'救援'], '烧伤': [r'burn', r'烧伤'], '窗': [r'window', r'窗'],
        '阳台': [r'balcon', r'阳台'], '走廊': [r'corridor', r'hallway', r'走廊'],
        '消防员': [r'firefighter', r'消防员']}

def classify_fire_v2(t, b):
    """正反证据权衡, 返回 (标签, 正词列表, 负词列表)"""
    tl = (t or '').lower()
    tb = (tl + ' ' + b).lower()
    # 标题级乱码: 直接排除
    if any(re.search(p, tl) for p in GARBLED_TITLE):
        return ('非火灾噪声', [], ['乱码标题'])
    core_event = [p for p in CORE_FIRE_EVENT if re.search(p, tb)]
    core_weak = [p for p in CORE_FIRE_WEAK if re.search(p, tb)]   # 仅 "火灾"
    core = core_event + core_weak
    weak = [p for p in FIRE_WEAK if re.search(p, tb)]
    violence = [p for p in VIOLENCE if re.search(p, tb)]
    nonevent = [p for p in NEG_EVENT if re.search(p, tb)]
    nonb = [p for p in NEG if re.search(p, tb)]
    other = [p for p in NOISE_OTHER if re.search(p, tb)]
    frame = [p for p in NONFIRE_FRAME if re.search(p, tb)]   # 政策/风水/预言/限高/地震 框架

    # 有"火灾"弱词但处在 战争/非火框架 中 -> 那词是比喻/政策, 不算火
    if core_event:
        # 真火灾事件词出现: 即便混了噪声也保留(混合)
        neg_all = violence + nonevent + nonb + other + frame
        if neg_all:
            return ('火灾相关(混合)', core_event, weak + neg_all)
        return ('火灾相关', core_event, weak)
    if core_weak and (violence or frame):
        # "火灾" 处在战争/风水/限高/预言框架 -> 非火灾事件
        return ('非火灾事件', core_weak, core_weak + violence + frame)
    if core_weak and not (violence or frame or nonevent or nonb or other):
        # 孤立"火灾"词, 无噪声框架: 视作弱火灾, 需语境佐证
        ctx = (classify_hi_v2(t, b) in ('高层', '多层公寓')) or bool(scan_sens(t, b))
        return ('火灾相关', core_weak, weak) if ctx else ('未知', core_weak, weak)

    # 无核心火灾词: 纯噪声事件直接排除, 不给 stray 弱词翻盘机会
    if violence:  return ('非火灾噪声', [], weak + violence)
    if nonevent:  return ('非火灾事件', [], weak + nonevent)
    if frame:     return ('非火灾事件', [], weak + frame)
    if nonb:      return ('非建筑火灾', [], weak + nonb)
    if other:     return ('非火灾噪声', [], weak + other)
    if len(weak) >= 2:
        return ('火灾相关', [], weak)
    if len(weak) == 1:
        ctx = (classify_hi_v2(t, b) in ('高层', '多层公寓')) or bool(scan_sens(t, b))
        return ('火灾相关', [], weak) if ctx else ('未知', [], weak)
    return ('未知', [], weak)

def classify_hi_v2(t, b):
    """高层/低层同现时优先判高层(保住高价值那篇)"""
    tb = (t + ' ' + b[:400]).lower()
    if any(re.search(p, tb) for p in ANCHOR_HI):
        return '高层'
    hi = False
    for p in HIGH:
        m = re.search(p, tb)
        if m:
            num = re.search(r'(\d{1,2})', m.group(0))
            if num and int(num.group(1)) >= 5:
                hi = True; break
            if p in STRONG_HIGH:
                hi = True; break
            if p == r'\btower\b' and re.search(r'residential|apartment|building|住房|公寓', tb):
                hi = True; break
    low = any(re.search(p, t.lower()) for p in LOW_T)
    if hi:
        return '高层'            # 高低同现 -> 保高层
    if low:
        return '明确非高层'
    if any(re.search(p, tb) for p in APT):
        return '多层公寓'
    return '未知'

def scan_groups(t, b):
    tb = (t + ' ' + b).lower()
    return [g for g, kws in VG.items() if any(re.search(k, tb) for k in kws)]

def scan_sens(t, b):
    tb = (t + ' ' + b).lower()
    return [g for g, kws in SENS.items() if any(re.search(k, tb) for k in kws)]

def value_score(hi, groups, sens):
    s = 0
    if hi == '高层': s += 3
    elif hi == '多层公寓': s += 2
    elif hi == '未知': s += 1
    for g in groups:
        s += 3 if g in SCARCE else 1
    if len(sens) >= 4: s += 2
    elif len(sens) >= 2: s += 1
    return s

FIELDS = ['gid', '标题', 'grok判定', 'fire_rel', 'fire_pos', 'fire_neg', 'high_rise',
          'vulnerable', 'embodied', 'value_score', 'in_1446', 'in_final',
          '参考persona(8180)', '正文(前200)']

# ---------- 加载 ----------
fin_titles = set()
with open(f"{ROOT}/_保留集_FINAL_完整版.csv", encoding='utf-8-sig', newline='') as fh:
    for row in csv.DictReader(fh):
        t = norm_title(row.get('标题'))
        if t: fin_titles.add(t)
try:
    bak = json.load(open(f"{ROOT}/_deleted_noise_backup.json", encoding='utf-8'))
    for rec in bak.get('records', []):
        t = norm_title(rec.get('fields', {}).get('标题'))
        if t: fin_titles.add(t)
except Exception: pass

gids_1446 = set()
with open(f"{ROOT}/_全量_路由表_K_最终.csv", encoding='utf-8-sig', newline='') as fh:
    for row in csv.DictReader(fh):
        g = (row.get('gid') or '').strip()
        if g: gids_1446.add(g)

persona_map = {}
with open(f"{ROOT}/第三轮_含正文_筛选草稿.csv", encoding='utf-8-sig', newline='') as fh:
    r = csv.reader(fh); H = [c.strip() for c in next(r)]
    ci_t = H.index('核心事件'); ci_p = H.index('round2_persona')
    for row in r:
        if ci_t < len(row) and ci_p < len(row):
            persona_map[norm_title(row[ci_t])] = (row[ci_p] or '').strip()

with open(f"{ROOT}/_全量_grok判定.csv", encoding='utf-8-sig', newline='') as fh:
    r = csv.reader(fh); H6 = [c.strip() for c in next(r)]; ROWS6 = list(r)
gi = H6.index('gid'); gt = H6.index('标题'); gj = H6.index('grok判定'); gb = H6.index('正文(前2000)')

leak, full1446 = [], []
in_1446_total = in_final_total = 0
processed = 0

def flush_checkpoint():
    try:
        with open(f"{ROOT}/_rescreen_checkpoint_leak_v2.csv", 'w', encoding='utf-8-sig', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDS); w.writeheader()
            for d in leak: w.writerow(d)
        with open(f"{ROOT}/_rescreen_checkpoint_full1446_v2.csv", 'w', encoding='utf-8-sig', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDS); w.writeheader()
            for d in full1446: w.writerow(d)
    except Exception as e:
        print("  [checkpoint warn]", e)

for row in ROWS6:
    gid = (row[gi] if gi < len(row) else '').strip()
    title = (row[gt] if gt < len(row) else '')
    body = (row[gb] if gb < len(row) else '')
    in_1446 = gid in gids_1446
    nt = norm_title(title)
    in_final = nt in fin_titles
    if in_1446: in_1446_total += 1
    if in_final: in_final_total += 1
    fire, pos_hits, neg_hits = classify_fire_v2(title, body)
    hi = classify_hi_v2(title, body)
    groups = scan_groups(title, body)
    sens = scan_sens(title, body)
    sc = value_score(hi, groups, sens)
    ref_persona = persona_map.get(nt, '')
    rec = {'gid': gid, '标题': title[:78], 'grok判定': (row[gj] if gj < len(row) else '').strip(),
           'fire_rel': fire,
           'fire_pos': '|'.join(pos_hits) if pos_hits else '',
           'fire_neg': '|'.join(neg_hits) if neg_hits else '',
           'high_rise': hi, 'vulnerable': '+'.join(groups) if groups else '',
           'embodied': '+'.join(sens) if sens else '', 'value_score': sc,
           'in_1446': '是' if in_1446 else '否', 'in_final': '是' if in_final else '否',
           '参考persona(8180)': ref_persona, '正文(前200)': body[:200].replace('\n', ' ')}

    # ① 漏网: 6666内、1446外、火灾相关(含混合)、高层/多层、高价值、未进终稿
    if (not in_1446) and fire in ('火灾相关', '火灾相关(混合)') and hi in ('高层', '多层公寓') and sc >= 4 and not in_final:
        leak.append(rec)
    if in_1446:
        full1446.append(rec)

    processed += 1
    if processed % 1500 == 0:
        print(f"  [checkpoint] 已处理 {processed}/{len(ROWS6)} -> 漏网{len(leak)}")
        flush_checkpoint()

def rank(d):
    # 火灾确信度优先: 干净单篇真火(火灾相关)排前, 混合文(火灾相关(混合))沉底; 同档稀缺群体+分数优先
    conf = 0 if d['fire_rel'] == '火灾相关' else 1
    scarce = 1 if any(g in SCARCE for g in (d['vulnerable'].split('+') if d['vulnerable'] else [])) else 0
    return (conf, -scarce, -d['value_score'])
leak.sort(key=rank)
full1446.sort(key=lambda d: (0 if d['fire_rel'] in ('火灾相关', '火灾相关(混合)') else 1, -d['value_score']))

def write_csv(path, rows):
    with open(path, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS); w.writeheader()
        for d in rows: w.writerow(d)

write_csv(f"{ROOT}/_rescreen_6666_leak_v2.csv", leak)
flush_checkpoint()

print("6666 总:", len(ROWS6))
print("  ├ 在1446内:", in_1446_total, " | 在终稿内:", in_final_total)
print("\n>>> ① 漏网 v2 (丢弃层5220内, 正反权衡, 严谨版):", len(leak), "条")
mixed = sum(1 for d in leak if d['fire_rel'] == '火灾相关(混合)')
print("   其中 混合文(含噪声词但保留):", mixed, "条")
print("\n--- ① 漏网 v2 TOP20 (稀缺群体优先) ---")
for d in leak[:20]:
    tag = '[混合]' if d['fire_rel'] == '火灾相关(混合)' else ''
    print(f"  [VR{d['value_score']}|{d['high_rise']}|{d['vulnerable'] or '-'}]{tag} {d['标题'][:46]} | gid={d['gid']}")
print("\n-> _rescreen_6666_leak_v2.csv")

