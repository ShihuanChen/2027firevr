import json, subprocess, re, sys

BASE = "MBmvbhTH1aYGRzsmFYpcbuU3n6f"
TABLE = "tbljjPOxZdQGDKUc"
LARK = "/c/Users/Administrator/.workbuddy/binaries/node/cli-connector-packages/lark-cli"

FIELDS = ["编号","身体主体","核心冲突","感官主导","交互_交互动词",
          "交互_共情机制","SAVTBC_S空间","SAVTBC_A声音","SAVTBC_V视觉",
          "SAVTBC_B身体","SAVTBC_C社交","伤亡等级","视角","叙事视角",
          "叙事结构","情感标签","VR可模拟性","氛围叙事机制","交互机制"]

def fetch():
    cmd = [LARK,"base","+record-list","--base-token",BASE,"--table-id",TABLE,
           "--as","user","--page-size","200","--format","json",
           "--field-names",",".join(FIELDS)]
    r = subprocess.run(["bash","-lc"," ".join(cmd)], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        print("FETCH ERR:", r.stderr[:500]); sys.exit(1)
    d = json.loads(r.stdout)
    recs = d["data"]["data"]
    # record ids from markdown
    md_cmd = [LARK,"base","+record-list","--base-token",BASE,"--table-id",TABLE,
              "--as","user","--page-size","200","--format","markdown","--field-names","编号"]
    md = subprocess.run(["bash","-lc"," ".join(md_cmd)],
                        capture_output=True, text=True, encoding="utf-8", errors="replace")
    ids = re.findall(r"^\|\s*(rec[a-zA-Z0-9]+)\s*\|", md.stdout, re.M)
    assert len(ids) == len(recs), f"id count {len(ids)} != rec count {len(recs)}"
    return list(zip(ids, recs))

def as_list(v):
    if v is None: return []
    if isinstance(v, list): return [str(x) for x in v]
    return [str(v)]

def as_str(v):
    if v is None: return ""
    if isinstance(v, list): return " ".join(str(x) for x in v)
    return str(v)

BODY_MAP = {
    "老年人步速":"老年人","老年人":"老年人","儿童身体限制":"儿童","儿童":"儿童",
    "轮椅":"轮椅使用者","视障":"视障者","视觉障碍":"视障者","听障":"听障者",
    "拄拐":"拄拐/助行器","助行":"拄拐/助行器","孕妇":"孕妇/抱婴者","宠物":"宠物",
    "救援者":"救援者","残障者":"普通成年人","体力耗尽":"普通成年人",
    "跌倒":"普通成年人","高温/灼热":"普通成年人","烟雾刺激":"普通成年人",
}
def map_body(btext, ctext, existing):
    out = set(existing)
    for k,v in BODY_MAP.items():
        if k in btext or k in ctext:
            out.add(v)
    if not out:
        out.add("普通成年人")
    return sorted(out)

def derive(item):
    rid = item[0]
    rec = item[1]
    bianhao, body_exist, conflict, sense, verbs, emp, S, A, V, B, C, casualty, \
    v_persp, v_stance, v_struct, v_emo, v_vr, v_atmo, v_inter = rec

    bianhao = as_str(bianhao)
    body_exist = as_list(body_exist)
    conflict = as_list(conflict)
    sense = as_list(sense)
    verbs = as_list(verbs)
    emp = as_list(emp)
    S = as_str(S); A = as_str(A); V = as_str(V); B = as_str(B); C = as_str(C)
    casualty = as_str(casualty)
    conflict_s = " ".join(conflict)
    c_s = " ".join([C, B])

    is_supplement = bool(re.match(r"^S\d+", bianhao.strip())) or any(
        k in bianhao for k in ["自述","逃生记","复盘","回顾","亲历","幸存者"])
    memorial_kw = any(k in (bianhao+" "+C) for k in ["memorial","mourn","return to","手印","回顾","之后","纪念"])

    # 视角
    persp = "第一人称" if is_supplement else "第三人称"

    # 叙事视角
    if is_supplement:
        stance = "幸存者第一人称"
    elif ("邻里呼喊" in A) or ("敲门/拍门" in (verbs and " ".join(verbs))) or ("邻里互助" in C):
        stance = "目击者/邻居"
    elif ("救援者" in c_s):
        stance = "救援者"
    elif (casualty in ("死亡","群死群伤","重伤")) and ("家庭单元" in C or "家属" in C or memorial_kw):
        stance = "家属/亲友"
    elif memorial_kw:
        stance = "家属/亲友"
    else:
        stance = "官方/媒体全知"

    # 叙事结构
    spaces = [s.strip() for s in S.split(",") if s.strip()]
    if is_supplement or memorial_kw:
        struct = "倒叙"
    elif len(spaces) >= 3:
        struct = "多线"
    else:
        struct = "线性"

    # 情感标签
    if casualty in ("死亡","群死群伤"):
        emo = "悲伤"
    elif "建筑/设施缺陷" in conflict_s:
        emo = "愤怒"
    elif "信息缺失/警报延迟" in conflict_s:
        emo = "无助"
    elif "逃生vs被困" in conflict_s or "时间压力" in conflict_s:
        emo = "恐惧"
    elif ("身体限制vs环境障碍" in conflict_s) or any(b in B for b in ["步速","身体限制","体力耗尽","跌倒"]):
        emo = "无助"
    elif casualty in ("无伤亡","轻伤"):
        emo = "希望"
    else:
        emo = "恐惧"

    # 身体主体
    body = map_body(B, C, body_exist)

    # 氛围叙事机制
    atmo = set()
    if sense or V:
        atmo.add("环境模拟")
    if (sense and ("听觉" in " ".join(sense))) or A:
        atmo.add("信息呈现")
        atmo.add("多模态感知剥夺")
    if any(s in " ".join(sense) for s in ["触觉/温度","嗅觉暗示","运动/前庭"]):
        atmo.add("多模态感知剥夺")
    atmo.add("V_framing")
    atmo = sorted(atmo)

    # 交互机制
    inter = set()
    if verbs:
        inter.add("E3交互")
    if ("身体限制vs环境障碍" in conflict_s) or any(b in B for b in ["步速","身体限制","体力耗尽","跌倒"]) or any(x in body for x in ["老年人","轮椅使用者","视障者","听障者","拄拐/助行器","孕妇/抱婴者"]):
        inter.add("限制模拟")
    if ("建筑/设施缺陷" in conflict_s) or ("信息缺失/警报延迟" in conflict_s):
        inter.add("V处境困难")
    if "时间压力" in conflict_s:
        inter.add("E6")
    if "自救vs互救" in conflict_s:
        inter.add("E5")
    if not inter:
        inter.add("V处境困难")
    inter = sorted(inter)

    # VR可模拟性
    parts = []
    if spaces:
        parts.append("空间：" + "、".join(spaces))
    if conflict_s:
        parts.append("冲突：" + conflict_s)
    if verbs:
        parts.append("交互：" + "、".join(verbs))
    vr = "；".join(parts) if parts else "高层火灾场景，可程序化还原烟、火、声与受限移动"

    return {
        "视角": persp, "叙事视角": stance, "叙事结构": struct,
        "情感标签": emo, "身体主体": body, "氛围叙事机制": atmo,
        "交互机制": inter, "VR可模拟性": vr
    }

V2_FIELDS = ["视角","叙事视角","叙事结构","情感标签","身体主体",
             "氛围叙事机制","交互机制","VR可模拟性"]

FIELD_IDS = {
    "视角":"fldW2QeZQZ","叙事视角":"fldy6EY7Jy","叙事结构":"fldrGtLJbV",
    "情感标签":"fld6m5uU9x","身体主体":"fldx51C6gl","氛围叙事机制":"fld6HQShGz",
    "交互机制":"fldDtjr1qw","VR可模拟性":"fldazH7sKt",
}

def update_record(rid, labels):
    fields = {}
    for k in V2_FIELDS:
        v = labels[k]
        if isinstance(v, list):
            v = [str(x) for x in v]
        else:
            v = str(v)
        fields[FIELD_IDS[k]] = v
    payload = {"record_id": rid, "fields": fields}
    cmd = [LARK,"base","+record-update","--base-token",BASE,"--table-id",TABLE,
           "--as","user","--json", json.dumps(payload, ensure_ascii=False)]
    r = subprocess.run(["bash","-lc"," ".join(cmd)], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        return f"ERR {r.stderr[:200]}"
    return "ok"

if __name__ == "__main__":
    DRY = "--write" in sys.argv
    try:
        recs = fetch()
    except Exception as e:
        import traceback; traceback.print_exc(); sys.exit(2)
    print(f"total records: {len(recs)}")
    skip = 0; done = 0; errs = []
    for item in recs:
        rid = item[0]
        existing_persp = as_str(item[1][12])  # 视角 is index 12 in FIELDS
        if existing_persp.strip():   # already labeled (e.g. 4 fish)
            skip += 1
            continue
        d = derive(item)
        if not DRY:
            res = update_record(rid, d)
            if res.startswith("ERR"):
                errs.append((rid, res)); done += 1
            else:
                done += 1
        else:
            done += 1
        if done <= 5:
            print(f"\n--- {as_str(item[1][0])[:45]} ---")
            for k,v in d.items():
                print(f"  {k}: {v}")
    print(f"\n{'WRITE' if DRY else 'DRY'} done={done} skip(alreadylabeled)={skip} errs={len(errs)}")
    if errs:
        for r,e in errs[:5]:
            print("  ", r, e)
