<title>身临其境：VR 高层火灾共情系统 —— 以残障人士身份体验真实火灾现场</title>

# Abstract(未）

高层建筑火灾是城市最危险的灾害场景之一：2017 年伦敦 Grenfell Tower 大火 72 人遇难、2025 年香港宏福苑火灾 146 人遇难。遇难者中弱势群体占比偏高，他们在火灾疏散中面临**「信息断裂 × 身体约束 × 环境恶化」**三重困境（详见第 1 节）：听障者依赖邻里而非 85dB 警报获取灾难信息【oecd_dhh_scoping】，轮椅使用者无法通过楼梯【ronchi2013wheelchair】，浓烟 5-8 分钟充满楼梯间。传统消防安全教育以健全人视角设计【shockingrealities2025】，无法传递上述真实体验；现有 VR 共情研究虽证明具身体验能促进观点采择【herrera2018building】，但场景多为设计师想象，缺乏真实灾害语料支撑，尚未系统化地从大规模灾害新闻中提取可重建的具身场景作为 VR 关卡依据。

本文提出并实现了一个 **VR 高层火灾共情系统**：以香港宏福苑等真实火灾为场景原型，让用户以六类残障身份（听障/老年/轮椅/管状视野视障/儿童/拄拐）第一人称体验逃生困境，核心机制是**身体-环境耦合**——同一环境参数在不同残障身份下产生不同的主观体验。系统的场景依据来自人机协作筛选管线：AI 语义过滤（8,180 → 1,027 独立事件）后，人工分两阶段裁决——规则学习阶段保留 31 条、火灾池精判阶段保留 78 条，正式保留合计 109 条具身场景可重建的报道；另有 16 篇人工补充的高价值报道（幸存者自述/证词），共同构成 VR 场景重建素材库，经 SAVTBC 六维编码转译为 VR 关卡参数——这是本文在方法层面的核心贡献（从文本语料到具身场景设计的可迁移路径）。评估遵循 EVRD 框架【evrd2025】：情感共情（IRI）、认知共情（锚定任务）、行为共情（捐助意愿）三维测量，并嵌入 doomed-to-fail 机制促进认知共情。

## Keywords

Virtual Reality; Empathy; Accessibility; Disaster Evacuation; Vulnerable Populations; High-Rise Fire

# 1. Introduction（未)

**问题。**高层建筑火灾是最危险的城市灾害场景之一：2017 年伦敦 Grenfell Tower 大火 72 人遇难、2025 年香港宏福苑火灾 146 人遇难。遇难者中弱势群体占比显著偏高——香港宏福苑火灾的遇难者多为长者。疏散行为学研究表明，他们在火灾疏散中面临**三重困境**：**信息断裂**——听障者收不到 85dB 声学警报，预疏散延迟比健全人多 5-10 分钟【kuligowski_nist】【kshirsagar2025iscram】，且依赖社交网络（邻里/家人）而非官方警报获取灾难信息【oecd_dhh_scoping】；**身体约束**——轮椅使用者完全无法通过楼梯【ronchi2013wheelchair】，老年人疏散步速仅 0.4-0.6 m/s（约健全人一半）【gwynne2016evacuation】，儿童因身高 105cm 在浓烟下沉 120cm 时视野被遮蔽；**环境恶化**——浓烟 5-8 分钟即可充满楼梯间，能见度降至不足一米。三个困境并非独立存在：环境恶化（浓烟、高温）会加剧信息断裂（烟雾使听障者仅有的视觉信号也被剥夺，并使视障者残余视力归零），同时加剧身体约束（高温灼热、呛咳窒息使原本可移动的人也无法行动），形成恶性叠加。这意味着弱势群体在火灾中的劣势不是单一参数的劣化，而是**"身体 × 环境耦合"的乘性效应**。

**为什么 VR。**传统的消防安全教育（紧急标识、消防演习、应急广播、标准疏散路线图）**以健全人视角设计**，无法传递上述真实体验——Shocking Realities（CHI 2025）通过对照实验证实，健全用户在仅听口头描述时对轮椅使用者的可达性问题存在系统性低估，只有当他们亲身"在游戏中自己发现困难"时认知才显著提升【shockingrealities2025】。VR 具身共情已被证明能有效促进观点采择（Herrera & Bailenson，400 人实验）【herrera2018building】与长期行为改变（Ahn & Bailenson 砍树实验）【ahn2013embodied】【ahn2014short】，但现有 VR 共情模拟仍存在两个局限：(1) 场景多为设计师想象，缺乏真实灾害语料支撑——例如 Shocking Realities 的轮椅场景是基于可达性规范而非真实火灾故事；(2) 多聚焦单一障碍类型的抽象任务（如"在黑暗中行走"），未覆盖火灾疏散中"身体 × 环境"的耦合困境，更未触及上述"三重困境的乘性叠加"。

**本文贡献。**(1) **一个 VR 高层火灾共情系统**：以真实火灾（宏福苑/Grenfell/上海静安等）为场景原型，让用户以六类残障身份第一人称体验逃生困境；(2) **"身体 × 环境耦合"共情设计框架**：环境参数 × 障碍模块 → 症状体验的映射机制，配合 doomed-to-fail 设计促进认知共情；(3) **从文本语料到具身场景设计的转化路径**：这一路径目前是文献中被忽视的黑箱——既往 VR 共情工作要么依赖设计师想象【shockingrealities2025】，要么依据从零编写的实验脚本【visualimpairment2025】，缺乏从真实大规模灾害语料中系统化提取可重建场景的方法。我们以人机协作筛选管线（AI 语义过滤 8,180 → 1,027 独立事件，人工分两阶段裁决：规则学习阶段保留 31 条 + 火灾池精判阶段保留 78 条 = 109 条）从 8,180 条高层火灾新闻中筛选出 109 条具备 VR 重建条件的报道，另有 16 篇人工补充高价值报道，再用 SAVTBC 六维编码（空间/声音/视觉/时间/身体/社交）将文本中的具身细节转译为 VR 关卡参数——这一"语料→场景编码→VR 参数"的端到端流程本身构成可迁移的 HCI 方法学工具，填补了"VR 火灾场景缺乏真实依据"的空白，同时也为后续的 VR 共情研究提供了系统化的场景供给路径。

**论文组织。**§2 梳理相关工作的共识与局限；§3 描述系统设计（六角色、身体 × 环境耦合机制、任务树、共情测量）；§4 描述场景依据方法（新闻语料筛选与六维编码转译）；§5 报告筛选结果与场景依据库；§6 讨论设计决策与局限；§7 总结与下一步。

# 2. Related Work

**大纲**

**三个支柱：真实场景（内容）、具身机制（体验）、弱势对象（伦理）**

**2.1 真实场景从哪来/**第一人称经历真实新闻这一范式成立且有效→沉浸式新闻

- 定义→效果→设计框架

场景来自真实火灾报道，必须先证明真实新闻→VR 体验是有价值的

- [ ] 内容供给靠人工精制、成本高 → 引出规模化场景从哪来的问题



· **2.2 沉浸式具身故事体验为什么有效/**身体在场能转化为情感共鸣的机制→具身and共情研究

- 三要素→设计策略→行为证据

核心机制是身体\*环境，必须先有理论证明身体模拟→共情成立

- [ ] 重建需要可重建的具身文本作原料 → 引出什么文本能支撑重建的问题



· **2.3 弱势群体VR-为谁设计、怎么设计才不落入怜悯/**弱势群体 VR 的方法论/理论/设计/伦理约束

必须借鉴已有弱势群体 VR 的方法与伦理边界

- [ ] 已有工作都靠人工设计脚本 → 同样是内容靠人工问题



· **2.4 研究空白**

**缺口**分别对应系统的三个支柱缺什么

- 每条线先讲已有工作做了什么、结论是什么，再指出边界；边界即通向下一条线的理由；统一在 2.4 呼应本文和前文联系



## 初稿

【开头需要介绍结构和逻辑】

**2.1 Immersive Journalism and Narrative VR**

**2.1.1 沉浸式新闻的定义与理论**

沉浸式新闻（Immersive Journalism）的概念由 de la Peña 等人于 2010 年正式提出，定义为"以让人们对新闻故事中的事件或情境获得第一人称体验的形式来生产新闻"【delapena2010immersive】。该定义界定了沉浸式新闻的三个关键特征：非虚构性——内容基于真实新闻事件；第一人称在场——用户以自我为中心的视角存在于虚拟空间中；时间同步性——用户以实时方式经历事件进程而非事后回看。这一定义奠定了沉浸式新闻作为一种新闻呈现范式的基础：受众从信息接收者转变为事件的空间参与者。

然而，仅凭借这一定义和理论描述，尚不足以支撑从大规模灾害新闻文本到 VR 叙事体验的完整转换。如何将新闻正文中包含的具身细节有效地转化为 VR 中可交互的叙事场景，仍是尚未被充分解决的问题。本文关注的核心正在于此：一方面，提供一套从文本到 VR 场景的可执行生成方案；另一方面，探索如何设计有效的叙事与交互机制，使第一人称在场真正转化为情感共鸣。

近年来，沉浸式新闻的共情效果受到持续检验：Sánchez Laws 系统审视了沉浸式新闻对共情的促进作用及其边界【sanchez2020immersive】，Aronson-Rath 等从产业实践角度总结了 VR 新闻生产的挑战与机遇【aronson2023immersive】。这些工作共同表明：沉浸式新闻的核心价值在于"第一人称在场"，但其效果高度依赖叙事设计与交互机制，而非沉浸技术本身。



**2.1.2 效果检验：从"默认共情"到"可设计的共情"**

在效果检验方向，Feeling the News? 的对照实验提出了一个与"第一人称新闻"理想形成对照的发现。实验数据显示，被动观看 360° 视频在情感参与度上显著低于主动交互式 VR 体验；叙事结构（线性 vs. 分支）对受众的认知共情也有显著影响，分支叙事组在事后测试中对新闻事件细节的回忆更准确。作者的结论是："Immersive journalism (IJ) is often assumed to be inherently emotion-inducing... the audience responses depend on interaction and narrative design"【feelingnews2023】。上述结果表明，沉浸本身只是内容传输的媒介条件，受众的情感反应取决于可被调控的叙事编排与交互机制设计。

Herrera 和 Bailenson 的大规模实验（超过 400 名参与者）从另一个角度支持了这一观点。他们比较了传统视角转换任务和 VR 视角转换对长期共情的影响，发现 VR 组在观点采择上的提升显著高于传统组，且效应在一周后仍可测量【herrera2018building】。这说明沉浸式环境下的共情效应并非自然发生，而是需要经过精心设计才能产生可测量的持久影响。



**2.1.3 设计框架与产业落地**

上述发现自然引出一个问题：**如何构造有效的叙事和交互机制以达到情绪激发的效果？**近年来，多个研究从不同层面回应了这一问题。在评估层面，Beyond "Being There"（CHI 2026）将 VR 叙事参与度分解为认知（空间记忆、叙事理解）、情感（情绪效价、共情反应）、行为（交互深度、路径选择）三个维度，并提出了对应的测量方法【beyondbeingthere2026】。在范式层面，Storyliving 提出应将 VR 理解为"叙事生活"（storyliving）——用户通过身体行为主动建构意义，而非被动接收作者预设的叙事【storyliving2022】。在工具层面，RécitKit 提供了一套空间叙事设计套件，包含时空场景编辑器、注意力引导系统和评估模块，可将文本描述转化为 VR 中的空间叙事单元【recitkit2025】。

这些框架在设计层面各有贡献，但共同的现实约束是成本。Embracing Immersive Journalism 的调研显示，沉浸式新闻的典型制作预算在 5 万到 50 万美元之间，且存在人才缺口、分发困难和 ROI 不明确等问题【embracing2024】。现有的生产模式成本过高，难以支持大规模的内容生产，这也解释了为何现有工作主要依赖少量被人工精选的素材。内容供给的瓶颈由此显现：高质量的叙事内容无法规模化生产。



**2.2 Embodiment and Empathy in Immersive environmentsVR（具身感与共情）**

如果 2.1 回答的是"新闻 VR 让人体验什么"，那么本节关注回答的是"这种体验如何产生情感影响"。答案指向具身感（Sense of Embodiment, SoE）——身体在虚拟空间中的存在感如何影响情感反应，这一机制已被大量实证研究所确认【kilteni2012embodiment】。Kilteni 等人给出了 SoE 的操作性定义，将其分解为三个子要素：自我定位（self-location），即感知到自己位于虚拟身体内部的体验；身体所有权（body ownership），即虚拟身体属于自己的感觉；能动性（agency），即对虚拟身体动作有控制感的体验【kilteni2012embodiment】。该工作已成为后续 VR 具身研究的基础框架。研究者通过橡胶手错觉的 VR 版实验发现，视觉-触觉一致性可以显著增强对身体所有权的感知，且此效应可推广至整个虚拟身体；通过延迟运动反馈实验（100ms/300ms/500ms 延迟量），发现 100ms 以内的延迟对能动感影响较小，300ms 以上则显著破坏能动性。

SoE 三要素对本文有直接的理论意义：若要用户在 VR 中产生"我在火灾现场"的具身感，新闻报道所提供的场景信息必须足够支撑这三个维度的重建——空间信息（楼层、走廊、楼梯）支撑自我定位，身体行为描写（扶墙行走、匍匐前进）支撑身体所有权，决策与选择描写（不乘电梯、改走消防通道）支撑能动性。换言之，一篇报道是否具备 VR 重建价值，取决于它在这三个维度上提供了多少可操作的证据。这一视角将在方法章节（第 4 节）中作为筛选标准的理论依据展开。

早于 Kilteni 的工作，Slater 和 Wilbur 在 1997 年就系统定义了沉浸式虚拟环境的临场感（presence）框架，将"在场"区分为技术层面的沉浸（immersion）和心理层面的临场感（presence）【slater1997five】。这一区分至今仍有理论价值：沉浸是 VR 系统的技术参数（视场角、追踪精度、显示分辨率），临场感是用户的心理状态（"我好像真的在那里"），而共情是更高层次的情感结果。这三者不能混为一谈——Feeling the News? 的发现（被动观看即使在场感高，情感提升也不显著）【feelingnews2023】正是在实践中验证了这一理论区分。

在设计路径上，Jiang 等人提出了一个 VR 共情设计框架（EVRD）~~，发表于 IJHCS 2025。~~该工作采用实践导向的研究方法（practice-led design），提出了一个反直觉的设计策略——"doomed-to-fail"（注定失败）。传统 VR 叙事往往设计用户"成功救援"的情节，但 EVRD 的实验结果显示，让用户在 VR 中体验"无法成功"的情境（如无论怎么努力都无法打开那扇门），对认知共情的促进作用反而更显著——用户通过亲身经历理解了障碍者所处困境的结构性原因，而非停留在情感同情层面【evrd2025】。

Ahn 和 Bailenson 的经典实验从另一个角度验证了具身体验的力量：他们让参与者在一款沉浸式虚拟环境中"砍伐"一棵虚拟树，或者仅仅观看别人砍树的视频。结果发现，具有具身体验的参与者在事后的环保行为和态度改变上显著强于仅观看视频的对照组【ahn2013embodied】【ahn2014short】。这说明具身体验不仅影响情感，还能驱动现实世界中实际的行为的改变——~~这在论文方法学上意味着：我们对 VR 共情效果的评估不能只测情绪反应，还应该测量行为层面的变化。~~

在更宏观的层面，近年来也出现了几篇整合性的综述。Cultivating Empathy Through Narratives in VR（2024）系统回顾了叙事驱动的 VR 共情研究，将现有研究按照~~"叙事类型×共情维度"~~进行了分类【cultivation2024】。一篇发表在 Virtual Reality 期刊上的范围综述则更为全面地梳理了 VR 共情干预研究的全景，识别了当前研究在方法论一致性上的不足【vrscoping2024】。这些综述为本文的贡献定位提供了参照：相比于"从零设计一个 VR 共情体验"（大多数现有工作），我们关注的是一个前置但被忽视的问题——"从海量文本中筛选出哪些素材具备 VR 共情重建潜力"。

**2.2.1 高层火灾疏散行为学：具身参数的实证来源。**具身感的"身体约束"维度需要实证参数支撑，高层火灾疏散行为学提供了这一基础。Kuligowski 等（NIST）通过大规模疏散演练建立了疏散决策三阶段模型（预疏散延迟 → 移动 → 到达安全区），并测量了健全人与残障人群在疏散中的行为差异【kuligowski_nist】。Gwynne 和 Rosenbaum 系统测算了老年人疏散步速（0.4-0.6 m/s，约为健全人的一半）【gwynne2016evacuation】；Ronchi 等测量了轮椅使用者、低视力者在楼梯疏散中的可通过性与烟雾影响【ronchi2013wheelchair】。这些参数为本文六角色（陈伯/罗姐/阿May/威廉/King仔/阿福）的身体约束建模提供了直接输入，也是第 3 节角色设计（3.3）与映射表（3.4）的依据。Kobes 等对建筑安全与火灾中人类行为的综述【kobes2009evacuation】，以及 Kinateder 等关于 VR 用于疏散研究的综述【kinateder2018vr】则确认了 VR 作为火灾疏散行为研究工具的可行性。



**2.3 弱势群体的 VR：可达性、表征与伦理**

将 VR 用于弱势群体体验与共情培育，近年在 CHI 会议上涌现了一系列值得关注的工作。这些工作可以从"怎么做"（方法论）、"怎么理解"（理论框架）、"怎么设计"（设计指南）和"怎么批评"（伦理约束）四个层面来理解。

在方法论层面，Shocking Realities（CHI 2025）通过 VR 恐怖游戏将轮椅用户的日常挑战嵌入恐怖游戏机制之中，设计了四种具体的场景关卡：狭窄通道、坡道角度（超出 ADA 标准的斜坡）、到达高度（安装在站姿者可达高度而非轮椅使用者可达高度的消防报警按钮）、以及地板障碍（地面上散布碎片和障碍物，轮椅只能绕过而非跨过）。用户测试显示，体验过的参与者对轮椅可达性问题的认知显著提升，而且这种认知提升不是通过"怜悯"而是通过"体验到了障碍确实存在"来实现的【shockingrealities2025】。这个方法论突破在于它避免了传统说教式共情的陷阱——不是告诉用户"轮椅用户很困难"，而是让用户"在游戏中自己发现困难"。

另一组对照实验来自视觉障碍模拟的研究。该实验让 35 名大学生以第一人称体验四种视觉受限场景（近视模糊、中心视野缺失、周边视野缺失、完全黑暗），并在事后使用 IRI 量表测量共情变化。结果显示，实验组在观点采择和共情关注维度上有显著的统计学提升（p < 0.01, d = 0.45），且一周后的追踪测试中效应仍部分保留【visualimpairment2025】。The Machine to Be Another 则从另一个角度切入具身共情：通过实时摄像机画面交换让两个参与者"拥有"对方的身体，后续 fMRI 研究显示体验者的前额叶皮层激活模式在内群体-外群体区分任务中发生改变【machinetobeanother】。

在理论框架层面，An Equitable Experience?（CHI 2025）通过系统性文献综述，识别出了 HCI 文献中关于 VR 残障可达性的三种概念化方式：技术可达性（硬件能否使用，如控制器是否可单手操作）、体验可达性（体验质量是否与非残障用户相当，如盲人用户能否通过空间音频获得类似的场景认知）、表征可达性（残障身份是否在 VR 内容中得到准确尊重多样化的呈现，如化身设计是否避免刻板印象）。该研究还指出，当前大多数工作集中在技术可达性层面，表征可达性最少被触及【equitable2025】。

在设计指南层面，Inclusive Avatar Guidelines（CHI 2025）提出了四条残障化身设计原则：提供选项而非强制（让用户自己决定是否在化身中展示辅助器具）、避免唯一表征（同一残障类别应有不同年龄、性别、风格的化身变体）、功能对应而非视觉装饰（辅助器具在 VR 中应与真实交互功能对应）、与真实社区协同设计【inclusiveavatar2025】。

LegacySphere（CHI 2024）提供了一个整合了具身、角色扮演和叙事三要素的 VR 视角转换系统，用于跨代际沟通。其核心发现是：具身体验（embodiment）与叙事体验（narrative）之间存在协同效应——两者结合比单独使用任何一个都能更有效地促进共情【legacysphere2024】。

在伦理约束层面，Tigwell（CHI 2021）通过调研 92 名设计师和 17 名盲人/低视力用户，对失能模拟的伦理问题提出了系统批评：如果只呈现"缺陷"而不揭示"环境限制"，模拟可能激起怜悯或恐惧而非真正的共情【tigwell2021】。这项 CHI 高引工作已经在方法论层面被上述 CHI 2025 的工作所回应——Shocking Realities 通过"环境失败"机制而非"缺陷展示"来设计体验【shockingrealities2025】，Equitable Experience 则从理论层面将"表征可达性"提升到了与技术可达性同等重要的地位【equitable2025】。这一伦理约束指向一个设计原则：应当呈现~~"身体 × 环境耦合"~~的困境（问题在环境，不在残障者），而非孤立地展示缺陷。

在灾害风险沟通层面，Kshirsagar 等【kshirsagar2025iscram】与 Shakib 等【shakib2025iscram】分别从听障应急通信和听障灾害警报两个角度证实：仅依赖 85dB 声学警报的传统系统对听障群体的警报可达性近乎为零，视觉替代方案（频闪灯/文字推送）则存在"必须主动关注设备"的限制。Bennett 等（CHI 2019）进一步提出了 ASL 应急警报的设计方案【bennett2019asl】。OECD 国家的范围综述发现，听障者依赖社交网络（邻里/家人）而非官方警报获取灾难信息【oecd_dhh_scoping】。这些发现表明：听觉信息的缺失使听障者在火灾中面临"信息断裂"，而这一断裂只能通过非听觉渠道（如邻里提示）弥补——这正是 3.3 中阿May 角色设计所依据的实证事实。



**2.4 研究空白与本文回应（？deeper）**

综合以上三条脉络，可以识别出一个贯穿始终的共同缺口。为了让论证更具体，我们将其分解为三个相互关联的问题，每个问题都对应前文某条脉络中未被回答的部分：

**缺口一：内容供给依赖人工精制，缺乏规模化生产路径。**从 2.1 可以看到，沉浸式新闻的内容来源依赖知名通讯社的已发表稿件【delapena2010immersive】与昂贵的现场制作（预算 5-50 万美元）【embracing2024】；从 2.2 与 2.3 可以看到，VR 共情模拟的内容设计同样依赖研究人员精心编写实验脚本【shockingrealities2025】【visualimpairment2025】【legacysphere2024】。HCI 文献关注的焦点是"如何评估已成型的 VR 体验"【beyondbeingthere2026】和"如何设计可用的 VR 系统"【recitkit2025】，但内容如何获取、如何从大规模语料中筛选出可重建的场景，这一前置环节几乎无人系统化处理。PRISMA 提供了系统综述的报告标准，但其面向的是学术文献检索，而非面向 VR 场景重建的新闻正文筛选【page2021prisma】。

**缺口二：缺乏"什么文本适合转化为具身 VR 体验"的筛选标准。**承接缺口一，即便承认需要规模化内容生产，现有文献也没有回答一个更基础的问题：什么样的新闻报道具有 VR 重建潜力？具身感理论（2.2）告诉我们，重建需要空间信息、身体行为与决策描写的支撑，但现有研究从未给出将这些理论要求操作化为可执行筛选标准的方案。换言之，从文本语料到具身体验设计的转化过程，目前仍是一个未被挖掘的黑箱。

**缺口三：弱势群体的 VR 共情体验是单次、封闭、预制的。**从 2.3 可以看到，已有弱势群体 VR 共情工作均以"完成一次模拟"为终点——用户玩完一个关卡【shockingrealities2025】或做完一次视角转换【visualimpairment2025】【machinetobeanother】后体验即结束。缺乏将弱势群体视角嵌入可持续体验框架的尝试，用户无法在不同条件下反复遭遇同一个弱势群体角色的身体限制，也就难以理解"信息断裂 × 身体约束 × 环境恶化"这三重困境是如何在真实火灾中交织发生的。

本文以一个端到端系统同时回应上述三个缺口。在内容供给上，我们提出一套人机协作的大规模语料筛选流程（作为实现手段，详见方法章节），从 8,180 条检索结果中筛选出 109 条具备 VR 重建条件的火灾报道，另有 16 篇人工补充高价值报道；更关键的是，对这批语料的标注与分析产生了关于弱势群体火灾体验的系统性 insight——哪些困境在真实报道中被反复记载、哪些感官信息（如声音）在报道中长期缺失——这些 insight 反过来指导叙事与交互机制的设计。在体验形式上，我们将筛选出的报道嵌入可持续的 VR 体验框架，使用户可以反复以不同弱势群体的化身经历身体 × 环境耦合的共情叙事。

综上，本文的贡献定位为：一，以真实火灾语料为基础、以弱势群体具身视角为核心的可持续 VR 共情体验框架；二，从大规模语料中系统化提取可重建场景并归纳弱势群体火灾体验 insight 的方法路径。其中，语料筛选是支撑性的实现手段，而对保留素材（109 条正式 + 16 篇补充）的 SAVTBC 六维编码所揭示的弱势群体体验特征，才是方法层面的真正贡献。该框架的理论基础来自 SoE 三要素【kilteni2012embodiment】，评估方法参考 Beyond "Being There" 的三维参与度框架【beyondbeingthere2026】，叙事范式借鉴 Storyliving 的"叙事生活"理念【storyliving2022】，弱势群体相关的方法论和伦理约束则来自 Shocking Realities【shockingrealities2025】、Equitable Experience【equitable2025】和 Tigwell 的研究【tigwell2021】。



# 3. System Design: VR 高层火灾共情系统（未）

## 3.1 设计目标与原则

（需要过渡，并说明白设计目标为什么存在、依据是什么、怎么对应前文/gap等）

- **身体 × 环境耦合**：VR 环境参数是"因"，障碍症状是"果"。同一个环境参数（烟雾密度、火警铃、楼梯）在不同障碍模块下产生不同的主观体验——这是共情的来源。例如"黑烟从门缝涌入"在健全人眼中是"能见度 5m"，在视障者眼中是"残余视野归零"，在儿童眼中是"视线高度完全被烟雾层遮挡"
- **doomed-to-fail 机制**：让用户在拼尽全力后仍无法完成任务，真正理解"为什么对这个身体来说，逃生是不可能的"【evrd2025】——轮椅者在楼梯口被物理阻断、老年人体力耗尽倒在 12 层。
- **呈现"环境限制"而非"缺陷"**：听障 × 仅声音警报 = 收不到信号，把矛头指向无障碍环境缺失而非残障者自身【tigwell2021】。
- **真实场景依据**：所有场景参数来自真实新闻语料与医学文献，而非设计师想象。

## 3.2 系统架构：三层模块化

系统采用 **人物模块 Persona × 障碍模块 Impairment × 场景模块 Scene** 三层模块化架构：

| 模块 | 内容 |
|-|-|
| 人物模块 | 六类人群（听障/老年/轮椅/视障/儿童/拄拐）× 3 亚型分型矩阵，含实证疏散参数（步速、视野、听力） |
| 障碍模块 | 四种感官剥夺通道：听觉（信息断裂）/ 视觉（视野剥夺）/ 移动（物理阻断）/ 体能（衰竭） |
| 场景模块 | 六维场景参数系统（空间/声音/视觉/时间/身体/社交），来自真实新闻语料打标 |

## 3.3 六角色设计与任务树

**为什么是这六类角色？**依据来自两条实证线索：一是疏散行为学文献中反复出现的高危人群（见 2.2.1：老年步速 Gwynne 等【gwynne2016evacuation】、轮椅与低视力者 Ronchi 等【ronchi2013wheelchair】、听障灾害通信 Kshirsagar/Shakib 等【kshirsagar2025iscram】【shakib2025iscram】）；二是本研究对保留素材（109 条正式 + 16 篇补充）的 SAVTBC 打标中，出现频率最高的弱势群体类别（老年 47 / 儿童 41 / 视障 17 / 身体受限 15，见 5.2）。两类证据的交集确定六类角色：阿May（听障）、陈伯（老年）、罗姐（轮椅）、威廉（视障）、King仔（儿童）、阿福（拄拐）。任务树结构则对应疏散行为学的决策三阶段模型（预疏散延迟 → 移动 → 到达安全区）【kuligowski_nist】。

每个角色体验设计为线性主任务 + 分支决策点，时长 5-8 分钟（符合 VR 舒适性）。场景以香港宏昌阁（宏福苑原型）31 层住宅为原型。

| 角色 | 障碍类型 | 核心困境 | 教学点 |
|-|-|-|-|
| 阿May（34 岁，听障） | 听觉信息断裂 | 火警铃、敲门、爆炸、消防员喊话全部听不到 | 信息延迟：比邻居晚 5-10 秒知道危险；紧急沟通壁垒 |
| 陈伯（78 岁，老年） | 移动 + 体能 | 步速 0.4m/s，每下 3 层强制停喘；高频听损致铃声模糊 | 22 层对健全人是 5 分钟的路，对陈伯是生死的距离 |
| 罗姐（52 岁，轮椅） | 物理阻断 | 楼梯完全不可过；电梯火灾禁用（绝望循环）；5cm 门槛如墙 | 距楼梯只有 3 米，但这 3 米是一道永远跨不过的坎 |
| 威廉（60 岁，管状视野） | 视野剥夺 | 屏幕仅中央 20° 清晰；被视野外撞倒；烟雾使残余视野归零 | 你只看到世界的 5%，火灾让你连这 5% 也失去 |
| King仔（7 岁，儿童） | 低视角 + 理解断裂 | 相机高度 105cm；烟雾下沉 120cm 完全遮挡；腿的森林 | 火灾里儿童看到的是一个"腿的森林" |
| 阿福（40 岁，拄拐） | 速度 + 跌倒风险 | 步速 0.5x；无扶手处跌倒概率 5%/步；被催促、被超越挤倒 | 健全人嫌你慢，但你能做的已经是最快 |

## 3.4 VR 环境指标 → 障碍症状映射表

**映射依据**：每一行的"健全人 vs 残障者"差异均来自 2.2.1 引用的实证参数（步速/可达性/烟雾影响【gwynne2016evacuation】【ronchi2013wheelchair】）与 2.3 的灾害通信研究（85dB 警报对听障者近乎无效【kshirsagar2025iscram】【shakib2025iscram】）；烟雾视觉影响（管状视野、能见度）参考视觉障碍模拟实验的设计参数【visualimpairment2025】。映射的用途是"体验设计参数"而非医学诊断——它将文献中的行为学数据转化为 VR 环境参数的感官结果，供关卡搭建使用。

| VR 环境指标 | 健全人 | 听障者 | 视障（管状） | 轮椅/老年 |
|-|-|-|-|-|
| 黑烟密度 0.7-0.95 | 能见度 \~5m，呛咳 | 同健全人但无听觉导航 | 能见度 \~0.3m，只剩中央小孔 | 无法弯腰贴地走（轮椅）；呼吸更困难（老年） |
| 火警铃 85dB | 清晰可闻 | **完全听不到** ⚠️ | 清晰可闻 | 高频听损，铃声模糊（老年） |
| 楼梯间烟雾灌入 | 加速下楼 | 不知道上面着火 | 视野外全是烟雾，无法判断安全 | 楼梯完全不可过（轮椅）；每 3 层强制停（老年） |
| 电梯禁用标识 | 自然走楼梯 | 同健全人 | 无法读标识 | **致命阻断**——反复按无效按钮（轮椅） |
| 邻里敲门/呼喊 | 获得信息 | **完全听不到敲门** ⚠️ | 看不到谁在敲门 | 开门慢，错过黄金窗口（老年） |
| 走廊浓烟 | 低头捂鼻快走 | 同健全人 | 视野极小，易撞墙 | 烟雾层在头顶，坐姿视线更低（轮椅） |

⚠️ = 核心教学点（信息断裂/物理阻断），VR 独特性最强的体验。

## 3.5 通用游戏机制

- **核心循环**：感知环境 → 做出决策 → 执行动作 → 环境实时变化 → 产生后果；障碍模块持续施加限制（听障缺听觉通道、视障缺视觉通道、移动障碍限速度/通过性、体能障碍限耐力）。
- **HUD 系统**：体力槽（老年/体能角色）、时间压力（火势楼层 vs 玩家楼层）、心率（超阈值触发视线模糊）、障碍状态（复盘画面）。
- **交互动作库**：扳机键抓取/开门；握持键摸墙（触觉导航）；摇杆蹲下/爬行（烟雾层下方）；A 键呼救（3 秒 CD）；双手柄交替上推（推轮椅/爬楼梯 QTE）；手柄快速摇动（拔拐杖/挣脱）。
- **难度自适应**：三档预设（入门/标准/极限：烟雾能见度 8m/4m/1.5m、火速 1/2/3 层每分、起始楼层 12/22/28 层）；可变维度支持研究对照（固定人物 × 可变环境、固定环境 × 可变人物、固定一切 × 可变信息提示）。

## 3.6 共情测量嵌入设计

| 测量维度 | 工具 | 游戏触发点 |
|-|-|-|
| 情感共情 | IRI-Empathic Concern + 自我重叠(IOS) | 结局后问卷（VR 内填写）【evrd2025】 |
| 认知共情 | 锚定任务："估计陈伯下楼需要几分钟？" | 体验前/后各测一次【chi26_virtual_perspectives】 |
| 行为共情 | 捐助意愿（无障碍改造） | 体验结束屏【evrd2025】 |
| 临场感 | SUS 临场感量表（6 题简版） | 体验后【slater1997five】 |
| 情境意识 | SAGAT 冻结探针："火势在几层？你现在几层？" | 游戏中 2-3 次随机冻结【endsley_sa】 |

# 4. Method: 真实新闻语料驱动的场景依据获取

本章描述系统场景依据的获取方法：从大规模高层火灾新闻中筛选"具身场景可重建"报道，经六维场景编码转译为 VR 关卡参数。流程遵循"人定规则 → 规则审核 → AI 大规模筛选 → 迭代至达标"的人机协同框架。

## 4.1 检索策略与数据收集✔

### 4.1.1 检索策略（概念块 AND 组合）

- **Block 1 事件**：`(fire OR blaze OR inferno OR "caught fire")`
- **Block 2 场所**：`("high-rise" OR "high rise" OR highrise OR tower OR "apartment building")`
- **Block 3 疏散**：`(evacuation OR evacuate OR escape OR trapped OR rescue)`
- **Tier-B 定向召回**：`+ elderly OR disabled OR wheelchair OR deaf OR blind`（中英双语，覆盖项目核心弱势群体）

### 4.1.2 数据源与收集结果✔

| 数据源 | 作用 |
|-|-|
| GDELT DOC 2.0 API | 主力：免费、全球覆盖、回溯 24 个月 |
| Google News RSS | 补充：按月切分突破单次 100 条限制 |
| Bing News RSS | 补充：中英文双轨 |

- **检索命中（S0）**：8,180 条（GDELT 11 检索式 × 36 月 + RSS + Bing 去重后）
- **正文抓取成功（S1）**：6,666 条（排除死链/付费墙/空正文/正文 <300 字，有效率 81.5%）

## 4.2 人工金标准构建

**设计原则**：遵循"小批量人工审阅归纳规则 → 规则审核 → AI 大规模执行 → 人工复核"的循环，保留判断权始终在人。金标准由两个阶段构成，分别承担"定规则"与"做裁决"两种职能：

【6666条有效正文中，根据不同方法抽样人工判定了403条，确定了筛选非高层火灾相关的标准】

**阶段一 · 规则归纳（403 条人工判定）**

- 目标：从多样本中归纳"什么报道值得保留"的规则。

抽样设计覆盖三种方式：**顺序样本**（GoldSet103，检验全量池中非火灾占比）、**分层抽样**（v2/v3/v4，按长度×场景×人物×弱势四维分层，保证代表性）、**早期路由批次**（001/002，检验关键词初筛效果）。这一阶段判定的 403 条中约 92% 判剔除，31篇保留

- 关键产出：一是归纳出纳入标准（I1 具身场景细节 / I2 人物叙事）与排除标准（E1-E6）；
- 二是形成**负样本集**（判 0 的报道），用于归纳排除类别并构建模型提示；K 侧误留率由独立抽查的 62 篇审计。



【省略了：Grok 按规则对 6,666 篇正文做语义初筛，同事件去重后得到 1,027 篇候选池（火灾相关）】

**阶段三 · 火灾池精判（291 条人工判定，保留 78 条）**

- 目标：在 AI 过滤后的纯火灾候选池上，按定稿标准逐条裁决。

批次为：

① **第 1 批确认（300 条，长文优先）**——首批精判，发现候选过多且有重复，触发去重。

② **精简（101 条，第 1 批子集）**——同事件聚簇去重、剔除简报类，压缩候选。

③ **超精简（78 条，另取）**——按已判样本学习的打分排序，只留高置信候选。

④ **第 2 批（100 条，另取）**——场景分排序补判，覆盖前几批未触及的高分候选。

⑤ **边缘候选补判（50 条）**——对可能被过度压缩的报道按场景分补捞，防止漏判。

⑥ **第 8 轮收口（24 条）**——Grok 初筛后人工复核，对剩余未裁决候选做最终裁决。

每批完成后执行"校验 → 校准 → 重跑"闭环（新增判定回注后重新校准筛选规则），批次间有重叠（如精简批为第 1 批子集），去重合并后阶段三共进金标准 291 条。本阶段产生保留 78 条，与阶段一保留的 31 条合计为正式保留 109 条。

**金标准规模（累计工作量，不参与漏斗）**：

人工判定累计 694 条 = 阶段一规则归纳 403 条 + 阶段三火灾池精判 291 条（其中保留 109 = 阶段一 31 + 阶段三 78；剔除 585）

**标注一致性：跨批次重复出现的 41 条报道，人工判定结果完全一致（100%）；判定由单人完成、跨批次回注校验，过程可回溯至原始报道。**

## 4.3 方法演进记录

最终筛选方法见 4.6 管线图。本表记录方法探索过程中的关键迭代，作为可复现性与方法学反思的证据（每轮的原因、内容、结果均如实保留）：

| 轮次 | 方法 | 动机 | 数据与效果 | 结论 |
|-|-|-|-|-|
| 迭代 0 | v0 标题级 6 维评分 | 第一轮粗筛 | 一次筛 8,072，保留 52 | 废弃：标题无法反映正文质量 |
| 迭代 1 | v1 关键词三票 + 保守自动剔除 | 落实"AI 只剔不保留" | 103 条开发样本上的探索性结果（误留 0/103、误删 0.97%、自动剔除 87.6%），非总体估计 | 框架正确：AI 做模型辅助过滤，保留权留给人工（该轮为 103 条开发样本上的探索性结论） |
| 迭代 2 | batch-1/2 小批量顺序迭代 | 逐批学习用户标准 | 学到弱势群体加分等规则 | 效率低：全量 80 轮不可接受 |
| 迭代 3 | 一次性聚类 + 代表传播 | 压缩人工轮次 | silhouette 0.18；自动处理 3,117 条 | 废弃：方法学硬伤（代表无信息量、传播零验证） |
| 迭代 4 | 三种自动方法定量对比 | 实证检验自动方法上限 | 关键词 P14.4/R91.7；Grok P24.4/R41.7；组合 F1 31.6% | 单一自动方法均不可靠 |
| 迭代 5 | Grok 正文语义初筛（定稿） | 标题法否决、特征词误召回 47% | 6,666 → K 1,443（火灾）/D 5,192/E 31（62 条 K 类抽查未见误留） | 正文语义判断是正确方案 |
| 迭代 6 | 用户标准学习 + 超精简确认（收口） | 用户批注量不可接受 | 694 条金标准；保留均分 11.6 vs 剔除 4.2 | 用已判样本学习打分，压缩人工量 |

## 4.4 最终筛选标准：具身场景可重建性

- **保留依据**：一篇报道只要能让设计者回答以下**任一**问题，即保留：

  - ①空间——我能重建这栋楼的内部结构吗（楼梯/走廊/窗户/阳台/电梯的位置与动线）？
  - ②火与烟——我能再现火焰从哪里蔓延到哪里、烟雾多浓多高吗？
  - ③身体——我能模拟高温灼热、呛咳窒息、能见度下降这些身体感受吗？
  - ④人物——我能还原"谁、从哪、通过什么动作"逃生或被救（爬/跳/逃/被救/呼救）吗？
  - 每条新闻各有侧重即可，不需面面俱到。
- **排除标准（标题仅作排除线索，正文全文为判定单元）**：纯伤亡数字通报、官方声明、政策讨论、纪念活动、法律调查进展、新闻简报、同事件重复报道（只留场景最丰富一篇）。**注意：正文出现 "officials said"、"memorial" 等词是新闻常态，不作为排除依据**——只有标题本身命中排除类别，且正文主要内容匹配该类别、不含 I1/I2 证据时，才按 E1-E5 剔除。
- **理论根系**：具身感 SoE 三要素【kilteni2012embodiment】——空间细节对应自我定位、身体动作对应身体所有权、决策描写对应能动性。

### 操作化判例（I1/I2/E1-E6）

**判别流程**：标题初筛 → 正文精读 → 满足 I1/I2 任一即保留；正文主要匹配 E1-E6 且无 I1/I2 即剔除；标题命中但正文含具身场景则保留（标题 vs 正文判例边界）。

| 类别 | 典型判例（正文摘录） | 判别要点 |
|-|-|-|
| **I1 具身场景细节** | "浓烟滚滚，楼道能见度不足一米，居民沿楼梯扶手摸墙下行"、"明火从 12 层窗户喷出，黑烟沿外墙向上翻滚 50 米"、"顶层公寓 6 楼一名男子从窗口跳下，邻居用被单在下面接" | 空间细节（楼/窗/阳台/楼梯/走廊）+ 火烟视觉 + 身体感受，三类任一可保留 |
| **I2 人物叙事** | 人物身份 + 动作（爬/跳/逃/被救/呼救）+ 救助关系，三类任一可保留 |  |
| **E1 伤亡通报（剔除）** | 仅伤亡数字通报，无空间/人物/动作细节 |  |
| **E2 官方声明（剔除）** | 引述官方表态，无具身场景或人物动作 |  |
| **E3 纪念活动（剔除）** | 仅纪念/悼念仪式，无场景细节 |  |
| **E4 法律调查（剔除）** | 法律程序报道，无具身场景 |  |
| **E5 新闻简报（剔除）** | 一句话简讯，无细节展开 |  |
| **E6 同事件重复** | 同一 gid 出现多次判 1，仅保留 1 篇；4.6 同事件去重为 1,027 候选池 |  |
| **边界：标题 E3 命中但正文有 I1/I2（保留）** | 正文含具身场景 → 保留；标题类别仅作排除线索 |  |

**跨轮次一致性验证**：41 个 gid 在多批次中重复判定一致率 100%，证明判例应用可重复。

## 4.5 新闻 → VR 场景转译（未）

保留报道经 **SAVTBC 六维场景编码**（空间/声音/视觉/时间/身体/社交）打标，场景还原度分级后提取 VR 参数：

| 维度 | 高频指标（保留素材打标，109 条正式 + 16 篇补充，2026-08-05） | 覆盖率 |
|-|-|-|
| S 空间 | 高层 58 / 窗 42 / 楼梯间 35 / 阳台 8 | 93% |
| A 声音 | 邻里呼喊 43 / 爆炸声 17 / 火警铃 9 / 敲门 16 | **70%（最低）** |
| V 视觉 | 明火 91 / 浓烟 60 / 黑烟 24 | 95% |
| T 时间 | 清晨/白天/快速蔓延 | 88% |
| B 身体 | 烟雾刺激 82 / 高温灼热 45 / 跌倒 6 | 88% |
| C 社交 | 老年人 49 / 儿童 42 / 邻里互助 40 / 家庭单元 31 | 98% |

**关键发现：A 声音维覆盖率最低（70%）**——约 30% 报道缺少声音描写。需注意：这反映的是新闻写作对声音信息的覆盖不足，不能直接等同于"现实火灾中听障者收不到警报"；结合宏福苑"无声警报"的幸存者自述与听障灾害通信文献【kshirsagar2025iscram】，该发现支持"声音信息在火灾叙事中系统性缺位"的判断，为 VR 听觉设计提供参考而非因果结论。标签对接六角色：老年人 49→陈伯、儿童 42→King仔、视障（视觉障碍 18）→威廉、轮椅 1→罗姐。

## 4.6 筛选管线

整个筛选流程分三阶段：

- **阶段一 · 规则归纳（人工先行）**：从 8,180 检索结果抽样（顺序样本 GoldSet103 + 分层抽样 v2/v3/v4 + 批次 001/002），人工判定约 403 条，归纳保留/剔除规则（I1/I2 + E1-E6），同时形成负样本用于归纳排除类别并构建模型提示。
- **阶段二 · AI 大规模执行**：Grok 按规则对 6,666 篇正文做语义初筛（K=1,443 真火灾 / D=5,192 非火灾 / E=31 接口错误），同事件去重后得到 1,027 篇候选池。

> **验证：K 侧抽查 62 条外部核对全部命中（0/62 误留）——"0% 误留"指抽查样本，非总体断言（近似单侧 95% 上界 4.8%，rule of three；62 条为人工抽检，报告为描述性审计）；D 侧 5,192 条非火灾为语义判定，抽样核查待后续补全。**

- **阶段三 · 精判定稿（人工复核）**：在火灾候选池（1,027）上按**定稿标准（I1 具身场景细节 / I2 人物叙事，任一即保留）**逐批判定，每批完成后用新判定回注、重校准筛选规则。批次演进如下（数字为各批判定条数，批次间有重叠，非候选池剩余量）：

> ① **第 1 批确认（300 条，长文优先）**——首批精判，发现候选过多且有重复，触发去重；② **精简（101 条，第 1 批子集）**——同事件聚簇去重、剔除简报类，压缩候选；③ **超精简（78 条，另取）**——按已判样本学习的打分排序，只留高置信候选；④ **第 2 批（100 条，另取）**——场景分排序补判，覆盖前几批未触及的高分候选；⑤ **边缘候选补判（50 条）**——对可能被过度压缩的报道按场景分补捞，防止漏判；⑥ **第 8 轮收口（24 条）**——Grok 初筛后人工复核，对剩余未裁决候选做最终裁决。

各批判定条数有重叠（如精简批为第 1 批子集），去重合并后阶段三共进金标准 291 条（保留 78 条）；加上阶段一规则学习阶段判定的 31 条保留，正式保留合计 **109 条**（31 + 78）；另有 16 篇人工补充高价值报道，共同构成 VR 场景重建素材库。



**图 4-1：数据筛选管线（三阶段人机协同）**

![数据筛选管线（5 层 AI 漏斗 + 人工精判，109 = 31 + 78；694 为累计工作量不参与漏斗）](https://internal-api-drive-stream.feishu.cn/space/api/box/stream/download/authcode/?code=YjkyMzgwNzRlOGE2NTU0ZTFmMTY4YTRiNTY1OTU4NWRfYWUzYWJjMDdmMjE2Y2Q2NjUxOGRiMGI0NjE2MjMxMmFfSUQ6NzY3NDY5NzQ4MzkzODcyODkyNl8xNzg3MjAyMjg3OjE3ODcyMDU4ODdfVjM)

**数据可用性（证据文件）**：全量检索与判定记录 `_全量_grok判定.csv`（6,666 行）；人工金标准累计 `_merged_user_labels.csv`（694 行，109 保留 + 585 剔除）；保留集完整正文 `_保留集_FINAL_完整版.csv`（125 行）；SAVTBC 六维打标 `_保留集_SAVTBC打标.csv`（125 行）。以上文件可在项目数据目录核对。

# 5. Results: 场景依据库

## 5.1 筛选漏斗

| 层级 | 数量 | 说明 |
|-|-|-|
| 检索命中 | 8,180 | GDELT + Google/Bing News |
| 正文有效 | 6,666 | 去死链/空文/<300 字 |
| AI 语义判火灾 | 1,443 | Grok 读正文语义判火灾；K 侧抽查 62 条误留 0/62（近似单侧 95% 上界 4.8%） |
| 同事件去重 | 1,027 | 每事件留场景最丰富一篇 |
| **人工精判保留** | **109 条** | 阶段一规则学习保留 31 篇；阶段三从候选池精判保留 78 篇（109 = 31 + 78） |

**另有 16 篇人工定向收集的高价值报道**（宏福苑幸存者自述、Grenfell 证词、上海静安口述等，非 GDELT 检索结果）作为补充素材，具身细节密度极高，与 109 条正式保留共同构成 VR 场景重建素材库，详见 5.2.2。

## 5.2 保留集构成

### 5.2.1 正式筛选保留（109 条）

- **语种**：中文 8 条 + 英文 13 条 + 英文/其他语种 88 条（合计 109）
- **事件覆盖**：香港大埔宏福苑 11 条（系统场景原型）、纽约（Bronx/Inwood/Manhattan/Brooklyn）15 条、印度（Palam/Delhi/Noida/Ghaziabad）8 条、柏林/莫斯科/曼谷等国际火灾
- **代表性样本**：香港大埔"延烧的一夜"（452/454/455）、汕头自建房火灾始末（4346）、Survivors jump from fire escapes（5111）、Palam 父女跳楼（143）、Bangkok 38 层公寓（5619）、轮椅+孕妇逃生（5636）、母亲救 3 孩子（2174）、saree 爬下逃生（415）
- **六角色场景对应**：听障（阿May）← 宏福苑"无声警报"细节；老年（陈伯）← 宏福苑长者逃生/汕头自建房；轮椅（罗姐）← 5636 轮椅+孕妇/5111 fire escape；视障（威廉）← 浓烟中摸墙细节；儿童（King仔）← 儿童获救叙事；拄拐（阿福）← 互助逃生细节

### 5.2.2 补充语料（16 篇，人工确认，S1-S16）

- **来源**：用户提供 + 检索挖掘的中文深度报道与系统性采访材料（GDELT 检索盲区的人工弥补）
- **内容**：宏福苑幸存者自述×3、宏福苑系列、南京明尚西苑、上海静安逃生记、格伦费尔系列×4、Cook County、杭州/海淀/广州/17 楼、上海静安口述补充
- **价值**：具身细节密度极高（宏福苑"摸墙救夫妇"、上海静安"10 楼跳脚手架"、格伦费尔"扔婴儿接住"），是 VR 重建的核心素材
- **与正式保留的关系**：16 篇补充语料不在 5.1 漏斗的筛选流程内（其来源为人工定向收集，非 GDELT 检索结果），因此不计入漏斗统计；经人工确认具身细节密度极高，与 109 条正式保留共同构成 VR 场景重建素材库。

## 5.2.3 SAVTBC 六维打标汇总

> **SAVTBC 六维打标汇总**（保留素材 109 条正式 + 16 篇补充，2026-08-05；Grok 语义打标 + 人工复核）：S 空间 93% | V 视觉 95% | T 时间 88% | B 身体 88% | C 社交 98% | **A 声音 70%（最低）**。**逐条明细见附件 `_保留集_SAVTBC打标.csv`**（109+16 行 × 六维标签——打标对全部保留素材执行）。代表性样例：香港宏福苑幸存者自述（S1）——高层/走廊 + 浓烟 + 烟雾刺激 + 邻里互助；Grenfell 时间线（S8）——敲门/信息延迟 + 深夜 + 视觉障碍 + 儿童残障；Palam 父女跳楼（143）——窗户逃生口 + 邻里呼喊 + 快速蔓延 + 跌倒；汕头自建房（4346）——楼梯间浓烟 + 爆炸声 + 傍晚快速蔓延 + 儿童互助。六维覆盖率的完整分布与六角色标签对接见 4.5。



## 6.1 设计决策讨论

- **为什么六角色而不是单角色**：弱势群体不是同质群体——信息断裂（听障）、物理阻断（轮椅）、视野剥夺（视障）、体能衰竭（老年）是不同的困境类型，单一角色无法覆盖"身体 × 环境耦合"的多样性。
- **doomed-to-fail 与用户体验的平衡**：EVRD 证明"注定失败"促进认知共情【evrd2025】，但需配合复盘环节解释失败的结构性原因，避免陷入无助感。
- **真实语料的价值**：相比设计师想象场景，真实新闻提供了可信的参数来源（烟雾蔓延速度、预疏散延迟、弱势群体步速）与叙事细节（"摸墙救夫妇"、"轮椅+孕妇逃生"），支撑了场景的真实性与研究可复现性。
- **伦理约束**：遵循 Tigwell 批评【tigwell2021】——呈现"身体 × 环境耦合"而非孤立"缺陷"，保留角色能动性（理性决策/求助/互助），并预留残障群体 co-design 复核环节。

## 6.2 与 Related Work 的衔接



## 6.3 方法学反思

- **方法学贡献**：本工作的人机协同两阶段框架（小批量人工归纳规则 → 规则审核 → AI 大规模执行 → 人工复核）可迁移到任何「从大规模噪声语料筛选 VR 可重建场景」任务，是方法学层面的可复用资产。具体可迁移点：(1) 抽样裁决金标准的构建模式（分层抽样保代表性 + 负样本归纳排除类别 + 火灾池精判定稿）；(2) 标题级排除的纠错机制（关键词粗筛 → 正文语义判断 → 人工二元裁决）；(3) 二元标准（I1 具身场景细节 / I2 人物叙事）的迭代学习方式。
- **迭代教训**：(1) **标题级评分（v0）**与**一次性聚类代表传播（silhouette 0.18）**均为方法学硬伤——标题无法反映正文质量，聚类代表传播零验证（代表无信息量）。废弃原因必须回归人机协同迭代框架。(2) **特征词匹配 ≠ 语义判断**：关键词法 P14.4/R91.7、Grok 语义初筛 P24.4/R41.7、组合 F1 31.6%，单一自动方法均不可靠。必须由人工做最终保留判断，AI 只做模型辅助的相关性过滤（model-assisted relevance filtering）与召回压缩。
- **局限性披露**：(1) 金标准为多轮抽样裁决（火灾池 1,443 条中人工精判 291 + 早期规则学习 403），未全量裁决部分未纳入当前保留集，保留率 1.64% 为下界估计。(2) 早期关键词压缩存在约 24% 误杀，该方法已在迭代 5 被 Grok 正文语义初筛取代。(3) 主筛选使用 Grok-4.5 语义初筛，后续可考虑多模型交叉验证以降低单一模型偏差，不一致候选以人工判定为准。(4) AI 判定验证：K 侧（判火灾）抽查 62 条误留 0（0/62；近似单侧 95% 上界 4.8%，rule of three；62 条为人工抽检非概率抽样，报告为描述性审计），D 侧（5,192 条非火灾）为语义判定、抽样核查表 150 条待人工复核——召回率尚未验证。**对后续研究启示**：从大规模语料筛选 VR 可重建场景应遵循人工归纳规则 + LLM 语义初筛 + 人工二元精判流水线；保留判断权必须保留在人，AI 只做模型辅助的相关性过滤与召回压缩；PRISMA 规范报告透明度、不认证抽样设计本身，需披露抽样比例、未裁决比例与潜在误杀率，保留集应视为保守、非穷尽的场景依据库；任何压缩候选池的早期方法都应配套正文语义判断与人工复核环节以防漏判。

# 7. Conclusion and Future Work

## 7.1 结论

本文提出了一个 VR 高层火灾共情系统：以真实火灾（宏福苑等）为场景原型，让用户以六类残障身份第一人称体验高层火灾逃生困境。系统通过"身体 × 环境耦合"机制将环境参数转化为残障症状体验，配合 doomed-to-fail 设计与三维共情测量，填补了"高层火灾 × 弱势群体 × 真实语料"的 VR 共情研究空白。场景依据来自人机协作筛选管线（AI 语义过滤 8,180 → 1,027 独立事件，人工两阶段裁决保留 109 条，另有 16 篇人工补充），经六维编码转译为 VR 关卡参数。

## 7.2 下一步

- **1. 三轴编码**：对保留素材（109 条正式 + 16 篇补充）做 VR 叙事三轴编码（轴A 空间动线 / 轴B 身体×环境耦合 / 轴C 决策与情感，0-3 分），逐条精读正文，Kappa ≥ 0.80 校验
- **2. 六角色场景覆盖核查**：检查保留集是否覆盖六类角色的关键困境（信息断裂/物理阻断/视野剥夺/体能衰竭/低视角/跌倒风险），缺口用补充语料补齐
- **3. 场景生成**：以编码结果为基础，将具身场景细节转译为 VR 可交互叙事（空间布局→关卡，身体×环境→感官替代，决策→交互节点）
- **4. 用户研究**：招募健全被试体验六角色场景，测量三维共情增量（IRI/锚定任务/捐助意愿）+ 临场感 + 情境意识
- **5. Grenfell 证词提取**：BBC 216 集调查播客 + 官方证词可继续提取典型幸存者证词全文纳入补充语料
- **6. 中文源检索弥补**：后续可补充微信/澎湃/新京报等中文深度报道源，缩小 GDELT 盲区

# References

## 高层火灾疏散行为学

【kuligowski_nist】Kuligowski, E.D. et al. Movement on Stairs During Building Evacuations. NIST Technical Note 1839, 2014.

【gwynne2016evacuation】Gwynne, S.M.V., Rosenbaum, E.R. Evacuation of Older Adults and People with Functional Limitations. Fire Safety Journal, 2016. DOI: 10.1016/j.firesaf.2016.05.003.

【ronchi2013wheelchair】Ronchi, E., Nilsson, D., Kojić, S., et al. A Virtual Reality Experiment on Flashing Lights at Emergency Exit Portals for People with Visual Impairments. Fire Safety Journal, 2013. DOI: 10.1016/j.firesaf.2012.06.006.

【grenfelltowerinquiry】Grenfell Tower Inquiry. Phase 2 Report. 2024. grenfelltowerinquiry.org.uk.

【kobes2009evacuation】Kobes, M., Helsloot, I., de Vries, B., Post, J. Building Safety and Human Behaviour in Fire: A Literature Review. Fire Safety Journal, 2010.

【kinateder2018vr】Kinateder, M., et al. Virtual Reality for Fire Evacuation Research. Fire Science Reviews, 2014.

【lovreglio2020vr】Lovreglio, R., et al. Prototyping Virtual Reality Serious Games for Building Earthquake Preparedness: The Auckland Case Study. Advanced Engineering Informatics, 2018.

【nfpa101】NFPA 101: Life Safety Code. National Fire Protection Association.

【nfpa72】NFPA 72: National Fire Alarm and Signaling Code. National Fire Protection Association.

## VR 共情与具身体验

【kilteni2012embodiment】Kilteni, K., Groten, R., Slater, M. The Sense of Embodiment in Virtual Reality. Presence: Teleoperators and Virtual Environments, 2012.

【slater1997five】Slater, M., Wilbur, S. A Framework for Immersive Virtual Environments (FIVE): Speculations on the Role of Presence in Virtual Environments. Presence, 1997.

【slater2009place】Slater, M. Place Illusion and Plausibility Can Lead to Realistic Behaviour in Immersive Virtual Environments. Philosophical Transactions of the Royal Society B, 2009.

【herrera2018building】Herrera, F., Bailenson, J., Weisz, E., Ogle, E., Zaki, J. Building Long-Term Empathy: A Large-Scale Comparison of Traditional and Virtual Reality Perspective-Taking. PLoS ONE, 2018.

【ahn2013embodied】Ahn, S.J., Bailenson, J.N., Park, D. Short- and Long-Term Effects of Embodied Experiences in Immersive Virtual Environments on Environmental Locus of Control and Behavior. Computers in Human Behavior, 2014.

【evrd2025】Jiang, X., Zhou, W., Sun, J., et al. Empathy Enhancement Through VR: A Practice-Led Design Study (EVRD). International Journal of Human-Computer Studies, 2025.

【chi26_virtual_perspectives】Da, et al. Virtual Perspectives: Spatial Presence & Agency on Perspective-Taking. CHI 2026.

【shin2017empathy】Shin, D. Empathy and Embodied Experience in Virtual Environment: To What Extent Can Virtual Reality Stimulate Empathy and Embodied Experience? Computers in Human Behavior, 2017.

【visualimpairment2025】Visual Impairment Simulation in VR as an Empathy Booster. Virtual Reality, 2025.

【cultivating2024】Hadjipanayi, C., Christofi, M., Banakou, D., Michael-Grigoriou, D. Cultivating Empathy Through Narratives in Virtual Reality: A Review. Personal and Ubiquitous Computing, 2024.

【vrscoping2024】Trevena, L., Paay, J., McDonald, R. VR Interventions Aimed to Induce Empathy: A Scoping Review. Virtual Reality, 2024.

【legacysphere2024】Yoon, D., et al. LegacySphere: Embodied VR Narrative for Intergenerational Empathy. CHI 2024.

【beyondbeingthere2026】Wang, Q., et al. Beyond "Being There": An Integrated Framework for Measuring Narrative Experience in Immersive VR. CHI 2026 Extended Abstracts.

【storyliving2022】Vallance, M., Towndrow, P.A. Narrative Storyliving in Virtual Reality Design. Frontiers in Virtual Reality, 2022.

【recitkit2025】Setlur, V., Ridet, S. RecitKit: A Spatial Toolkit for Designing Human-Centered Spatial Storytelling in VR. 2025.

## 沉浸式新闻

【delapena2010immersive】de la Peña, N., Weil, P., Llobera, J., et al. Immersive Journalism: Immersive Virtual Reality for the First-Person Experience of News. Presence, 2010.

【feelingnews2023】Greber, H., Lecheler, S., Aaldering, L. Feeling the News? The Differential Effects of Immersive Journalism on Emotional Response. 2023.

【embracing2024】Eskiadi, I.G., Panagiotou, N. Embracing Immersive Journalism: Adoption and Integration by News Media Producers. Journalism and Media, 2024.

【sanchez2020immersive】Sánchez Laws, A.L. Can Immersive Journalism Enhance Empathy? Digital Journalism, 2020.

【aronson2023immersive】Aronson-Rath, R., Milward, J., Owen, T., Pitt, F. Virtual Reality Journalism. Tow Center Report, Columbia University.

## 弱势群体 × 灾害

【kshirsagar2025iscram】Kshirsagar, et al. Deaf Communication in Emergency Response. ISCRAM 2025.

【shakib2025iscram】Shakib, et al. Deaf Community Disaster Alerts. ISCRAM 2025.

【bennett2019asl】Bennett, et al. ASL and Emergency Alerts: Rethinking Visual Accessibility. CHI 2019.

【oecd_dhh_scoping】Experiences of People Who are Deaf or Hard-of-Hearing During Emergencies in OECD Countries: A Scoping Study.

【eew_deaf】From Alert to Action: Earthquake Early Warning and Deaf Communities.

【shockingrealities2025】Krekhov, A., Emmerich, K., Güler, O., Krüger, J. Shocking Realities: VR Horror Games as a Tool for Raising Wheelchair Accessibility Awareness. CHI 2025.

【equitable2025】An Equitable Experience? VR 残障可达性三维概念化. CHI 2025.

【inclusiveavatar2025】Inclusive Avatar Guidelines. CHI 2025.

【tigwell2021】Tigwell, G., et al. Nuanced Perspectives Toward Disability Simulations. CHI 2021.

## 无障碍技术

【canetroller2018】Zhao, Y., Bennett, C.L., Benko, H., et al. Canetroller: Enabling People with Visual Impairments to Navigate Virtual Reality. CHI 2018.

【embodiedexploration2023】Embodied Exploration: Wheelchair Users' VR Accessibility Evaluation. ASSETS 2023.

【ada2010】ADA Standards for Accessible Design. U.S. Department of Justice, 2010.

## VR 疏散研究

【fire2025vrevac】Virtual Reality in Building Evacuation: A Review. Fire, 2025.

【vr2025multimodal】VR 探究多模态警报对疏散行为的影响. Virtual Reality, 2025.

【frdem2023】功能受限人群火灾疏散研究. Frontiers in Disaster and Emergency Management, 2023.

## 方法与标准

【page2021prisma】Page, M.J., et al. The PRISMA 2020 Statement: An Updated Guideline for Reporting Systematic Reviews. BMJ, 2021.

【krippendorff2018】Krippendorff, K. Content Analysis: An Introduction to Its Methodology. SAGE, 2018.

【endsley1995sa】Endsley, M. Toward a Theory of Situation Awareness in Dynamic Systems. Human Factors, 1995.

【kelley1967attribution】Kelley, H.H. Attribution Theory in Social Psychology. Nebraska Symposium on Motivation, 1967.

【batson2011empathy】Batson, C.D. Altruism in Humans. Oxford University Press, 2011.

【brown2006soe】Brown, L., et al. Accessibility in Human-Computer Interaction. 2006.