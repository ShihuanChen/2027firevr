﻿import os
import csv, json, sys, re
csv.field_size_limit(sys.maxsize)
ROOT = os.path.dirname(os.path.abspath(__file__))

# ---- load retention ----
d = json.load(open(ROOT+"/_ret_full.json", encoding="utf-8"))
data = d["data"]
fids = data["field_id_list"]; fnames = data["fields"]; recs = data["data"]
rids = data["record_id_list"]
ret = []
for i, rec in enumerate(recs):
    item = {fnames[j]: (rec[j] if j < len(rec) else None) for j in range(len(fnames))}
    item["_rid"] = rids[i]
    ret.append(item)

def norm_url(u):
    if not u: return ""
    u = u.strip().lower()
    u = re.sub(r"^https?://", "", u); u = re.sub(r"^www\.", "", u)
    return u.split("#")[0].split("?")[0].rstrip("/")
def norm_title(t):
    if not t: return ""
    return re.sub(r"\s+", " ", t.strip().lower())

# ---- source maps ----
src_url = {}; src_title = {}
def add_source(path, url_col, text_col, title_col=None):
    with open(path, encoding="utf-8-sig") as fh:
        r = csv.reader(fh); hdr = next(r)
        ui = hdr.index(url_col) if url_col in hdr else None
        ti = hdr.index(text_col)
        tii = hdr.index(title_col) if (title_col and title_col in hdr) else None
        for row in r:
            if len(row) <= max(ti, ui or 0): continue
            txt = row[ti].strip()
            if not txt: continue
            if ui is not None:
                nu = norm_url(row[ui])
                if nu and nu not in src_url: src_url[nu] = txt
            if tii is not None:
                nt = norm_title(row[tii])
                if nt and nt not in src_title: src_title[nt] = txt
add_source(ROOT+"/第三轮_含正文_筛选草稿.csv", "原始报道链接", "文本", None)
add_source(ROOT+"/../../data/高层火灾新闻收集.csv", "URL", "新闻正文", "标题")
add_source(ROOT+"/../../data/高层火灾新闻总表_20260701.csv", "url", "content", "title")

# ---- md supplementary: explicit bianhao -> md section heading ----
md_path = ROOT+"/../../docs/补充语料_高价值报道.md"
lines = open(md_path, encoding="utf-8").read().split("\n")
md_sections = {}; cur=None; buf=[]
for ln in lines:
    m = re.match(r"^###\s+(.*)$", ln)
    if m:
        if cur is not None: md_sections[cur.strip()] = "\n".join(buf).strip()
        cur = m.group(1).strip(); buf=[]
    elif cur is not None: buf.append(ln)
if cur is not None: md_sections[cur.strip()] = "\n".join(buf).strip()

# build md lookup by normalized heading (strip A1. prefix and parenthetical)
def md_key(h):
    h = re.sub(r"^[A-Z]\d+\.\s*", "", h)         # remove "A1. "
    h = re.sub(r"[（(].*?[)）]", "", h)           # remove parentheticals
    return norm_title(h)
md_lookup = {md_key(k): v for k, v in md_sections.items() if v}

# explicit map retention bianhao -> EXACT md heading (key in md_sections)
explicit_md = {
 "香港宏福苑幸存者自述（微信篇1）": "A1. 宏福苑幸存者自述（微信公众号，原文链接见用户提供）",
 "香港宏福苑幸存者自述（微信篇2）": "A2. 宏福苑幸存者自述（微信第二篇，同一事件另一版本）",
 "NYT李威廉自述：Trapped for Two Hours": "A3. NYT 报道《Trapped for Two Hours in a Burning Tower》（李威廉 William Li 自述）",
 "宏福苑系列补充": "A4. 宏福苑系列补充标题（用户提供，均含高细节）",
 "五级火警技术分析": "A5. 五级火警技术分析（AI 生成综述）",
 "南京明尚西苑-澎湃特写": "B1. 澎湃新闻《特写丨凌晨，从高楼火灾中逃生的人们》",
 "上海静安-三联高楼居民逃生记": "C1. 三联生活周刊《高楼居民逃生记》（新浪转载）",
 "格伦费尔时间线长文": "D1. 今日头条时间线长文《浓烟！尖叫！随后一片死寂》",
 "伦敦大火亲历：求你们接住我的娃": "D2. 英国那些事《伦敦大火亲历：求你们接住我的娃》",
 "格伦费尔系统性回顾": "D3. 搜狐《香港大火所打破的\"纪录\"》——格伦菲尔系统性回顾",
 "格伦费尔之后的生活（出版摘编）": "D4. 澎湃/出版摘编《格伦费尔塔楼火灾是如何发生的》节选（格伦费尔之后的生活）",
 "Cook County十年回顾": "E1. ABC7 十周年回顾（幸存者采访）",
 "杭州赵先生逃生复盘": "F1. 杭州赵先生逃生复盘（2026-02-02，杭州留下某公寓 7 楼）",
 "新京报-海淀王科迪教科书自救": "F2. 新京报《高层住宅楼起火，年轻小伙教科书式安全自救》（2026-01-03，北京海淀玉泉路 21 楼顶层）",
 "广州景安花园23楼": "F3. 广州景安花园火灾（23 楼空调外机起火）",
 "深夜高楼17层一家三口逃生": "F4. 深夜高楼 17 层一家三口死里逃生（红茶魔术猫，2026-01-06）",
}
# 4 rescued fish: numeric bianhao -> real title for lookup
fish_title = {
 "4213": "记者揭广州高层商住楼消防之患",
 "1348": "Skyshot cracker sets building on fire",
 "5641": "Bristol council apology after over-60s stuck inside tower block",
 "7165": "Grenfell families fury after government demolishes wall handprints",
}


# ---- substring search for english truncated-no-source ----
third_rows = []
with open(ROOT+"/第三轮_含正文_筛选草稿.csv", encoding="utf-8-sig") as fh:
    r = csv.reader(fh); hdr = next(r)
    ui = hdr.index("原始报道链接"); ti = hdr.index("文本")
    for row in r:
        if len(row) <= max(ui, ti): continue
        third_rows.append((row[ui], row[ti]))
# GDELT 2-hop: title(norm) -> url(norm) ; then url -> third text
gtitle2url = {}
with open(ROOT+"/../../data/高层火灾新闻总表_20260701.csv", encoding="utf-8-sig") as fh:
    r = csv.reader(fh); hdr = next(r)
    ui = hdr.index("url"); ti = hdr.index("title")
    for row in r:
        if len(row) <= max(ui, ti): continue
        nt = norm_title(row[ti]); nu = norm_url(row[ui])
        if nt and nu and nt not in gtitle2url: gtitle2url[nt] = nu
third_by_url = {norm_url(u): t for u, t in third_rows}
def hop_resolve(title):
    nt = norm_title(title)
    if not nt: return None
    gu = gtitle2url.get(nt)
    if not gu:
        # prefix match (retention title may be truncated)
        for gt, gurl in gtitle2url.items():
            if gt.startswith(nt[:30]) or nt.startswith(gt[:30]):
                gu = gurl; break
    if not gu: return None
    return third_by_url.get(gu)
news_rows = []
with open(ROOT+"/../../data/高层火灾新闻收集.csv", encoding="utf-8-sig") as fh:
    r = csv.reader(fh); hdr = next(r)
    ui = hdr.index("URL"); ti = hdr.index("新闻正文"); tii = hdr.index("标题")
    for row in r:
        if len(row) <= max(ui, ti, tii): continue
        news_rows.append((row[ui], row[tii], row[ti]))

def search_sources(title):
    # CJK-only body search: scan body for a distinctive 3/4-char window from the title.
    # (English url-phrase search was removed: it produced too many mis-fills.)
    if not re.search(r"[\u4e00-\u9fff]", title):
        return None
    stop = {"火灾","高层","大楼","消防","居民","起火","报道","记者","广州","高层商","商住楼消"}
    cjk = re.findall(r"[\u4e00-\u9fff]+", title)
    windows = []
    for seg in cjk:
        for L in (3,4):
            for i in range(len(seg)-L+1):
                w = seg[i:i+L]
                if w not in stop: windows.append(w)
    if not windows: return None
    best = None
    for u, txt in third_rows:
        if len(txt) < 300: continue
        if any(w in txt for w in windows):
            if best is None or len(txt) > len(best): best = txt
    for u, t, txt in news_rows:
        if len(txt) < 300: continue
        if any(w in (t+txt) for w in windows):
            if best is None or len(txt) > len(best): best = txt
    return best

def hop_resolve(title):
    # 2-hop: GDELT title(prefix>=20) -> GDELT url -> third text. Strong signal.
    nt = norm_title(title)
    if not nt: return None
    gu = gtitle2url.get(nt)
    if not gu:
        for gt, gurl in gtitle2url.items():
            if len(gt) >= 20 and (gt.startswith(nt[:25]) or nt.startswith(gt[:25])):
                gu = gurl; break
    if not gu: return None
    return third_by_url.get(gu)

# ---- resolve & build plan ----
plan = []; report = {"url":0,"md":0,"title":0,"search":0,"already_ok":0,"gap":[]}
for it in ret:
    bianhao = (it.get("编号") or "").strip()
    url = (it.get("原始URL") or "").strip()
    cur = (it.get("正文/摘要") or "").strip()
    rid = it["_rid"]
    lookup = fish_title.get(bianhao, bianhao)   # fish numeric -> real title
    nu = norm_url(url); nt = norm_title(lookup)
    full = src_url.get(nu) or src_title.get(nt)
    src_kind = "url/title"
    if not full and bianhao in explicit_md:
        h = explicit_md[bianhao]
        if h in md_sections and md_sections[h]:
            full = md_sections[h]; src_kind = "md"
    if not full and nt:
        # try md by normalized bianhao
        nk = md_key(bianhao)
        if nk in md_lookup:
            full = md_lookup[nk]; src_kind = "md"
    if not full and re.search(r"[\u4e00-\u9fff]", lookup):
        s = search_sources(lookup)
        if s: full = s; src_kind = "search"
    if not full and re.search(r"[A-Za-z]", lookup):
        h = hop_resolve(lookup)
        if h: full = h; src_kind = "gdelthop"
    if full and len(full) > len(cur) + 50 and src_kind != "search":
        plan.append({"rid": rid, "text": full, "src": src_kind, "bianhao": bianhao[:40]})
        report[src_kind] = report.get(src_kind, 0) + 1
    elif full and len(full) <= len(cur)+50:
        report["already_ok"]+=1
    else:
        report["gap"].append((bianhao[:50], len(cur)))

print("UPDATE plan size:", len(plan))
print("by source:", {k:v for k,v in report.items() if k!="gap"})
print("GAPS (no full text, bianhao | cur_len):")
for g in report["gap"]: print("  ", g)
json.dump(plan, open(ROOT+"/_update_plan.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
print("plan written.")



